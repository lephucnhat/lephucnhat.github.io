# -*- coding: utf-8 -*-
"""CheckCCRQT — overview and per-lot PDF map export (Task 14).

Builds on two sibling modules in this package that port LVTLayout's print
engine into CheckCCRQT (see their docstrings for exactly what changed):

- ``exporters._layout_engine.MapLayoutEngine`` -- ported from
  ``LVTLayout/layout_engine/engine.py``'s ``LvtEngine``.
- ``exporters._legend.add_legend_block`` -- ported from
  ``LVTLayout/layout_engine/legend.py``.

This module itself is a port of ``LVTLayout/exporter.py``'s per-feature
PDF export loop (``_create_single_feature_layer``, ``_style_plot_layer``,
``_auto_scale``, ``_export_single``, ``_merge_pdfs``, ``_safe_filename``),
plus two new public entry points required by Task 14:

- ``export_overview_map(iface, plugin_dir, layer, status_field, output_pdf)``
- ``export_per_lot_maps(iface, plugin_dir, layer, features, field_map,
  output_dir, merge=True)``

PyPDF2 (used by ``_merge_pdfs``) is a hard dependency of the "merge"
option only -- verified installed in the QGIS-bundled interpreter
(``python-qgis-ltr.bat -c "import PyPDF2"`` -> ``PyPDF2 3.0.1``) during
this task's implementation. If it is missing at runtime,
``export_per_lot_maps(..., merge=True)`` raises ``ImportError`` instead of
silently skipping the merge.
"""

import concurrent.futures
import io
import math
import os
import re
import tempfile
import threading
import unicodedata
import urllib.request
from datetime import date as _date, datetime as _dt, timedelta as _timedelta

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QColor, QFont
from qgis.core import (
    QgsCategorizedSymbolRenderer,
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsFeature,
    QgsFillSymbol,
    QgsLayoutExporter,
    QgsLayoutItemMap,
    QgsMessageLog,
    QgsPalLayerSettings,
    QgsProject,
    QgsRasterLayer,
    QgsRectangle,
    QgsRendererCategory,
    QgsSingleSymbolRenderer,
    QgsSymbol,
    QgsTextBufferSettings,
    QgsTextFormat,
    QgsVectorLayer,
    QgsVectorLayerSimpleLabeling,
    QgsWkbTypes,
    Qgis,
)

from ._layout_engine import MapLayoutEngine, ITEM_IDS
from ..core.coordinate_utils import format_coordinate

#: High-resolution satellite XYZ basemap for harvest traceability maps.
SATELLITE_XYZ_URL = "https://mt1.google.com/vt/lyrs=s&x={x}&y={y}&z={z}"
ESRI_XYZ_URL = "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}"

_XYZ_TILE_CACHE = {}
_XYZ_TILE_CACHE_LOCK = threading.Lock()


def _download_xyz_tile(tx, ty, zoom, timeout=3):
    """Download one satellite tile (Google -> Esri fallback) with in-memory caching."""
    from PIL import Image

    key = (zoom, tx, ty)
    with _XYZ_TILE_CACHE_LOCK:
        cached = _XYZ_TILE_CACHE.get(key)
    if cached is not None:
        return Image.open(io.BytesIO(cached)).convert("RGB")

    headers = {"User-Agent": "Mozilla/5.0"}
    for tmpl in (SATELLITE_XYZ_URL, ESRI_XYZ_URL):
        url = tmpl.format(x=tx, y=ty, z=zoom)
        req = urllib.request.Request(url, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                data = resp.read()
            if len(data) > 800:
                img = Image.open(io.BytesIO(data)).convert("RGB")
                with _XYZ_TILE_CACHE_LOCK:
                    if len(_XYZ_TILE_CACHE) < 1024:
                        _XYZ_TILE_CACHE[key] = data
                return img
        except Exception:
            continue
    return None


def _deg2num(lat_deg, lon_deg, zoom):
    lat_rad = math.radians(lat_deg)
    n = 2.0 ** zoom
    xtile = int((lon_deg + 180.0) / 360.0 * n)
    ytile = int((1.0 - math.asinh(math.tan(lat_rad)) / math.pi) / 2.0 * n)
    return xtile, ytile


def _lonlat_to_3857(lon_deg, lat_deg):
    x = lon_deg * 20037508.34 / 180.0
    y = math.log(math.tan((90.0 + lat_deg) * math.pi / 360.0)) / (math.pi / 180.0)
    y = y * 20037508.34 / 180.0
    return x, y


def _tile_bounds_3857(xtile, ytile, zoom):
    n = 2.0 ** zoom
    lon_min = xtile / n * 360.0 - 180.0
    lon_max = (xtile + 1) / n * 360.0 - 180.0
    lat_max = math.degrees(math.atan(math.sinh(math.pi * (1 - 2 * ytile / n))))
    lat_min = math.degrees(math.atan(math.sinh(math.pi * (1 - 2 * (ytile + 1) / n))))
    xmin, ymin = _lonlat_to_3857(lon_min, lat_min)
    xmax, ymax = _lonlat_to_3857(lon_max, lat_max)
    return xmin, ymin, xmax, ymax


def _fetch_satellite_geotiff(extent, crs, out_tif, max_tiles=49):
    """Synchronously download XYZ satellite tiles for ``extent`` (in ``crs``)
    and write a georeferenced EPSG:3857 GeoTIFF so ``QgsLayoutExporter``
    always renders the satellite background reliably.
    """
    try:
        from PIL import Image
        import numpy as np
        from osgeo import gdal, osr
    except ImportError:
        return None

    try:
        wgs84 = QgsCoordinateReferenceSystem("EPSG:4326")
        if crs is not None and crs.isValid() and crs.authid() != "EPSG:4326":
            xform = QgsCoordinateTransform(crs, wgs84, QgsProject.instance())
            wgs_rect = xform.transformBoundingBox(extent)
        else:
            wgs_rect = extent

        min_lon = max(-179.9, wgs_rect.xMinimum())
        max_lon = min(179.9, wgs_rect.xMaximum())
        min_lat = max(-85.0, wgs_rect.yMinimum())
        max_lat = min(85.0, wgs_rect.yMaximum())

        span_lon = max(max_lon - min_lon, 1e-5)
        zoom = 17
        for z in range(18, 9, -1):
            x0, y0 = _deg2num(max_lat, min_lon, z)
            x1, y1 = _deg2num(min_lat, max_lon, z)
            if (abs(x1 - x0) + 1) * (abs(y1 - y0) + 1) <= max_tiles:
                zoom = z
                break

        x0, y0 = _deg2num(max_lat, min_lon, zoom)
        x1, y1 = _deg2num(min_lat, max_lon, zoom)
        xmin_t, _ymin_t, _xmax_t, ymax_t = _tile_bounds_3857(x0, y0, zoom)
        _xmin_b, ymin_b, xmax_b, _ymax_b = _tile_bounds_3857(x1, y1, zoom)

        cols = x1 - x0 + 1
        rows = y1 - y0 + 1
        canvas = Image.new("RGB", (cols * 256, rows * 256))
        fetched = 0
        tile_coords = [(tx, ty) for tx in range(x0, x1 + 1) for ty in range(y0, y1 + 1)]
        with concurrent.futures.ThreadPoolExecutor(max_workers=min(8, max(1, len(tile_coords)))) as pool:
            future_map = {
                pool.submit(_download_xyz_tile, tx, ty, zoom): (tx, ty)
                for tx, ty in tile_coords
            }
            for fut in concurrent.futures.as_completed(future_map):
                tx, ty = future_map[fut]
                try:
                    tile_img = fut.result()
                except Exception:
                    tile_img = None
                if tile_img is not None:
                    canvas.paste(tile_img, ((tx - x0) * 256, (ty - y0) * 256))
                    fetched += 1

        if fetched == 0:
            return None

        arr = np.array(canvas)
        h, w, _ = arr.shape
        px_w = (xmax_b - xmin_t) / w
        px_h = (ymin_b - ymax_t) / h
        ds = gdal.GetDriverByName("GTiff").Create(out_tif, w, h, 3, gdal.GDT_Byte)
        srs = osr.SpatialReference()
        srs.ImportFromEPSG(3857)
        ds.SetProjection(srs.ExportToWkt())
        ds.SetGeoTransform([xmin_t, px_w, 0.0, ymax_t, 0.0, px_h])
        for band_idx in range(3):
            ds.GetRasterBand(band_idx + 1).WriteArray(arr[:, :, band_idx])
        ds.FlushCache()
        ds = None
        return out_tif
    except Exception:
        return None


def _parse_target_date(val):
    """Parse ``date``, ``datetime``, or ISO ``YYYY-MM-DD`` string into ``date``."""
    if val is None:
        return None
    if isinstance(val, _dt):
        return val.date()
    if isinstance(val, _date):
        return val
    text = str(val).strip()
    if not text:
        return None
    try:
        return _date.fromisoformat(text[:10])
    except ValueError:
        for fmt in ("%d/%m/%Y", "%Y/%m/%d"):
            try:
                return _dt.strptime(text[:10], fmt).date()
            except ValueError:
                continue
    return None


def _stretch_s2_channel(arr):
    """Stretch a Sentinel-2 reflectance band (2–98%, gamma 0.85) into uint8."""
    import numpy as np

    data = np.asarray(arr, dtype="float64")
    valid = data[np.isfinite(data) & (data > 0)]
    if valid.size == 0:
        return np.zeros(data.shape, dtype=np.uint8)
    p2, p98 = np.percentile(valid, (2, 98))
    if p98 <= p2:
        p98 = p2 + 1.0
    scaled = np.clip((data - p2) / (p98 - p2), 0.0, 1.0)
    return (np.power(scaled, 0.85) * 255.0).astype(np.uint8)


def _create_sentinel2_date_basemap_layer(
    extent,
    crs,
    target_date,
    stac_url=None,
    offline_folder=None,
):
    """Fetch a Sentinel-2 RGB GeoTIFF raster layer matching ``target_date``.

    Returns ``(raster_layer, temp_tif_path, scene_date_ddmmyyyy)`` or
    ``(None, None, None)`` if no suitable Sentinel-2 RGB scene can be read.
    """
    parsed = _parse_target_date(target_date)
    if parsed is None or extent is None or crs is None:
        return None, None, None

    try:
        import numpy as np
        from osgeo import gdal, osr
        from ..core import sentinel_stac

        wgs84 = QgsCoordinateReferenceSystem("EPSG:4326")
        if crs.isValid() and crs.authid() != "EPSG:4326":
            xform = QgsCoordinateTransform(crs, wgs84, QgsProject.instance())
            wgs_rect = xform.transformBoundingBox(extent)
        else:
            wgs_rect = extent

        wgs_bbox = (
            max(-179.9, wgs_rect.xMinimum()),
            max(-85.0, wgs_rect.yMinimum()),
            min(179.9, wgs_rect.xMaximum()),
            min(85.0, wgs_rect.yMaximum()),
        )

        rgb_scenes = []
        if offline_folder:
            local_scenes = sentinel_stac.scan_local_folder(offline_folder)
            rgb_scenes = [
                s for s in local_scenes
                if s.assets.get("red") and s.assets.get("green") and s.assets.get("blue")
            ]
        else:
            resolved_url = stac_url or sentinel_stac.DEFAULT_STAC_URL
            for win_days in (3, 18):
                try:
                    found = sentinel_stac.search_scenes(
                        wgs_bbox,
                        parsed - _timedelta(days=win_days),
                        parsed + _timedelta(days=win_days),
                        max_cloud=80,
                        limit=40,
                        stac_url=resolved_url,
                    )
                except Exception:
                    found = []
                rgb_scenes = [
                    s for s in found
                    if s.assets.get("red") and s.assets.get("green") and s.assets.get("blue")
                ]
                if rgb_scenes:
                    break

        if not rgb_scenes:
            return None, None, None

        best = min(
            rgb_scenes,
            key=lambda s: (
                abs((s.datetime.date() - parsed).days),
                s.cloud_cover if s.cloud_cover is not None else 50.0,
            ),
        )
        r_arr, gt = sentinel_stac.read_band_window(best.assets["red"], wgs_bbox)
        g_arr, _ = sentinel_stac.read_band_window(best.assets["green"], wgs_bbox)
        b_arr, _ = sentinel_stac.read_band_window(best.assets["blue"], wgs_bbox)

        h, w = r_arr.shape
        out_tif = os.path.join(
            tempfile.gettempdir(), f"checkccrqt_s2_{os.getpid()}_{id(best)}.tif"
        )
        ds = gdal.GetDriverByName("GTiff").Create(out_tif, w, h, 3, gdal.GDT_Byte)
        srs = osr.SpatialReference()
        srs.ImportFromEPSG(4326)
        ds.SetProjection(srs.ExportToWkt())
        ds.SetGeoTransform(list(gt))
        for idx, band_arr in enumerate((r_arr, g_arr, b_arr), start=1):
            ds.GetRasterBand(idx).WriteArray(_stretch_s2_channel(band_arr))
        ds.FlushCache()
        ds = None

        date_str = best.datetime.strftime("%d/%m/%Y")
        layer = QgsRasterLayer(out_tif, f"Sentinel-2 ({date_str})")
        if layer.isValid():
            return layer, out_tif, date_str
        if os.path.exists(out_tif):
            try:
                os.remove(out_tif)
            except OSError:
                pass
    except Exception:
        pass
    return None, None, None


def _create_satellite_basemap_layer(extent=None, crs=None, max_tiles=49):
    """Return ``(sat_layer, temp_tif_path)`` using a synchronous GeoTIFF when
    possible, falling back to an XYZ ``QgsRasterLayer``.
    """
    if extent is not None and crs is not None:
        fd, tmp_tif = tempfile.mkstemp(suffix="_sat.tif")
        os.close(fd)
        tif_path = _fetch_satellite_geotiff(extent, crs, tmp_tif, max_tiles=max_tiles)
        if tif_path and os.path.exists(tif_path):
            sat_layer = QgsRasterLayer(tif_path, "Ảnh vệ tinh nền")
            if sat_layer is not None and sat_layer.isValid():
                return sat_layer, tif_path
        try:
            os.remove(tmp_tif)
        except OSError:
            pass

    uri = f"type=xyz&url={SATELLITE_XYZ_URL}&zmax=19&zmin=0"
    sat_layer = QgsRasterLayer(uri, "Ảnh vệ tinh nền", "wms")
    if sat_layer is not None and sat_layer.isValid():
        return sat_layer, None
    return None, None


def _format_centroid_vn2000(feat, layer_crs, lon_0_deg=106.0):
    """Format the feature centroid in VN-2000 (2 decimals) using ``coordinate_utils``."""
    try:
        geom = feat.geometry()
        if geom is None or geom.isNull() or geom.isEmpty():
            return ""
        pt = geom.centroid().asPoint()
        if layer_crs is not None and layer_crs.isValid() and layer_crs.authid() != "EPSG:4326":
            wgs84 = QgsCoordinateReferenceSystem("EPSG:4326")
            xform = QgsCoordinateTransform(layer_crs, wgs84, QgsProject.instance())
            pt = xform.transform(pt)
        res = format_coordinate(pt.x(), pt.y(), "VN-2000", lon_0_deg=lon_0_deg)
        if isinstance(res, tuple) and len(res) == 2:
            return f"X={res[1]}, Y={res[0]}"
        return str(res)
    except Exception:
        return ""


# Map item size in the double-line frame template (mm), read from
# templates/Khung_CheckCCRQT_02Line.qpt's <LayoutItem ... id="Map" ...
# size="171.7,233.45,mm">, used so _auto_scale fits the actual print
# frame rather than a guessed page size.
_MAP_FRAME_W_MM = 171.7
_MAP_FRAME_H_MM = 233.45

# Nice scale steps for auto-fit (extended to 1:1,000,000 for province-wide A3 maps — BUG-13).
_NICE_SCALES = [
    1000, 1500, 2000, 2500, 3000, 4000, 5000, 7500,
    10000, 12500, 15000, 20000, 25000, 50000, 100000,
    150000, 200000, 250000, 350000, 500000, 750000, 1000000,
]
_DEG_TO_M = 111320.0  # approximate meters per degree at equator

# -- Status -> color palette -------------------------------------------------
# Colors are the plan's status palette (PLAN.md "Bảng màu chuẩn Kiểm lâm" /
# "Trạng thái"):  Thành công #2E7D32, Cảnh báo #E65100, Lỗi #C62828.
#
# status_field's actual values are whatever the layer holds -- e.g.
# core.change_detector's STATUS_NONE/STATUS_PARTIAL/STATUS_CLEARCUT/
# STATUS_CLOUDY, or core.jrc_tmf_checker's "Cảnh báo" -- so exact strings
# aren't hardcoded. Instead, values are classified by keyword so any
# status text naming a lot that is clear/compliant, "warning"-level, or an
# outright violation gets the matching tone, with an explicit mapping for
# the known constants used elsewhere in this plugin and a safe default.
STATUS_COLOR_SUCCESS = "#00FF66"
STATUS_COLOR_WARNING = "#FF9100"
STATUS_COLOR_ERROR = "#FF1744"
STATUS_COLOR_DEFAULT = "#B0BEC5"  # high-contrast neutral silver for unrecognized values

#: Exact-match overrides for the known status constants used elsewhere in
#: this plugin (core.change_detector, core.jrc_tmf_checker).
_STATUS_EXACT_COLORS = {
    "Chưa khai thác": STATUS_COLOR_SUCCESS,
    "Khai thác một phần": STATUS_COLOR_WARNING,
    "Đã khai thác trắng": STATUS_COLOR_ERROR,
    "Bị mây che / Thiếu dữ liệu": STATUS_COLOR_DEFAULT,
    "Cảnh báo": STATUS_COLOR_WARNING,
}

#: Statuses meaning "no result for this lot" (a per-lot processing error,
#: missing geometry, cancelled before processing, or JRC TMF no-data) --
#: neutral grey, never the red "violation" tone, even though "Lỗi: ..."
#: contains the "lỗi" error keyword below.
_NO_RESULT_PREFIXES = ("lỗi:", "thiếu dữ liệu", "chưa kiểm tra", "không xác định")

_ERROR_KEYWORDS = ("trắng", "lỗi", "error", "vi phạm", "violation", "mất rừng", "phá rừng")
_WARNING_KEYWORDS = ("cảnh báo", "một phần", "warning", "nghi vấn", "partial")

# -- Title/branding text -----------------------------------------------------
# The task brief's adapted Step 1 (ported from PLAN.md) specified the map
# title text as "CHECK CCRQT — Phòng Sử dụng & Phát triển rừng" -- the same
# branding string used as the sidebar title+subtitle in ui/main_dialog.py
# (TAB_DEFS area, "CHECK CCRQT" / "Phòng Sử dụng & Phát triển rừng").
#
# Deliberate deviation: the exported PDF's main title (template item
# "Tên bản đồ") instead gets a content-descriptive string per export kind
# ("Bản đồ tổng thể lô chứng chỉ" / "Bản đồ lô chứng chỉ") -- naming what
# the map actually shows, the way every other printed CheckCCRQT map
# would need to if this plugin ever grows more map types, rather than a
# static plugin slogan repeated identically on every PDF page regardless
# of content. The brief's literal branding string is NOT dropped, though:
# it is placed in the template's organization-name slot ("Tên đv xd bản
# đồ", id ids["org_name"]) instead, via BRAND_ORG_TEXT below, so it still
# appears on every exported page -- just in the slot built for an
# org/producer credit line rather than doubling as the map's own title.
BRAND_ORG_TEXT = "Phòng Sử dụng & Phát triển rừng"


def status_color(value):
    """Classify a status string into one of the three palette colors.

    Falls back to ``STATUS_COLOR_DEFAULT`` for ``None``/empty/unrecognized
    values (e.g. the JRC TMF "no change" case, or any other status text
    that isn't a warning or an outright violation).
    """
    if value is None:
        return STATUS_COLOR_DEFAULT
    text = str(value).strip()
    if not text:
        return STATUS_COLOR_DEFAULT
    if text in _STATUS_EXACT_COLORS:
        return _STATUS_EXACT_COLORS[text]

    lowered = text.lower()
    if lowered.startswith(_NO_RESULT_PREFIXES):
        return STATUS_COLOR_DEFAULT
    if any(kw in lowered for kw in _ERROR_KEYWORDS):
        return STATUS_COLOR_ERROR
    if any(kw in lowered for kw in _WARNING_KEYWORDS):
        return STATUS_COLOR_WARNING
    return STATUS_COLOR_SUCCESS


# -- Shared helpers (ported from LVTLayout/exporter.py) ----------------------


def _is_geographic(crs):
    if not crs or not crs.isValid():
        return False
    return crs.isGeographic()


def _get_padding(bbox, crs):
    if _is_geographic(crs):
        min_pad = 0.0002  # ~22 meters
    else:
        min_pad = 10  # 10 meters
    pad_x = max(bbox.width() * 0.3, min_pad)
    pad_y = max(bbox.height() * 0.3, min_pad)
    return pad_x, pad_y


def _auto_scale(bbox, crs=None, map_w_mm=_MAP_FRAME_W_MM,
                 map_h_mm=_MAP_FRAME_H_MM, padding=1.3):
    """Calculate auto-fit scale from bounding box.

    Ported from ``LVTLayout/exporter.py::_auto_scale``. Handles both
    projected (meters) and geographic (degrees) CRS, and snaps the raw
    fit scale up to the next "nice" cartographic scale step.
    """
    bw = bbox.width() * padding
    bh = bbox.height() * padding
    if bw <= 0 or bh <= 0:
        return 2000

    is_geo = crs and _is_geographic(crs)
    if not is_geo and bw < 1.0 and bh < 1.0:
        is_geo = True

    if is_geo:
        bw *= _DEG_TO_M
        bh *= _DEG_TO_M

    scale_x = bw / (map_w_mm / 1000.0)
    scale_y = bh / (map_h_mm / 1000.0)
    raw = max(scale_x, scale_y)

    for s in _NICE_SCALES:
        if s >= raw:
            return s
    return _NICE_SCALES[-1]


def _safe_filename(text):
    """Convert Vietnamese text to a safe ASCII filename fragment.

    Ported verbatim from ``LVTLayout/exporter.py::_safe_filename``.
    """
    if not text:
        return "unknown"
    nfkd = unicodedata.normalize("NFKD", str(text))
    ascii_str = nfkd.encode("ASCII", "ignore").decode("ASCII")
    safe = re.sub(r"[^A-Za-z0-9_\-]", "_", ascii_str)
    safe = re.sub(r"_+", "_", safe).strip("_")
    return safe or "unknown"


def _fget(feat, field_name):
    """Safely get a feature attribute value as a string, or ``""``."""
    if not field_name:
        return ""
    names = feat.fields().names()
    if field_name not in names:
        return ""
    value = feat[field_name]
    if value is None or str(value) == "NULL":
        return ""
    return str(value)


def _create_single_feature_layer(feat, crs, layer_name="__ccrqt_lot__"):
    """Create a temporary memory layer containing exactly ONE feature.

    Ported verbatim (aside from the default layer name) from
    ``LVTLayout/exporter.py::_create_single_feature_layer``.
    """
    geom_type = QgsWkbTypes.displayString(feat.geometry().wkbType())
    crs_auth = crs.authid() if crs is not None and crs.isValid() else ""
    uri = f"{geom_type}?crs={crs_auth}" if crs_auth else geom_type
    mem = QgsVectorLayer(uri, layer_name, "memory")
    if crs is not None and crs.isValid():
        mem.setCrs(crs)
    dp = mem.dataProvider()

    dp.addAttributes(feat.fields().toList())
    mem.updateFields()

    new_feat = QgsFeature(mem.fields())
    new_feat.setGeometry(feat.geometry())
    field_names = [f.name() for f in mem.fields()]
    for field in feat.fields():
        if field.name() in field_names:
            new_feat[field.name()] = feat[field.name()]
    dp.addFeatures([new_feat])
    mem.updateExtents()

    return mem


def _style_plot_layer(layer):
    """Apply highlight renderer: green fill + red stroke.

    Ported verbatim from ``LVTLayout/exporter.py::_style_plot_layer``.
    """
    sym = QgsFillSymbol.createSimple({
        'color': '180,255,180,60',
        'outline_color': '255,0,0,255',
        'outline_width': '0.8',
    })
    layer.setRenderer(QgsSingleSymbolRenderer(sym))


def _apply_lot_labels(layer, label_field):
    """Enable readable forest lot labels with white halo over satellite imagery."""
    if not label_field or layer.fields().indexOf(label_field) < 0:
        return
    pal = QgsPalLayerSettings()
    pal.fieldName = label_field
    pal.enabled = True

    fmt = QgsTextFormat()
    fmt.setFont(QFont("Arial", 9, QFont.Bold))
    fmt.setSize(9)
    fmt.setColor(QColor("#0F172A"))

    buf = QgsTextBufferSettings()
    buf.setEnabled(True)
    buf.setSize(1.2)
    buf.setColor(QColor("#FFFFFF"))
    fmt.setBuffer(buf)

    pal.setFormat(fmt)
    layer.setLabeling(QgsVectorLayerSimpleLabeling(pal))
    layer.setLabelsEnabled(True)


def _make_hollow_outline_symbol(hex_color, outline_width_mm=0.55):
    """Hollow polygon symbol (no fill) with high-contrast stroke for Google Earth basemap."""
    sym = QgsFillSymbol.createSimple({
        "style": "no",
        "color": "0,0,0,0",
        "outline_color": hex_color,
        "outline_width": str(outline_width_mm),
        "outline_width_unit": "MM",
    })
    sl = sym.symbolLayer(0)
    if sl is not None:
        sl.setBrushStyle(Qt.NoBrush)
        sl.setStrokeColor(QColor(hex_color))
        sl.setStrokeWidth(outline_width_mm)
    return sym


def _style_overview_layer(layer, status_field):
    """Apply a hollow categorized renderer keyed on ``status_field``.

    No fill (transparent interior) with bright contrasting outlines over
    Google Earth satellite imagery.
    """
    idx = layer.fields().indexOf(status_field)
    if idx < 0:
        raise ValueError(f"Field not found on layer: {status_field!r}")

    values = sorted(
        {str(v) for v in layer.uniqueValues(idx) if v is not None and str(v) != "NULL"}
    )

    categories = []
    for value in values:
        symbol = _make_hollow_outline_symbol(status_color(value), outline_width_mm=0.55)
        categories.append(QgsRendererCategory(value, symbol, value))

    else_symbol = _make_hollow_outline_symbol(STATUS_COLOR_DEFAULT, outline_width_mm=0.45)
    categories.append(QgsRendererCategory("", else_symbol, "Khác", True))

    renderer = QgsCategorizedSymbolRenderer(status_field, categories)
    layer.setRenderer(renderer)


# -- export_overview_map ------------------------------------------------------


def export_overview_map(
    iface,
    plugin_dir: str,
    layer,
    status_field: str,
    output_pdf: str,
    include_satellite: bool = True,
    org_name: str = BRAND_ORG_TEXT,
    label_field: str = None,
    title: str = "BẢN ĐỒ TỔNG THỂ LÔ CHỨNG CHỈ",
) -> str:
    """Export an A3 overview PDF of ``layer`` over Google Earth basemap.

    Uses A3 size (297 x 420 mm), hollow high-contrast green/status outlines
    (no fill), uppercase map title, bottom legend clear of the top-left logo,
    and automatic lot labels whenever the map scale is larger than 1:5000
    (``scale <= 5000``).
    """
    _style_overview_layer(layer, status_field)

    page_w_mm = 297.0
    page_h_mm = 420.0
    sx = page_w_mm / 210.0
    sy = page_h_mm / 297.0
    scale = _auto_scale(
        layer.extent(),
        crs=layer.crs(),
        map_w_mm=_MAP_FRAME_W_MM * sx,
        map_h_mm=_MAP_FRAME_H_MM * sy,
    )

    if scale <= 5000:
        resolved_label_field = label_field
        if not resolved_label_field:
            field_names = layer.fields().names()
            for cand in ("id_lo", "Farm_ID", "lo", "Plot"):
                if cand in field_names:
                    resolved_label_field = cand
                    break
        if resolved_label_field:
            _apply_lot_labels(layer, resolved_label_field)

    project = QgsProject.instance()
    added_temp_layer = project.mapLayer(layer.id()) is None
    if added_temp_layer:
        project.addMapLayer(layer, False)
    sat_layer, sat_tif = (
        _create_satellite_basemap_layer(layer.extent(), layer.crs(), max_tiles=49)
        if include_satellite
        else (None, None)
    )
    if sat_layer is not None:
        project.addMapLayer(sat_layer, False)

    engine = MapLayoutEngine(iface, plugin_dir)
    crs_desc = layer.crs().description() or layer.crs().authid() or "VN-2000"

    params = {
        "mode": "print",
        "lang": "VN",
        "page_width": page_w_mm,
        "page_height": page_h_mm,
        "scale": scale,
        "extent_mode": "layer",
        "extent_layer": layer,
        "title": str(title).upper(),
        "org_name": org_name or BRAND_ORG_TEXT,
        "study_area": "PHẠM VI NGHIÊN CỨU TOÀN BỘ LÔ RỪNG CHỨNG CHỈ",
        "data_sources": f"{org_name or BRAND_ORG_TEXT} | Hệ tọa độ: {crs_desc} | Nền: Google Earth",
        "show_scalebar": True,
        "show_legend": True,
        "show_north": True,
        "signature_block": False,
        "legend": {
            "enabled": True,
            "title": "CHÚ DẪN",
            "layer_ids": [layer.id()],
            "layer_renames": {layer.id(): "Trạng thái lô rừng"},
            "filter_by_map": False,
            "columns": 1,
            "symbol_width": 11,
            "symbol_height": 5,
            "max_width": 85,
            "font_size": 9,
            "title_size": 12,
        },
    }

    layout = engine.create_layout(params)

    try:
        # Lock the map item to the target layer (+ optional satellite basemap),
        # regardless of whatever else happens to be visible in the project's
        # layer tree, so the export is deterministic.
        map_item = engine._find_item(layout, ITEM_IDS[("print", "VN")]["map"], QgsLayoutItemMap)
        if map_item is not None:
            map_item.setKeepLayerSet(True)
            if layer.crs() is not None and layer.crs().isValid():
                map_item.setCrs(layer.crs())
            layers = [layer, sat_layer] if sat_layer is not None else [layer]
            map_item.setLayers(layers)
            map_item.zoomToExtent(layer.extent())
            map_item.setScale(scale)
            layout.refresh()

        exporter = QgsLayoutExporter(layout)
        settings = QgsLayoutExporter.PdfExportSettings()
        result = exporter.exportToPdf(output_pdf, settings)
    finally:
        project.layoutManager().removeLayout(layout)
        if added_temp_layer and project.mapLayer(layer.id()) is not None:
            project.removeMapLayer(layer.id())
        if sat_layer is not None:
            project.removeMapLayer(sat_layer.id())
        if sat_tif and os.path.exists(sat_tif):
            try:
                os.remove(sat_tif)
            except OSError:
                pass

    if result != QgsLayoutExporter.Success:
        raise RuntimeError(f"Overview PDF export failed: error code {result}")

    return output_pdf


# -- export_per_lot_maps -------------------------------------------------------


def _build_study_area(feat, field_map):
    """Build a "|"-joined info line from whatever field_map keys resolve."""
    parts = []
    owner = _fget(feat, field_map.get("chu_ho"))
    id_lo = _fget(feat, field_map.get("id_lo"))
    dien_tich = _fget(feat, field_map.get("dien_tich_kb"))
    nam_trong = _fget(feat, field_map.get("nam_trong"))

    if owner:
        parts.append(owner)
    if id_lo:
        parts.append(id_lo)
    if dien_tich:
        try:
            parts.append(f"{float(dien_tich):.2f} ha")
        except ValueError:
            parts.append(dien_tich)
    if nam_trong:
        parts.append(f"Trồng {nam_trong}")
    return " | ".join(parts)


def _export_single_lot(
    engine,
    feat,
    layer_crs,
    field_map,
    output_dir,
    include_satellite=True,
    audit_record=None,
    lon_0_deg=106.0,
    stac_url=None,
    offline_folder=None,
    org_name=BRAND_ORG_TEXT,
    used_filenames=None,
):
    """Export one feature to its own PDF via ``MapLayoutEngine``.

    When ``include_satellite`` is True (default), renders an XYZ satellite
    basemap behind the lot boundary inside the standard double-line frame.
    When ``audit_record`` is provided (from harvest traceability audit),
    enriches the title and metadata with harvest status, detected harvest
    date, EUDR TMF status, and VN-2000 coordinates.

    Returns the output PDF path, or ``None`` if the export itself fails.
    """
    project = QgsProject.instance()

    id_lo = _fget(feat, field_map.get("id_lo")) or f"fid{feat.id()}"
    owner = _fget(feat, field_map.get("chu_ho"))

    temp_layer = _create_single_feature_layer(feat, layer_crs, "Phạm vi lô")
    _style_plot_layer(temp_layer)
    project.addMapLayer(temp_layer, False)

    bbox = feat.geometry().boundingBox()
    scale = _auto_scale(bbox, crs=layer_crs)
    if scale <= 5000:
        id_field = field_map.get("id_lo")
        if id_field:
            _apply_lot_labels(temp_layer, id_field)

    padded = QgsRectangle(bbox)
    pad_x, pad_y = _get_padding(bbox, layer_crs)
    padded.setXMinimum(bbox.xMinimum() - pad_x)
    padded.setXMaximum(bbox.xMaximum() + pad_x)
    padded.setYMinimum(bbox.yMinimum() - pad_y)
    padded.setYMaximum(bbox.yMaximum() + pad_y)

    sat_layer, sat_tif, s2_date_str = None, None, None
    h_date = audit_record.get("harvest_date") if audit_record else None
    if include_satellite and h_date is not None:
        sat_layer, sat_tif, s2_date_str = _create_sentinel2_date_basemap_layer(
            padded,
            layer_crs,
            h_date,
            stac_url=stac_url,
            offline_folder=offline_folder,
        )
    if sat_layer is None and include_satellite:
        sat_layer, sat_tif = _create_satellite_basemap_layer(padded, layer_crs)
    if sat_layer is not None:
        project.addMapLayer(sat_layer, False)

    study_area = _build_study_area(feat, field_map)
    coord_text = _format_centroid_vn2000(feat, layer_crs, lon_0_deg=lon_0_deg)

    if audit_record:
        title_text = "BẢN ĐỒ TRUY XUẤT NGUỒN GỐC LÔ RỪNG"
        trace_parts = [study_area] if study_area else []
        status = audit_record.get("status")
        if status:
            trace_parts.append(f"Hiện trạng: {status}")
        h_date = audit_record.get("harvest_date")
        if h_date:
            trace_parts.append(f"Ngày: {h_date}")
        tmf_status = audit_record.get("tmf_status")
        if tmf_status:
            trace_parts.append(f"EUDR: {tmf_status}")
        study_area = " | ".join(trace_parts)
    else:
        title_text = "BẢN ĐỒ LÔ CHỨNG CHỈ"

    crs_desc = (
        layer_crs.description() or layer_crs.authid()
        if layer_crs is not None and layer_crs.isValid()
        else "VN-2000"
    )
    eff_org = (org_name or "").strip() or BRAND_ORG_TEXT
    data_sources = f"{eff_org} | Hệ tọa độ: {crs_desc}"
    if coord_text:
        data_sources += f" | Tọa độ tâm: {coord_text}"
    if s2_date_str:
        data_sources += f" | Nền ảnh Sentinel-2 ngày {s2_date_str}"
    elif sat_layer is not None:
        data_sources += " | Nền ảnh vệ tinh"

    params = {
        "mode": "print",
        "lang": "VN",
        "page_width": 210,
        "page_height": 297,
        "scale": scale,
        "extent_mode": "drawn",
        "drawn_extent": padded,
        "title": title_text,
        "org_name": eff_org,
        "study_area": study_area,
        "data_sources": data_sources,
        "show_scalebar": True,
        "show_legend": False,
        "show_north": True,
        "signature_block": False,
    }

    layout = engine.create_layout(params)

    try:
        map_item = engine._find_item(layout, ITEM_IDS[("print", "VN")]["map"], QgsLayoutItemMap)
        if map_item is not None:
            map_item.setKeepLayerSet(True)
            if layer_crs is not None and layer_crs.isValid():
                map_item.setCrs(layer_crs)
            layers = [temp_layer, sat_layer] if sat_layer is not None else [temp_layer]
            map_item.setLayers(layers)
            map_item.zoomToExtent(padded)
            map_item.setScale(scale)
            layout.refresh()

        base_name = f"Lo_{_safe_filename(id_lo)}"
        if owner:
            base_name += f"_{_safe_filename(owner)}"
        filename = f"{base_name}_fid{feat.id()}.pdf"
        if used_filenames is not None:
            used_filenames.add(filename)
        pdf_path = os.path.join(output_dir, filename)

        exporter = QgsLayoutExporter(layout)
        settings = QgsLayoutExporter.PdfExportSettings()
        result = exporter.exportToPdf(pdf_path, settings)
    finally:
        project.layoutManager().removeLayout(layout)
        project.removeMapLayer(temp_layer.id())
        if sat_layer is not None:
            project.removeMapLayer(sat_layer.id())
        if sat_tif and os.path.exists(sat_tif):
            try:
                os.remove(sat_tif)
            except OSError:
                pass

    if result == QgsLayoutExporter.Success:
        return pdf_path

    QgsMessageLog.logMessage(
        f"Per-lot PDF export failed for {id_lo}: error code {result}",
        "CheckCCRQT", Qgis.Warning,
    )
    return None


def _merge_pdfs(pdf_paths, output_dir):
    """Merge multiple PDFs into one file using a multi-tier backend (BUG-11).

    Order: ``pypdf.PdfWriter`` -> ``PyPDF2.PdfWriter`` -> ``PyPDF2.PdfMerger``.
    Raises ``ImportError`` with clear install guidance if none is available.
    """
    writer_cls = None
    merger_cls = None
    try:
        from pypdf import PdfWriter as _PypdfWriter
        writer_cls = _PypdfWriter
    except ImportError:
        try:
            from PyPDF2 import PdfWriter as _PyPDF2Writer
            writer_cls = _PyPDF2Writer
        except ImportError:
            try:
                from PyPDF2 import PdfMerger as _PyPDF2Merger
                merger_cls = _PyPDF2Merger
            except ImportError as exc:
                raise ImportError(
                    "Thiếu thư viện gộp PDF (pypdf hoặc PyPDF2). "
                    "Vui lòng cài đặt trong OSGeo4W Shell: pip install pypdf"
                ) from exc

    n_plots = len(pdf_paths)
    ts = _dt.now().strftime('%d%m%Y_%H%M%S')
    merged_name = f"Xuat_{n_plots}_lo_gop_{ts}.pdf"
    merged_path = os.path.join(output_dir, merged_name)

    if writer_cls is not None:
        writer = writer_cls()
        try:
            for p in pdf_paths:
                writer.append(p)
            with open(merged_path, "wb") as out_fh:
                writer.write(out_fh)
        finally:
            try:
                writer.close()
            except Exception:
                pass
    else:
        merger = merger_cls()
        try:
            for p in pdf_paths:
                merger.append(p)
            merger.write(merged_path)
        finally:
            merger.close()

    for p in pdf_paths:
        try:
            if os.path.exists(p):
                os.remove(p)
        except OSError:
            pass

    return merged_path


def export_per_lot_maps(
    iface,
    plugin_dir: str,
    layer,
    features: list,
    field_map: dict,
    output_dir: str,
    merge: bool = True,
    include_satellite: bool = True,
    audit_records: dict = None,
    lon_0_deg: float = 106.0,
    stac_url: str = None,
    offline_folder: str = None,
    org_name: str = BRAND_ORG_TEXT,
    progress_callback=None,
    is_canceled=None,
) -> list:
    """Export one PDF per feature in ``features``, zoomed to each lot.

    Supports dynamic ``org_name`` (BUG-13), collision-free ``_fid{id}`` naming,
    progress reporting and user cancellation (BUG-12), and multi-tier PDF
    merging via ``pypdf``/``PyPDF2`` (BUG-11).
    """
    os.makedirs(output_dir, exist_ok=True)
    engine = MapLayoutEngine(iface, plugin_dir)
    layer_crs = layer.crs()
    records_by_id = audit_records or {}

    total = len(features)
    progress_dlg = None
    if progress_callback is None and total > 1:
        try:
            from qgis.PyQt.QtCore import Qt
            from qgis.PyQt.QtWidgets import QApplication, QProgressDialog

            parent_win = iface.mainWindow() if iface is not None else None
            progress_dlg = QProgressDialog(
                f"Đang xuất bản đồ {total} lô rừng...",
                "Hủy",
                0,
                total,
                parent_win,
            )
            progress_dlg.setWindowTitle("CheckCCRQT — Xuất bản đồ PDF")
            progress_dlg.setWindowModality(Qt.WindowModal)
            progress_dlg.setMinimumDuration(0)
            progress_dlg.show()
            QApplication.processEvents()
        except Exception:
            progress_dlg = None

    pdf_paths = []
    used_filenames = set()
    try:
        for idx, feat in enumerate(features, start=1):
            if callable(is_canceled) and is_canceled():
                break
            if progress_dlg is not None and progress_dlg.wasCanceled():
                break

            id_lo = _fget(feat, field_map.get("id_lo")) or f"fid{feat.id()}"
            audit_rec = records_by_id.get(id_lo)
            try:
                pdf_path = _export_single_lot(
                    engine,
                    feat,
                    layer_crs,
                    field_map,
                    output_dir,
                    include_satellite=include_satellite,
                    audit_record=audit_rec,
                    lon_0_deg=lon_0_deg,
                    stac_url=stac_url,
                    offline_folder=offline_folder,
                    org_name=org_name,
                    used_filenames=used_filenames,
                )
            except Exception as exc:
                QgsMessageLog.logMessage(
                    f"Per-lot export error for feature {feat.id()}: {exc}",
                    "CheckCCRQT", Qgis.Warning,
                )
                pdf_path = None
            if pdf_path:
                pdf_paths.append(pdf_path)

            if callable(progress_callback):
                try:
                    progress_callback(idx, total, id_lo)
                except Exception:
                    pass
            elif progress_dlg is not None:
                progress_dlg.setValue(idx)
                progress_dlg.setLabelText(f"Đã xuất {idx}/{total} lô (Lô: {id_lo})...")
                try:
                    from qgis.PyQt.QtWidgets import QApplication
                    QApplication.processEvents()
                except Exception:
                    pass
    finally:
        if progress_dlg is not None:
            progress_dlg.close()

    if merge and len(pdf_paths) > 1:
        merged = _merge_pdfs(pdf_paths, output_dir)
        return [merged]

    return pdf_paths
