# -*- coding: utf-8 -*-
"""Sentinel-2 RGB basemap & vector overlay generator for JRC TMF HTML reports.

Builds per-lot visual thumbnails ONLY for flagged lots ("Vi phạm" / "Cảnh báo"),
fetching the lowest-cloud Sentinel-2 L2A true-color scene from the lot's
detected deforestation year (via Earth Search STAC + GDAL /vsicurl/) and
computing SVG polygon coordinates for both the lot boundary and the post-2020
deforestation patches inside the lot.
"""

from __future__ import annotations

import base64
import concurrent.futures
import io
from datetime import date

import numpy as np

from ..core import sentinel_stac


_IMG_W = 460
_IMG_H = 340


def _stretch_channel(arr: np.ndarray) -> np.ndarray:
    """Stretch a Sentinel-2 reflectance band using 2-98% percentiles into uint8."""
    data = np.asarray(arr, dtype="float64")
    valid = data[np.isfinite(data) & (data > 0)]
    if valid.size == 0:
        return np.zeros(data.shape, dtype=np.uint8)
    p2, p98 = np.percentile(valid, (2, 98))
    if p98 <= p2:
        p98 = p2 + 1.0
    scaled = np.clip((data - p2) / (p98 - p2), 0.0, 1.0)
    # Slight gamma lift (0.85) keeps dense forest canopies readable.
    scaled = np.power(scaled, 0.85) * 255.0
    return scaled.astype(np.uint8)


def _padded_display_bbox(geom_wgs84):
    minx, miny, maxx, maxy = geom_wgs84.bounds
    span_x = max(maxx - minx, 0.0005)
    span_y = max(maxy - miny, 0.0005)
    pad_x = max(span_x * 0.45, 0.0018)
    pad_y = max(span_y * 0.45, 0.0018)
    # Match display aspect ratio (~460:340) so polygons never stretch.
    bx0, by0, bx1, by1 = minx - pad_x, miny - pad_y, maxx + pad_x, maxy + pad_y
    w = bx1 - bx0
    h = by1 - by0
    target_ratio = _IMG_W / float(_IMG_H)
    if w / max(h, 1e-9) < target_ratio:
        new_w = h * target_ratio
        dx = (new_w - w) / 2.0
        bx0 -= dx
        bx1 += dx
    else:
        new_h = w / target_ratio
        dy = (new_h - h) / 2.0
        by0 -= dy
        by1 += dy
    return (bx0, by0, bx1, by1)


def _coords_to_svg_points(coords, bbox):
    bx0, by0, bx1, by1 = bbox
    w = max(bx1 - bx0, 1e-9)
    h = max(by1 - by0, 1e-9)
    pts = []
    for lon, lat in coords:
        px = (lon - bx0) / w * _IMG_W
        py = (1.0 - (lat - by0) / h) * _IMG_H
        pts.append(f"{px:.1f},{py:.1f}")
    return " ".join(pts)


def _geom_to_svg_rings(geom, bbox):
    if geom is None or geom.is_empty:
        return []
    polys = [geom] if geom.geom_type == "Polygon" else list(getattr(geom, "geoms", []))
    rings = []
    for poly in polys:
        if poly.geom_type == "Polygon" and not poly.is_empty:
            rings.append(_coords_to_svg_points(poly.exterior.coords, bbox))
    return rings


def _fallback_bg_data_uri():
    from PIL import Image, ImageDraw

    img = Image.new("RGB", (_IMG_W, _IMG_H), (22, 38, 28))
    draw = ImageDraw.Draw(img)
    for x in range(0, _IMG_W, 46):
        draw.line([(x, 0), (x, _IMG_H)], fill=(30, 52, 38), width=1)
    for y in range(0, _IMG_H, 34):
        draw.line([(0, y), (_IMG_W, y)], fill=(30, 52, 38), width=1)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    b64 = base64.b64encode(buf.getvalue()).decode("ascii")
    return f"data:image/png;base64,{b64}"


def _render_sentinel_rgb_data_uri(scene, bbox):
    from PIL import Image

    red_href = scene.assets.get("red")
    green_href = scene.assets.get("green")
    blue_href = scene.assets.get("blue")
    if not (red_href and green_href and blue_href):
        return None

    r_arr, _ = sentinel_stac.read_band_window(red_href, bbox)
    g_arr, _ = sentinel_stac.read_band_window(green_href, bbox)
    b_arr, _ = sentinel_stac.read_band_window(blue_href, bbox)

    rgb = np.stack([
        _stretch_channel(r_arr),
        _stretch_channel(g_arr),
        _stretch_channel(b_arr),
    ], axis=-1)
    bicubic = getattr(Image, "Resampling", Image).BICUBIC
    img = Image.fromarray(rgb, mode="RGB").resize((_IMG_W, _IMG_H), bicubic)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    b64 = base64.b64encode(buf.getvalue()).decode("ascii")
    return f"data:image/png;base64,{b64}"


def _bboxes_overlap(b1, b2):
    return not (b1[2] < b2[0] or b1[0] > b2[2] or b1[3] < b2[1] or b1[1] > b2[3])


def build_tmf_visuals_for_records(
    tmf_records,
    stac_url=sentinel_stac.DEFAULT_STAC_URL,
    max_workers=6,
):
    """Fetch matching-year Sentinel-2 RGB basemaps & SVG overlays for flagged lots.

    Returns ``dict[id_lo, dict]``. Any network/STAC error gracefully falls
    back to a clean grid canvas so HTML export never fails.
    """
    flagged = [
        r for r in tmf_records
        if r.get("tmf_status") in ("Vi phạm", "Cảnh báo")
        and r.get("geometry_wgs84") is not None
    ]
    if not flagged:
        return {}

    current_year = date.today().year
    by_year = {}
    for rec in flagged:
        yr = rec.get("tmf_year")
        target_year = int(yr) if yr else min(2025, current_year)
        target_year = max(2016, min(current_year, target_year))
        by_year.setdefault(target_year, []).append(rec)

    scenes_by_year = {}
    for yr, group in by_year.items():
        bounds = [r["geometry_wgs84"].bounds for r in group]
        union_bbox = (
            min(b[0] for b in bounds),
            min(b[1] for b in bounds),
            max(b[2] for b in bounds),
            max(b[3] for b in bounds),
        )
        found = []
        # Prefer dry-season windows (Mar-Aug) with progressive cloud thresholds
        # 15% -> 30% -> 65%, then full-year fallback if needed (BUG-14).
        search_plan = [
            (date(yr, 3, 1), date(yr, 8, 31), 15),
            (date(yr, 3, 1), date(yr, 8, 31), 30),
            (date(yr, 3, 1), date(yr, 8, 31), 65),
            (date(yr, 1, 1), date(yr, 12, 31), 30),
            (date(yr, 1, 1), date(yr, 12, 31), 65),
        ]
        for d_from, d_to, max_cloud in search_plan:
            try:
                found = sentinel_stac.search_scenes(
                    union_bbox,
                    d_from,
                    d_to,
                    max_cloud=max_cloud,
                    limit=100,
                    stac_url=stac_url,
                    max_items=300,
                )
            except Exception:
                found = []
            if found:
                break
        rgb_scenes = [
            s for s in found
            if s.assets.get("red") and s.assets.get("green") and s.assets.get("blue")
        ]
        rgb_scenes.sort(key=lambda s: s.cloud_cover if s.cloud_cover is not None else 100.0)
        scenes_by_year[yr] = rgb_scenes

    fallback_uri = _fallback_bg_data_uri()

    def _build_one(rec):
        id_lo = rec.get("id_lo")
        geom = rec["geometry_wgs84"]
        yr = rec.get("tmf_year")
        target_year = int(yr) if yr else min(2025, current_year)
        target_year = max(2016, min(current_year, target_year))

        disp_bbox = _padded_display_bbox(geom)
        lot_rings = _geom_to_svg_rings(geom, disp_bbox)

        patch_svgs = []
        for patch in rec.get("loss_patches") or []:
            ext = patch.get("exterior") or []
            if len(ext) >= 3:
                pts_str = _coords_to_svg_points(ext, disp_bbox)
                xs = [float(p.split(",")[0]) for p in pts_str.split()]
                ys = [float(p.split(",")[1]) for p in pts_str.split()]
                cx = sum(xs) / len(xs)
                cy = sum(ys) / len(ys)
                patch_svgs.append({
                    "points": pts_str,
                    "year": patch.get("year") or yr or "",
                    "cx": round(cx, 1),
                    "cy": round(cy, 1),
                })

        img_uri = None
        scene_label = f"Không tải được ảnh Sentinel-2 ({target_year})"
        for scene in scenes_by_year.get(target_year, []):
            if getattr(scene, "bbox", None) is not None and not _bboxes_overlap(scene.bbox, disp_bbox):
                continue
            try:
                img_uri = _render_sentinel_rgb_data_uri(scene, disp_bbox)
                if img_uri:
                    cc = scene.cloud_cover if scene.cloud_cover is not None else 0.0
                    scene_label = f"Sentinel-2 RGB: {scene.datetime.strftime('%d/%m/%Y')} (Mây {cc:.0f}%)"
                    break
            except Exception:
                continue

        if not img_uri:
            img_uri = fallback_uri

        return id_lo, {
            "img_data_uri": img_uri,
            "scene_label": scene_label,
            "target_year": target_year,
            "width": _IMG_W,
            "height": _IMG_H,
            "lot_rings": lot_rings,
            "patch_svgs": patch_svgs,
        }

    visuals = {}
    workers = min(max(1, int(max_workers or 1)), len(flagged))
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
        futures = [pool.submit(_build_one, rec) for rec in flagged]
        for fut in concurrent.futures.as_completed(futures):
            try:
                id_lo, vis = fut.result()
                visuals[id_lo] = vis
            except Exception:
                pass
    return visuals
