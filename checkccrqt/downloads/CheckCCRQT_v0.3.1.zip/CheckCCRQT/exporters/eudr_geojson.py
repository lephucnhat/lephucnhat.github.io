# -*- coding: utf-8 -*-
"""EUDR-compliant GeoJSON exporter (RFC 7946 / EU TRACES NT).

Xuất hồ sơ định vị địa lý lô rừng trồng chứng chỉ theo Điều 9 Quy định
(EU) 2023/1115 (EUDR) và đặc tả GeoJSON RFC 7946:
  - Hệ tọa độ bắt buộc WGS-84 (EPSG:4326), thứ tự [longitude, latitude].
  - Loại bỏ tọa độ Z/M dư thừa (2D thuần).
  - Tự động sửa lỗi hình học nhẹ (tự cắt, vòng lặp) bằng ``buffer(0)``.
  - Làm tròn tọa độ đúng 6 chữ số thập phân (~11 cm).
  - Ép hướng vòng chuẩn RFC 7946: vòng ngoài ngược chiều kim đồng hồ (CCW),
    vòng lỗ thuận chiều kim đồng hồ (CW) qua ``shapely.geometry.polygon.orient``.
  - Phân ngưỡng diện tích 4,0 ha theo Điều 9 EUDR:
      * Lô >= 4,0 ha: BẮT BUỘC xuất dạng Polygon / MultiPolygon khép kín.
      * Lô <  4,0 ha: cho phép chọn xuất Polygon hoặc rút gọn thành Point
        (``representative_point()``) khi ``point_under_4ha=True``.

Author: Phòng Sử dụng và Phát triển rừng — Chi cục Kiểm lâm tỉnh Quảng Trị
License: GPL-3.0
"""

from __future__ import annotations

import json
import math
import os
from datetime import date

from shapely.geometry import MultiPolygon, Point, Polygon, mapping, shape
from shapely.geometry.polygon import orient as _orient_polygon

EUDR_POLYGON_THRESHOLD_HA = 4.0
DEFAULT_EXECUTING_UNIT = "Phòng Sử dụng và Phát triển rừng — Chi cục Kiểm lâm tỉnh Quảng Trị"


def _strip_zm_coords(coords):
    """Recursively drop Z/M dimensions and round coordinates to 6 decimals."""
    if not coords:
        return coords
    first = coords[0]
    if isinstance(first, (int, float)):
        return [round(float(coords[0]), 6), round(float(coords[1]), 6)]
    return [_strip_zm_coords(c) for c in coords]


def _force_2d_shapely(geom):
    """Convert any Shapely 2D/3D geometry to strict 2D."""
    if geom is None or geom.is_empty:
        return geom
    try:
        from shapely import force_2d
        return force_2d(geom)
    except Exception:
        pass
    geom_dict = mapping(geom)
    geom_dict["coordinates"] = _strip_zm_coords(geom_dict["coordinates"])
    return shape(geom_dict)


def _qgs_geom_to_shapely_wgs84(geom, source_crs=None):
    """Convert a QgsGeometry (reprojecting to EPSG:4326 if needed) to Shapely."""
    from qgis.core import (
        QgsCoordinateReferenceSystem,
        QgsCoordinateTransform,
        QgsGeometry,
        QgsProject,
    )

    g = QgsGeometry(geom)
    if source_crs is not None and source_crs.isValid():
        wgs84 = QgsCoordinateReferenceSystem.fromEpsgId(4326)
        if source_crs != wgs84:
            tr = QgsCoordinateTransform(source_crs, wgs84, QgsProject.instance())
            g.transform(tr)
    return shape(json.loads(g.asJson()))


def _to_shapely_wgs84(raw_geom, source_crs=None):
    """Normalize input geometry (Shapely / QgsGeometry / GeoJSON dict) to Shapely WGS-84."""
    if raw_geom is None:
        return None
    if isinstance(raw_geom, dict) and "type" in raw_geom:
        geom = shape(raw_geom)
    elif hasattr(raw_geom, "asJson"):
        geom = _qgs_geom_to_shapely_wgs84(raw_geom, source_crs=source_crs)
    else:
        geom = raw_geom
    if geom is None or geom.is_empty:
        return None
    geom = _force_2d_shapely(geom)
    if not geom.is_valid:
        geom = geom.buffer(0)
    if geom is None or geom.is_empty:
        return None
    return geom


def _orient_rfc7946(geom):
    """Enforce RFC 7946 winding order: exterior CCW (+1), interior holes CW."""
    if isinstance(geom, Polygon):
        return _orient_polygon(geom, sign=1.0)
    if isinstance(geom, MultiPolygon):
        oriented_parts = [_orient_polygon(p, sign=1.0) for p in geom.geoms if not p.is_empty]
        if len(oriented_parts) == 1:
            return oriented_parts[0]
        return MultiPolygon(oriented_parts)
    if hasattr(geom, "geoms"):
        polys = [
            _orient_polygon(g, sign=1.0)
            for g in geom.geoms
            if isinstance(g, Polygon) and not g.is_empty
        ]
        if len(polys) == 1:
            return polys[0]
        if len(polys) > 1:
            return MultiPolygon(polys)
    return geom


def _round_geojson_geometry(geom):
    """Serialize Shapely geometry to RFC 7946 GeoJSON dict with 6-decimal coords."""
    geo = mapping(geom)
    return {
        "type": geo["type"],
        "coordinates": _strip_zm_coords(geo["coordinates"]),
    }


def _estimate_area_ha_wgs84(geom):
    """Approximate geodesic/planar area in hectares for a WGS-84 polygon."""
    if geom is None or geom.is_empty or isinstance(geom, Point):
        return 0.0
    minx, miny, maxx, maxy = geom.bounds
    mean_lat = 0.5 * (miny + maxy)
    m_per_lon = 111320.0 * math.cos(math.radians(mean_lat))
    m_per_lat = 110574.0
    return round(abs(geom.area) * m_per_lon * m_per_lat / 10000.0, 4)


def _format_production_place(record):
    """Build standardized ProductionPlace string (ID lô / TK-Khoảnh-Lô)."""
    id_lo = str(record.get("id_lo") or "").strip()
    tk = str(record.get("tieu_khu") or "").strip()
    khoanh = str(record.get("khoanh") or "").strip()
    lo = str(record.get("lo") or "").strip()
    loc_parts = []
    if tk:
        loc_parts.append(f"TK {tk}")
    if khoanh:
        loc_parts.append(f"Khoảnh {khoanh}")
    if lo:
        loc_parts.append(f"Lô {lo}")
    loc_str = " - ".join(loc_parts)
    if id_lo and loc_str:
        return f"{id_lo} ({loc_str})"
    return id_lo or loc_str or "N/A"


def _resolve_area_ha(record, geom_wgs84):
    for key in ("dien_tich_bando", "area_ha", "Area", "dien_tich_kb"):
        val = record.get(key)
        if val is not None and val != "":
            try:
                num = float(val)
                if math.isfinite(num) and num >= 0:
                    return round(num, 4)
            except (TypeError, ValueError):
                pass
    return _estimate_area_ha_wgs84(geom_wgs84)


def build_eudr_feature_collection(
    records: list,
    point_under_4ha: bool = False,
    check_date: str | None = None,
    executing_unit: str | None = None,
    source_crs=None,
) -> dict:
    """Build an RFC 7946 / TRACES NT GeoJSON FeatureCollection dict from records."""
    eff_date = check_date or date.today().strftime("%Y-%m-%d")
    eff_unit = (executing_unit or "").strip() or DEFAULT_EXECUTING_UNIT

    features = []
    for rec in records:
        raw_geom = rec.get("geometry_wgs84")
        if raw_geom is None:
            raw_geom = rec.get("geometry")
        geom = _to_shapely_wgs84(raw_geom, source_crs=source_crs)
        if geom is None or geom.is_empty:
            continue

        area_ha = _resolve_area_ha(rec, geom)
        is_large = area_ha >= EUDR_POLYGON_THRESHOLD_HA

        if point_under_4ha and not is_large:
            out_geom = geom.representative_point()
            geom_rule = "EUDR Art.9 Point (< 4.0 ha)"
        else:
            out_geom = _orient_rfc7946(geom)
            geom_rule = (
                "EUDR Art.9 Polygon (>= 4.0 ha mandatory)"
                if is_large
                else "EUDR Art.9 Polygon (< 4.0 ha full boundary)"
            )

        geojson_geom = _round_geojson_geometry(out_geom)

        tmf_year = rec.get("tmf_year")
        tmf_ha = rec.get("tmf_ha")
        planted = rec.get("nam_trong")

        props = {
            "ProducerName": str(rec.get("chu_ho") or rec.get("ProducerName") or "").strip(),
            "ProducerCountry": "VN",
            "ProductionPlace": _format_production_place(rec),
            "Area": round(float(area_ha), 4),
            "Species": str(rec.get("loai_cay") or rec.get("Species") or "").strip(),
            "PlantedYear": int(planted) if isinstance(planted, (int, float)) and not isinstance(planted, bool) else (str(planted).strip() if planted else None),
            "EUDR_TMF_Status": str(rec.get("tmf_status") or rec.get("EUDR_TMF_Status") or "Chưa kiểm tra"),
            "EUDR_DeforestationYear": int(tmf_year) if tmf_year is not None and str(tmf_year).strip() != "" else None,
            "EUDR_AffectedHa": round(float(tmf_ha), 4) if tmf_ha is not None and str(tmf_ha).strip() != "" else 0.0,
            "EUDR_Driver": str(rec.get("tmf_driver") or rec.get("EUDR_Driver") or "").strip(),
            "GeometryRule": geom_rule,
            "CheckDate": eff_date,
            "ExecutingUnit": eff_unit,
        }

        features.append(
            {
                "type": "Feature",
                "id": str(rec.get("id_lo") or len(features) + 1),
                "geometry": geojson_geom,
                "properties": props,
            }
        )

    return {
        "type": "FeatureCollection",
        "name": "CheckCCRQT_EUDR_TRACES_NT",
        "features": features,
    }


def export_eudr_geojson(
    records: list,
    output_path: str,
    point_under_4ha: bool = False,
    check_date: str | None = None,
    executing_unit: str | None = None,
    source_crs=None,
) -> str:
    """Write an EUDR/TRACES NT compliant GeoJSON (RFC 7946) file to disk."""
    fc = build_eudr_feature_collection(
        records,
        point_under_4ha=point_under_4ha,
        check_date=check_date,
        executing_unit=executing_unit,
        source_crs=source_crs,
    )
    out_dir = os.path.dirname(os.path.abspath(output_path))
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as fh:
        json.dump(fc, fh, ensure_ascii=False, indent=2)
    return output_path
