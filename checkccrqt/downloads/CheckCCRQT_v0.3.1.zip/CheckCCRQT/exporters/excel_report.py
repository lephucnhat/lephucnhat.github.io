# -*- coding: utf-8 -*-
"""Excel (.xlsx) cycle report exporter (Task 13).

Produces a 2-sheet workbook from a list of audit record dicts (the shape
``self.last_audit_records`` holds on ``MainDialog`` — see Task 10/11):

``Input_Data``
    One header row + one row per record, with the ``Chênh lệch`` (area
    difference) and ``% Sai lệch`` (percentage deviation) columns as live
    Excel formulas referencing the declared/mapped-area columns on the same
    row — never Python-computed literals (user's global Excel Formulas Rule).

``Tong_Hop``
    One row per distinct ``status`` value present in ``records``, with
    ``COUNTIF``/``SUMIF`` formulas counting/summing ``Input_Data`` rows by
    status, plus a totals row summing those per-status formula rows.

``export_excel_report(records, output_path, period_label) -> str`` returns
``output_path`` for convenience.
"""

import openpyxl
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

#: Default author recorded on generated files (BUG-19: dynamic via org_name).
DEFAULT_AUTHOR = "Phòng Sử dụng và Phát triển rừng — Chi cục Kiểm lâm tỉnh Quảng Trị"

_HEADER_FILL = PatternFill(start_color="1B5E20", end_color="1B5E20", fill_type="solid")
_HEADER_FONT = Font(bold=True, color="FFFFFF")

#: (header label, record dict key or None for formula/derived columns), in
#: ``Input_Data`` column order (A..K).
_INPUT_COLUMNS = [
    ("Mã lô", "id_lo"),
    ("Chủ hộ", "chu_ho"),
    ("Tiểu khu", "tieu_khu"),
    ("Khoảnh", "khoanh"),
    ("Lô", "lo"),
    ("DT Khai báo", "dien_tich_kb"),
    ("DT Bản đồ", "dien_tich_bando"),
    ("Chênh lệch", None),  # H: =G{r}-F{r}
    ("% Sai lệch", None),  # I: =IF(F{r}=0,"",H{r}/F{r})
    ("Trạng thái", "status"),
    ("Ngày phát hiện", "harvest_date"),
    ("Trạng thái EUDR (TMF)", "tmf_status"),
    ("Năm mất rừng (TMF)", "tmf_year"),
    ("DT ảnh hưởng TMF (ha)", "tmf_ha"),
]

_COL_DT_KB = "F"
_COL_DT_BANDO = "G"
_COL_DIFF = "H"
_COL_PCT = "I"
_COL_STATUS = "J"


def _build_input_data_sheet(wb, records, period_label):
    ws = wb.create_sheet("Input_Data")
    ws.sheet_view.showGridLines = True

    ws["A1"] = f"Kỳ báo cáo: {period_label}"
    ws["A1"].font = Font(bold=True, color="1B5E20")

    header_row = 2
    for col_idx, (label, _key) in enumerate(_INPUT_COLUMNS, start=1):
        cell = ws.cell(row=header_row, column=col_idx, value=label)
        cell.fill = _HEADER_FILL
        cell.font = _HEADER_FONT
        cell.alignment = Alignment(horizontal="center")

    for offset, record in enumerate(records):
        r = header_row + 1 + offset
        ws[f"A{r}"] = record.get("id_lo")
        ws[f"B{r}"] = record.get("chu_ho")
        ws[f"C{r}"] = record.get("tieu_khu")
        ws[f"D{r}"] = record.get("khoanh")
        ws[f"E{r}"] = record.get("lo")
        ws[f"{_COL_DT_KB}{r}"] = record.get("dien_tich_kb")
        ws[f"{_COL_DT_BANDO}{r}"] = record.get("dien_tich_bando")
        ws[f"{_COL_DIFF}{r}"] = f"={_COL_DT_BANDO}{r}-{_COL_DT_KB}{r}"
        ws[f"{_COL_PCT}{r}"] = (
            f'=IF({_COL_DT_KB}{r}=0,"",{_COL_DIFF}{r}/{_COL_DT_KB}{r})'
        )
        ws[f"{_COL_STATUS}{r}"] = record.get("status")
        harvest_date = record.get("harvest_date")
        ws[f"K{r}"] = str(harvest_date) if harvest_date is not None else ""
        ws[f"L{r}"] = record.get("tmf_status") or ""
        tmf_year = record.get("tmf_year")
        ws[f"M{r}"] = tmf_year if tmf_year is not None else ""
        tmf_ha = record.get("tmf_ha")
        ws[f"N{r}"] = tmf_ha if tmf_ha is not None else ""

    for col_idx in range(1, len(_INPUT_COLUMNS) + 1):
        ws.column_dimensions[get_column_letter(col_idx)].width = 16

    return ws, header_row


def _build_tong_hop_sheet(wb, records, header_row, last_data_row):
    ws = wb.create_sheet("Tong_Hop")
    ws.sheet_view.showGridLines = True

    headers = ["Trạng thái", "Số lượng", "Tổng DT Bản đồ"]
    for col_idx, label in enumerate(headers, start=1):
        cell = ws.cell(row=1, column=col_idx, value=label)
        cell.fill = _HEADER_FILL
        cell.font = _HEADER_FONT
        cell.alignment = Alignment(horizontal="center")

    # Distinct statuses, in first-seen order (deterministic, matches input order).
    seen = []
    for record in records:
        status = record.get("status")
        if status not in seen:
            seen.append(status)

    # ``seen`` is derived from ``records``, so it is non-empty only when
    # ``records`` is non-empty, which in turn guarantees
    # ``last_data_row >= header_row + 1`` below — this range is always
    # valid whenever the loop body actually runs.
    status_col_range = f"Input_Data!{_COL_STATUS}{header_row + 1}:{_COL_STATUS}{last_data_row}"
    bando_col_range = f"Input_Data!{_COL_DT_BANDO}{header_row + 1}:{_COL_DT_BANDO}{last_data_row}"

    row = 2
    status_rows = []
    for status in seen:
        ws[f"A{row}"] = status
        ws[f"B{row}"] = f'=COUNTIF({status_col_range},A{row})'
        ws[f"C{row}"] = f'=SUMIF({status_col_range},A{row},{bando_col_range})'
        status_rows.append(row)
        row += 1

    # ``status_rows`` is non-empty whenever ``records`` is non-empty (it is
    # built 1:1 from the distinct statuses in ``records``), so a totals row
    # referencing an empty range can never occur — only add one when there
    # is at least one per-status row for it to sum.
    if status_rows:
        total_row = row
        first_r, last_r = status_rows[0], status_rows[-1]
        ws[f"A{total_row}"] = "Tổng cộng"
        ws[f"B{total_row}"] = f"=SUM(B{first_r}:B{last_r})"
        ws[f"C{total_row}"] = f"=SUM(C{first_r}:C{last_r})"
        ws[f"A{total_row}"].font = Font(bold=True)
        ws[f"B{total_row}"].font = Font(bold=True)
        ws[f"C{total_row}"].font = Font(bold=True)

    for col_idx in range(1, len(headers) + 1):
        ws.column_dimensions[get_column_letter(col_idx)].width = 22

    return ws


def export_excel_report(
    records: list,
    output_path: str,
    period_label: str,
    org_name: str = None,
) -> str:
    """Write the ``Input_Data``/``Tong_Hop`` cycle report workbook.

    Every calculated cell (Chênh lệch, % Sai lệch, counts, sums, totals) is a
    live Excel formula — nothing Python-computed is written into a calculated cell.
    """
    wb = openpyxl.Workbook()
    # Drop the default blank sheet openpyxl creates.
    default_sheet = wb.active
    wb.remove(default_sheet)

    author = (org_name or "").strip() or DEFAULT_AUTHOR
    wb.properties.creator = author
    wb.properties.lastModifiedBy = author

    ws_input, header_row = _build_input_data_sheet(wb, records, period_label)
    last_data_row = header_row + len(records)
    _build_tong_hop_sheet(wb, records, header_row, last_data_row)

    wb.save(output_path)
    return output_path


def export_tmf_excel_report(
    tmf_records: list,
    output_path: str,
    org_name: str = None,
) -> str:
    """Write a 3-sheet JRC TMF EUDR Excel workbook with live formulas.

    Sheets:
      1. ``JRC_TMF_ChiTiet``: full dataset including WGS84 centroid coords.
      2. ``Tong_Hop_EUDR``: COUNTIF/SUMIF summary by status.
      3. ``Vi phạm và cảnh báo``: formula-linked rows for non-compliant lots.
    """
    wb = openpyxl.Workbook()
    wb.remove(wb.active)
    author = (org_name or "").strip() or DEFAULT_AUTHOR
    wb.properties.creator = author
    wb.properties.lastModifiedBy = author

    ws_in = wb.create_sheet("JRC_TMF_ChiTiet")
    ws_in.sheet_view.showGridLines = True
    headers = [
        "Mã lô", "Chủ hộ", "Tiểu khu", "Khoảnh", "Lô", "DT Lô (ha)",
        "Trạng thái JRC TMF", "Năm mất rừng", "DT ảnh hưởng (ha)",
        "Loại rừng chủ đạo", "Nguyên nhân (Drivers)",
        "Vĩ độ (WGS84)", "Kinh độ (WGS84)",
    ]
    for c_idx, label in enumerate(headers, start=1):
        cell = ws_in.cell(row=1, column=c_idx, value=label)
        cell.fill = _HEADER_FILL
        cell.font = _HEADER_FONT
        cell.alignment = Alignment(horizontal="center")

    violation_source_rows = []
    for offset, rec in enumerate(tmf_records):
        r = 2 + offset
        ws_in[f"A{r}"] = rec.get("id_lo") or ""
        ws_in[f"B{r}"] = rec.get("chu_ho") or ""
        ws_in[f"C{r}"] = rec.get("tieu_khu") or ""
        ws_in[f"D{r}"] = rec.get("khoanh") or ""
        ws_in[f"E{r}"] = rec.get("lo") or ""
        dt_lot = rec.get("dien_tich_bando")
        ws_in[f"F{r}"] = round(float(dt_lot), 4) if dt_lot is not None else ""
        st = rec.get("tmf_status") or ""
        ws_in[f"G{r}"] = st
        yr = rec.get("tmf_year")
        ws_in[f"H{r}"] = yr if yr is not None else ""
        ha = rec.get("tmf_ha")
        ws_in[f"I{r}"] = round(float(ha), 4) if ha is not None else 0.0
        ws_in[f"J{r}"] = rec.get("tmf_dominant_class") or rec.get("dominant_class_vi") or ""
        ws_in[f"K{r}"] = rec.get("tmf_driver") or ""

        c_lat = rec.get("centroid_lat")
        c_lon = rec.get("centroid_lon")
        if (c_lat is None or c_lon is None) and rec.get("geometry_wgs84") is not None:
            geom = rec["geometry_wgs84"]
            if not getattr(geom, "is_empty", True):
                pt = geom.centroid
                c_lat, c_lon = pt.y, pt.x
        if c_lat is not None and c_lon is not None:
            ws_in[f"L{r}"] = round(float(c_lat), 6)
            ws_in[f"L{r}"].number_format = "0.000000"
            ws_in[f"M{r}"] = round(float(c_lon), 6)
            ws_in[f"M{r}"].number_format = "0.000000"
        else:
            ws_in[f"L{r}"] = ""
            ws_in[f"M{r}"] = ""

        if st != "Tuân thủ":
            violation_source_rows.append(r)

    for c_idx in range(1, len(headers) + 1):
        ws_in.column_dimensions[get_column_letter(c_idx)].width = 20

    ws_sum = wb.create_sheet("Tong_Hop_EUDR")
    ws_sum.sheet_view.showGridLines = True
    sum_headers = ["Trạng thái JRC TMF", "Số lô", "Tổng DT ảnh hưởng (ha)"]
    for c_idx, label in enumerate(sum_headers, start=1):
        cell = ws_sum.cell(row=1, column=c_idx, value=label)
        cell.fill = _HEADER_FILL
        cell.font = _HEADER_FONT
        cell.alignment = Alignment(horizontal="center")

    last_r = max(2, 1 + len(tmf_records))
    seen_statuses = []
    for rec in tmf_records:
        st = rec.get("tmf_status") or ""
        if st and st not in seen_statuses:
            seen_statuses.append(st)

    row_idx = 2
    for st in seen_statuses:
        ws_sum[f"A{row_idx}"] = st
        ws_sum[f"B{row_idx}"] = f"=COUNTIF(JRC_TMF_ChiTiet!G2:G{last_r},A{row_idx})"
        ws_sum[f"C{row_idx}"] = f"=SUMIF(JRC_TMF_ChiTiet!G2:G{last_r},A{row_idx},JRC_TMF_ChiTiet!I2:I{last_r})"
        row_idx += 1

    if seen_statuses:
        ws_sum[f"A{row_idx}"] = "Tổng cộng"
        ws_sum[f"B{row_idx}"] = f"=SUM(B2:B{row_idx - 1})"
        ws_sum[f"C{row_idx}"] = f"=SUM(C2:C{row_idx - 1})"
        for col in ("A", "B", "C"):
            ws_sum[f"{col}{row_idx}"].font = Font(bold=True)

    for c_idx in range(1, 4):
        ws_sum.column_dimensions[get_column_letter(c_idx)].width = 26

    # Sheet 3: Vi phạm và cảnh báo (formula-linked back to JRC_TMF_ChiTiet)
    ws_warn = wb.create_sheet("Vi phạm và cảnh báo")
    ws_warn.sheet_view.showGridLines = True
    warn_headers = [
        "STT", "Mã lô", "Chủ hộ", "Tiểu khu", "Khoảnh", "Lô", "DT Lô (ha)",
        "Trạng thái JRC TMF", "Năm mất rừng", "DT ảnh hưởng (ha)",
        "Loại rừng chủ đạo", "Nguyên nhân (Drivers)",
        "Vĩ độ (WGS84)", "Kinh độ (WGS84)",
    ]
    for c_idx, label in enumerate(warn_headers, start=1):
        cell = ws_warn.cell(row=1, column=c_idx, value=label)
        cell.fill = _HEADER_FILL
        cell.font = _HEADER_FONT
        cell.alignment = Alignment(horizontal="center")

    src_cols = ("A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M")
    for idx, src_r in enumerate(violation_source_rows, start=1):
        dst_r = 1 + idx
        ws_warn[f"A{dst_r}"] = idx
        ws_warn[f"A{dst_r}"].alignment = Alignment(horizontal="center")
        for col_offset, src_col in enumerate(src_cols):
            dst_col = get_column_letter(2 + col_offset)
            c = ws_warn[f"{dst_col}{dst_r}"]
            c.value = f"=JRC_TMF_ChiTiet!{src_col}{src_r}"
            if src_col in ("L", "M"):
                c.number_format = "0.000000"

    if violation_source_rows:
        tot_r = 2 + len(violation_source_rows)
        ws_warn[f"A{tot_r}"] = "Tổng"
        ws_warn[f"B{tot_r}"] = f"=COUNTA(B2:B{tot_r - 1})"
        ws_warn[f"G{tot_r}"] = f"=SUM(G2:G{tot_r - 1})"
        ws_warn[f"J{tot_r}"] = f"=SUM(J2:J{tot_r - 1})"
        for col in ("A", "B", "G", "J"):
            ws_warn[f"{col}{tot_r}"].font = Font(bold=True)
        note_r = tot_r + 2
    else:
        note_r = 3

    ws_warn[f"A{note_r}"] = (
        "Lưu ý EUDR: Khai thác rừng trồng keo đi trồng rừng keo mới theo chu kỳ không phải là vi phạm EUDR; "
        "cần đối chiếu hồ sơ khai thác hợp pháp và hiện trạng trồng lại rừng."
    )
    ws_warn[f"A{note_r}"].font = Font(italic=True, color="1B5E20")

    for c_idx in range(1, len(warn_headers) + 1):
        ws_warn.column_dimensions[get_column_letter(c_idx)].width = 20
    ws_warn.column_dimensions["A"].width = 8

    wb.save(output_path)
    return output_path
