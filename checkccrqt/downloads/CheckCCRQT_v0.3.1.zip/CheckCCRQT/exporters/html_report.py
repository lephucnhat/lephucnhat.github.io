# -*- coding: utf-8 -*-
"""Self-contained HTML validation report exporter.

``export_html_report`` renders a ``core.geometry_validator.ValidationResult``
into a single standalone HTML file (inline CSS + vanilla JS, no template
engine and no external library), so the user can open it directly in a
browser without any other assets.
"""

import base64
from datetime import datetime
import html as _html
import os

_DEFAULT_ORG_NAME = "Phòng Sử dụng và Phát triển rừng — Chi cục Kiểm lâm tỉnh Quảng Trị"
_EUDR_PLANTATION_NOTE = (
    "Cắt/khai thác rừng trồng keo đi trồng rừng keo mới theo chu kỳ không phải là vi phạm EUDR "
    "(không phải phá rừng chuyển đổi sang nông nghiệp hay chuyển đổi từ rừng tự nhiên sau 31/12/2020). "
    "Cần đối chiếu hồ sơ khai thác rừng trồng hợp pháp và hiện trạng trồng lại rừng tại thực địa."
)


def _extract_centroid_wgs84(rec):
    """Return ``(lat, lon)`` floats in WGS84 from ``rec`` or its ``geometry_wgs84``."""
    lat = rec.get("centroid_lat")
    lon = rec.get("centroid_lon")
    if lat is not None and lon is not None:
        try:
            return float(lat), float(lon)
        except (TypeError, ValueError):
            pass
    geom = rec.get("geometry_wgs84")
    if geom is not None and not getattr(geom, "is_empty", True):
        try:
            pt = geom.centroid
            return float(pt.y), float(pt.x)
        except Exception:
            pass
    return None, None


def _format_centroid_html(rec, compact=False) -> str:
    """Format lot centroid in WGS84 with 6 decimal places plus Google Maps link."""
    lat, lon = _extract_centroid_wgs84(rec)
    if lat is None or lon is None:
        return "—"
    lat_s = f"{lat:.6f}"
    lon_s = f"{lon:.6f}"
    url = f"https://www.google.com/maps?q={lat_s},{lon_s}"
    if compact:
        return (
            f'<span class="coord-val">{lat_s}, {lon_s}</span> '
            f'<a class="map-link" href="{url}" target="_blank" rel="noopener">[Bản đồ]</a>'
        )
    return (
        f'<span class="coord-val">Vĩ độ: <strong>{lat_s}°</strong> — '
        f'Kinh độ: <strong>{lon_s}°</strong></span> '
        f'<span class="crs-tag">(WGS84)</span> '
        f'<a class="map-link" href="{url}" target="_blank" rel="noopener">Xem Google Maps</a>'
    )


def _load_logo_data_uri(plugin_dir: str = "") -> str:
    """Return base64 PNG data URI for ``assets/logo_kiemlam.png`` if present."""
    root = plugin_dir or os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    logo_path = os.path.join(root, "assets", "logo_kiemlam.png")
    if not os.path.isfile(logo_path):
        return ""
    try:
        with open(logo_path, "rb") as handle:
            encoded = base64.b64encode(handle.read()).decode("ascii")
        return f"data:image/png;base64,{encoded}"
    except OSError:
        return ""


def _render_report_header(title: str, org_name: str, check_date: str, logo_uri: str) -> str:
    """Render report header block with emblem logo, title, org name and check date."""
    safe_title = _html.escape(title)
    safe_org = _html.escape(org_name or _DEFAULT_ORG_NAME)
    safe_date = _html.escape(check_date)
    logo_html = (
        f'<img class="report-logo" src="{logo_uri}" alt="Logo Kiểm lâm">'
        if logo_uri
        else ""
    )
    return (
        '<div class="report-header">'
        f"{logo_html}"
        '<div class="report-header-text">'
        f"<h1>{safe_title}</h1>"
        '<div class="report-meta">'
        f'<span><strong>Đơn vị thực hiện:</strong> {safe_org}</span>'
        '<span class="meta-sep">•</span>'
        f'<span><strong>Ngày kiểm tra:</strong> {safe_date}</span>'
        "</div>"
        "</div>"
        "</div>"
    )

# CheckCCRQT palette (Global Constraints).
_COLOR_PRIMARY = "#1B4D2E"
_COLOR_ACCENT = "#D4AF37"
_COLOR_BACKGROUND = "#F4F7F5"
_COLOR_BORDER = "#D0D7DE"
_COLOR_SUCCESS = "#2E7D32"
_COLOR_WARNING = "#E65100"
_COLOR_ERROR = "#C62828"

_SEVERITY_COLOR = {
    "error": _COLOR_ERROR,
    "warning": _COLOR_WARNING,
    "info": _COLOR_PRIMARY,
}

#: Vietnamese DISPLAY labels for ``core.geometry_validator.ISSUE_TYPES``
#: values and severities. Only what the user sees is translated -- the
#: underlying constant values (which other code branches on) are unchanged,
#: and the CSS class/filter keys below still use the raw codes.
ISSUE_TYPE_LABELS_VI = {
    "INVALID_GEOM": "Hình học không hợp lệ",
    "EMPTY_GEOM": "Hình học rỗng",
    "DUPLICATE_VERTEX": "Đỉnh trùng lặp",
    "DUPLICATE_ID": "Trùng mã lô",
    "SLIVER": "Lô mảnh vụn",
    "OVERLAP": "Chồng lấn",
    "GAP": "Khoảng trống",
    "MISSING_ATTR": "Thiếu dữ liệu thuộc tính",
    "AREA_MISMATCH": "Lệch diện tích",
}

SEVERITY_LABELS_VI = {
    "error": "Lỗi",
    "warning": "Cảnh báo",
    "info": "Thông tin",
}


def _issue_type_label(issue_type):
    return ISSUE_TYPE_LABELS_VI.get(str(issue_type), str(issue_type))


def _severity_label(severity):
    return SEVERITY_LABELS_VI.get(str(severity), str(severity))

_STYLE = f"""
    :root {{
        --primary: {_COLOR_PRIMARY};
        --accent: {_COLOR_ACCENT};
        --background: {_COLOR_BACKGROUND};
        --border: {_COLOR_BORDER};
        --success: {_COLOR_SUCCESS};
        --warning: {_COLOR_WARNING};
        --error: {_COLOR_ERROR};
    }}
    body {{
        font-family: Arial, "Segoe UI", sans-serif;
        background: var(--background);
        color: #1a1a1a;
        margin: 0;
        padding: 0 24px 24px 24px;
    }}
    .sticky-top {{
        position: sticky;
        top: 0;
        z-index: 100;
        background: var(--background);
        padding: 12px 0 8px 0;
        border-bottom: 2px solid var(--border);
        margin-bottom: 14px;
    }}
    h1 {{
        color: var(--primary);
        border-bottom: 3px solid var(--accent);
        padding-bottom: 8px;
        margin: 0 0 8px 0;
    }}
    .report-header {{
        display: flex;
        align-items: center;
        gap: 16px;
        background: #ffffff;
        border: 1px solid var(--border);
        border-left: 5px solid var(--primary);
        border-radius: 6px;
        padding: 12px 16px;
        margin-bottom: 16px;
    }}
    .report-logo {{
        height: 64px;
        width: auto;
        flex-shrink: 0;
    }}
    .report-header-text {{
        flex: 1;
        min-width: 0;
    }}
    .report-meta {{
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
        font-size: 13px;
        color: #334155;
        margin-top: 4px;
    }}
    .meta-sep {{
        color: #94a3b8;
    }}
    .summary-cards {{
        display: flex;
        flex-wrap: wrap;
        gap: 16px;
        margin: 24px 0;
    }}
    .card {{
        background: #ffffff;
        border: 1px solid var(--border);
        border-left: 6px solid var(--primary);
        border-radius: 6px;
        padding: 16px 20px;
        min-width: 160px;
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.08);
    }}
    .card .value {{
        font-size: 32px;
        font-weight: bold;
        color: var(--primary);
    }}
    .card .label {{
        font-size: 13px;
        color: #555555;
        margin-top: 4px;
    }}
    .filters {{
        display: flex;
        gap: 12px;
        margin: 16px 0;
    }}
    .filters input, .filters select {{
        padding: 8px;
        border: 1px solid var(--border);
        border-radius: 4px;
        font-size: 14px;
    }}
    table {{
        width: 100%;
        border-collapse: collapse;
        background: #ffffff;
    }}
    th, td {{
        border: 1px solid var(--border);
        padding: 8px 12px;
        text-align: left;
        font-size: 13px;
    }}
    th {{
        background: var(--primary);
        color: #ffffff;
    }}
    .severity-error {{ color: var(--error); font-weight: bold; }}
    .severity-warning {{ color: var(--warning); font-weight: bold; }}
    .severity-info {{ color: var(--primary); font-weight: bold; }}
"""


def _card(value, label):
    return (
        f'<div class="card"><div class="value">{value}</div>'
        f'<div class="label">{_html.escape(str(label))}</div></div>'
    )


def _issue_row(issue):
    id_lo = _html.escape(str(issue.id_lo))
    issue_type_code = _html.escape(str(issue.issue_type))
    issue_type_label = _html.escape(_issue_type_label(issue.issue_type))
    message = _html.escape(str(issue.message))
    severity_code = str(issue.severity)
    severity_label = _html.escape(_severity_label(severity_code))
    severity_class = f"severity-{severity_code}" if severity_code in _SEVERITY_COLOR else ""
    # data-type carries the raw code for the type filter; the cell shows
    # the Vietnamese label.
    return (
        f'<tr data-type="{issue_type_code}">'
        f"<td>{id_lo}</td>"
        f"<td>{issue_type_label}</td>"
        f"<td>{message}</td>"
        f'<td class="{severity_class}">{severity_label}</td>'
        "</tr>"
    )


def export_html_report(
    result,
    output_path: str,
    title: str = "Báo cáo kiểm tra CheckCCRQT",
    org_name: str = "",
    check_date: str = "",
) -> str:
    """Render ``result`` as a standalone HTML report and write it to ``output_path``.

    Returns ``output_path`` for convenience.
    """
    safe_title = _html.escape(title)
    resolved_org = (org_name or "").strip() or _DEFAULT_ORG_NAME
    resolved_date = (check_date or "").strip() or datetime.now().strftime("%d/%m/%Y %H:%M")
    header_html = _render_report_header(
        title, resolved_org, resolved_date, _load_logo_data_uri()
    )

    issue_types = sorted({issue.issue_type for issue in result.issues})
    type_options = "".join(
        f'<option value="{_html.escape(t)}">{_html.escape(_issue_type_label(t))}</option>'
        for t in issue_types
    )

    rows_html = "\n".join(_issue_row(issue) for issue in result.issues)

    summary_html = "".join(
        [
            _card(result.total, "Tổng số lô"),
            _card(result.ok_count, "Số lô đạt"),
            _card(result.geom_error_count, "Số lô lỗi hình học"),
            _card(result.missing_attr_count, "Số lô thiếu dữ liệu"),
            _card(result.area_mismatch_count, "Số lô lệch diện tích"),
        ]
    )

    document = f"""<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>{safe_title}</title>
<style>{_STYLE}</style>
</head>
<body>
<div class="sticky-top">
{header_html}

<div class="summary-cards">
{summary_html}
</div>

<div class="filters">
    <input type="text" id="filterText" placeholder="Lọc theo ID lô..." oninput="filterRows()">
    <select id="filterType" onchange="filterRows()">
        <option value="">Tất cả loại lỗi</option>
        {type_options}
    </select>
</div>
</div>

<table id="issuesTable">
    <thead>
        <tr>
            <th>ID lô</th>
            <th>Loại lỗi</th>
            <th>Mô tả</th>
            <th>Mức độ</th>
        </tr>
    </thead>
    <tbody>
{rows_html}
    </tbody>
</table>

<script>
function filterRows() {{
    var textFilter = document.getElementById('filterText').value.toLowerCase();
    var typeFilter = document.getElementById('filterType').value;
    var rows = document.getElementById('issuesTable').getElementsByTagName('tbody')[0].rows;
    for (var i = 0; i < rows.length; i++) {{
        var row = rows[i];
        var idLo = row.cells[0] ? row.cells[0].innerText.toLowerCase() : '';
        var issueType = row.getAttribute('data-type') || '';
        var matchesText = textFilter === '' || idLo.indexOf(textFilter) !== -1;
        var matchesType = typeFilter === '' || issueType === typeFilter;
        row.style.display = (matchesText && matchesType) ? '' : 'none';
    }}
}}
</script>
</body>
</html>
"""

    with open(output_path, "w", encoding="utf-8") as handle:
        handle.write(document)

    return output_path


def _fmt_ha(val):
    if val is None or val == "":
        return "0.0000"
    try:
        return f"{float(val):.4f}"
    except (TypeError, ValueError):
        return str(val)


def export_tmf_html_report(
    tmf_records,
    output_path,
    title="Báo cáo Kiểm tra JRC TMF (sau 31/12/2020)",
    visual_by_id=None,
    org_name="",
    check_date="",
):
    """Render 2-tab JRC TMF (EUDR 31/12/2020) HTML report:

    Tab 1: Tuân thủ (clean searchable table)
    Tab 2: Vi phạm & Cần check lại (Sentinel-2 basemap matching deforestation
           year, vectorized deforestation patch overlay, full lot details,
           and deforestation drivers).
    """
    visual_by_id = visual_by_id or {}
    total = len(tmf_records)
    compliant_recs = [r for r in tmf_records if r.get("tmf_status") == "Tuân thủ"]
    review_recs = [r for r in tmf_records if r.get("tmf_status") != "Tuân thủ"]
    compliant = len(compliant_recs)
    warning = sum(1 for r in tmf_records if r.get("tmf_status") == "Cảnh báo")
    violation = sum(1 for r in tmf_records if r.get("tmf_status") == "Vi phạm")

    def _status_color(status):
        if status == "Vi phạm":
            return _COLOR_ERROR
        if status == "Cảnh báo":
            return _COLOR_WARNING
        if status == "Tuân thủ":
            return _COLOR_SUCCESS
        return _COLOR_PRIMARY

    def _loc_label(rec):
        parts = []
        if rec.get("tieu_khu"):
            parts.append(f"TK {rec['tieu_khu']}")
        if rec.get("khoanh"):
            parts.append(f"K {rec['khoanh']}")
        if rec.get("lo"):
            parts.append(f"Lô {rec['lo']}")
        return " / ".join(parts) if parts else "—"

    # Tab 1: Compliant table rows
    compliant_rows_html = []
    for idx, rec in enumerate(compliant_recs, 1):
        id_lo = str(rec.get("id_lo") or "")
        chu_ho = str(rec.get("chu_ho") or "")
        loc = _loc_label(rec)
        coord_compact_html = _format_centroid_html(rec, compact=True)
        dt_lot = rec.get("dien_tich_bando")
        dt_lot_str = _fmt_ha(dt_lot) if dt_lot is not None else "—"
        dom = str(rec.get("tmf_dominant_class") or rec.get("dominant_class_vi") or "")
        compliant_rows_html.append(
            f"<tr>"
            f'<td style="text-align:center;">{idx}</td>'
            f"<td><strong>{_html.escape(id_lo)}</strong></td>"
            f"<td>{_html.escape(chu_ho)}</td>"
            f"<td>{_html.escape(loc)}</td>"
            f'<td style="white-space:nowrap;">{coord_compact_html}</td>'
            f'<td style="text-align:right;">{_html.escape(dt_lot_str)}</td>'
            f'<td style="color:{_COLOR_SUCCESS};font-weight:bold;">Tuân thủ</td>'
            f"<td>{_html.escape(dom)}</td>"
            f"</tr>"
        )
    compliant_tbody = "\n".join(compliant_rows_html) if compliant_rows_html else (
        '<tr><td colspan="8" style="text-align:center;color:#666;padding:18px;">Không có lô nào thuộc nhóm Tuân thủ.</td></tr>'
    )

    # Tab 2: Violation & Warning (Cần check lại) cards + year options
    years_seen = sorted({
        str(r.get("tmf_year"))
        for r in review_recs
        if r.get("tmf_year") is not None and str(r.get("tmf_year")).strip() != ""
    })
    year_options_html = "\n".join(
        f'<option value="{_html.escape(y)}">Năm { _html.escape(y) }</option>'
        for y in years_seen
    )

    review_cards_html = []
    for idx, rec in enumerate(review_recs, 1):
        id_lo = str(rec.get("id_lo") or "")
        chu_ho = str(rec.get("chu_ho") or "")
        st = str(rec.get("tmf_status") or "")
        yr = "" if rec.get("tmf_year") is None else str(rec.get("tmf_year"))
        ha_str = _fmt_ha(rec.get("tmf_ha"))
        dt_lot = rec.get("dien_tich_bando")
        dt_lot_str = _fmt_ha(dt_lot) if dt_lot is not None else "—"
        dom = str(rec.get("tmf_dominant_class") or rec.get("dominant_class_vi") or "Không xác định")
        driver = str(rec.get("tmf_driver") or "Chưa xác định nguyên nhân cụ thể (cần đối chiếu thực địa)")
        loc = _loc_label(rec)
        coord_html = _format_centroid_html(rec, compact=False)
        color = _status_color(st)
        badge_bg = "#FEE2E2" if st == "Vi phạm" else ("#FEF3C7" if st == "Cảnh báo" else "#E2E8F0")

        vis = visual_by_id.get(id_lo)
        if vis:
            w = vis["width"]
            h = vis["height"]
            lot_polys_svg = "".join(
                f'<polygon points="{pts}" fill="rgba(0,255,102,0.08)" '
                f'stroke="#00FF66" stroke-width="2.5" vector-effect="non-scaling-stroke"/>'
                for pts in vis.get("lot_rings", [])
            )
            patch_polys_svg = "".join(
                f'<polygon points="{p["points"]}" fill="rgba(220,38,38,0.48)" '
                f'stroke="#FF2222" stroke-width="2" vector-effect="non-scaling-stroke"/>'
                f'<text x="{p["cx"]}" y="{p["cy"]}" fill="#FFFFFF" stroke="#000000" '
                f'stroke-width="2.5" paint-order="stroke" font-size="12" font-weight="bold" '
                f'text-anchor="middle" dominant-baseline="central">{_html.escape(str(p.get("year", "")))}</text>'
                for p in vis.get("patch_svgs", [])
            )
            map_block = (
                f'<div class="map-box">'
                f'<div class="map-header">'
                f'<span><strong>{_html.escape(id_lo)}</strong> — {_html.escape(chu_ho)}</span>'
                f'<span class="scene-tag">{_html.escape(vis["scene_label"])}</span>'
                f'</div>'
                f'<div class="svg-wrap">'
                f'<img src="{vis["img_data_uri"]}" alt="Sentinel-2 {_html.escape(id_lo)}"/>'
                f'<svg viewBox="0 0 {w} {h}" preserveAspectRatio="none">'
                f'{lot_polys_svg}{patch_polys_svg}'
                f'</svg>'
                f'<div class="map-overlay-label">{_html.escape(id_lo)} ({_html.escape(dt_lot_str)} ha)</div>'
                f'</div>'
                f'<div class="map-legend">'
                f'<span><i class="swatch-lot"></i> Ranh giới lô</span>'
                f'<span><i class="swatch-loss"></i> Phạm vi mất rừng sau 31/12/2020</span>'
                f'</div>'
                f'</div>'
            )
        else:
            map_block = (
                f'<div class="map-box map-empty">'
                f'<div>Không có hình học/ảnh Sentinel-2 cho lô <strong>{_html.escape(id_lo)}</strong></div>'
                f'</div>'
            )

        if st == "Vi phạm":
            advice = (
                "Đối chiếu hồ sơ khai thác rừng trồng hợp pháp / rà soát thực địa tại vệt mất rừng màu đỏ "
                "(tác động vào rừng đạt chuẩn FAO ≥ 0,5 ha, tàn che ≥ 10%, cao ≥ 5 m dù nhỏ vẫn vi phạm; "
                "riêng rừng trồng keo luân canh không phải là phá rừng)."
            )
        else:
            advice = "Kiểm tra ranh giới quy hoạch 3 loại rừng và hiện trạng thực địa."

        review_cards_html.append(
            f'<div class="review-card" data-status="{_html.escape(st)}" '
            f'data-year="{_html.escape(yr)}" '
            f'data-search="{_html.escape((id_lo + " " + chu_ho + " " + loc + " " + driver).lower())}">'
            f'<div class="review-grid">'
            f'{map_block}'
            f'<div class="info-box">'
            f'<div class="info-top">'
            f'<span class="card-idx">#{idx}</span>'
            f'<span class="lot-title">{_html.escape(id_lo)}</span>'
            f'<span class="status-badge" style="color:{color};background:{badge_bg};border:1px solid {color};">{_html.escape(st)}</span>'
            f'</div>'
            f'<table class="meta-table">'
            f'<tr><th>Chủ hộ:</th><td><strong>{_html.escape(chu_ho or "—")}</strong></td></tr>'
            f'<tr><th>Vị trí lô:</th><td>{_html.escape(loc)}</td></tr>'
            f'<tr><th>Diện tích lô:</th><td>{_html.escape(dt_lot_str)} ha</td></tr>'
            f'<tr><th>Năm mất rừng:</th><td style="color:{color};font-weight:bold;">{_html.escape(yr or "—")}</td></tr>'
            f'<tr><th>DT mất rừng / ảnh hưởng:</th><td style="color:{color};font-weight:bold;">{_html.escape(ha_str)} ha</td></tr>'
            f'<tr><th>Tọa độ tâm (WGS84):</th><td>{coord_html}</td></tr>'
            f'<tr><th>Lớp phủ chủ đạo:</th><td>{_html.escape(dom)}</td></tr>'
            f'<tr><th>Nguyên nhân (Drivers):</th><td class="driver-cell">{_html.escape(driver)}</td></tr>'
            f'<tr><th>Khuyến nghị xử lý:</th><td>{_html.escape(advice)}</td></tr>'
            f'</table>'
            f'<div class="eudr-note"><strong>Lưu ý EUDR:</strong> {_html.escape(_EUDR_PLANTATION_NOTE)}</div>'
            f'</div>'
            f'</div>'
            f'</div>'
        )

    review_cards_block = "\n".join(review_cards_html) if review_cards_html else (
        '<div class="empty-review">Không phát hiện lô Vi phạm hay Cảnh báo cần kiểm tra lại.</div>'
    )

    esc_title = _html.escape(title)
    review_count = len(review_recs)
    resolved_org = (org_name or "").strip() or _DEFAULT_ORG_NAME
    resolved_date = (check_date or "").strip() or datetime.now().strftime("%d/%m/%Y %H:%M")
    header_html = _render_report_header(
        title, resolved_org, resolved_date, _load_logo_data_uri()
    )

    document = f"""<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="utf-8">
<title>{esc_title}</title>
<style>
body {{ font-family: Arial, "Segoe UI", sans-serif; background: {_COLOR_BACKGROUND}; color: #1a1a1a; margin: 0; padding: 0 24px 24px 24px; }}
.sticky-top {{ position: sticky; top: 0; z-index: 100; background: {_COLOR_BACKGROUND}; padding: 12px 0 8px 0; border-bottom: 2px solid {_COLOR_BORDER}; margin-bottom: 14px; box-shadow: 0 3px 10px rgba(0,0,0,0.05); }}
h1 {{ color: {_COLOR_PRIMARY}; border-bottom: 3px solid {_COLOR_ACCENT}; padding-bottom: 6px; margin: 0 0 6px 0; font-size: 20px; }}
.report-header {{ display: flex; align-items: center; gap: 14px; background: #ffffff; border: 1px solid {_COLOR_BORDER}; border-left: 5px solid {_COLOR_PRIMARY}; border-radius: 6px; padding: 8px 14px; margin-bottom: 10px; }}
.report-logo {{ height: 52px; width: auto; flex-shrink: 0; }}
.report-header-text {{ flex: 1; min-width: 0; }}
.report-meta {{ display: flex; flex-wrap: wrap; gap: 10px; font-size: 13px; color: #334155; margin-top: 2px; }}
.meta-sep {{ color: #94a3b8; }}
.cards {{ display: flex; flex-wrap: wrap; gap: 10px; margin: 8px 0; }}
.card {{ background: #ffffff; border: 1px solid {_COLOR_BORDER}; border-top: 4px solid {_COLOR_PRIMARY}; border-radius: 6px; padding: 8px 14px; min-width: 150px; cursor: pointer; transition: transform 0.1s; }}
.card:hover {{ transform: translateY(-1px); }}
.card .value {{ font-size: 22px; font-weight: bold; color: {_COLOR_PRIMARY}; }}
.card .label {{ font-size: 12px; color: #555; margin-top: 2px; }}
.tabs-bar {{ display: flex; gap: 8px; margin: 10px 0 8px 0; border-bottom: 2px solid {_COLOR_BORDER}; }}
.tab-btn {{ padding: 8px 16px; border: 1px solid {_COLOR_BORDER}; border-bottom: none; border-radius: 6px 6px 0 0; background: #e8eef0; color: #334155; font-weight: bold; font-size: 13px; cursor: pointer; }}
.tab-btn.active {{ background: {_COLOR_PRIMARY}; color: #ffffff; border-color: {_COLOR_PRIMARY}; }}
.tab-btn.tab-alert.active {{ background: {_COLOR_ERROR}; border-color: {_COLOR_ERROR}; }}
.tab-panel {{ display: none; }}
.tab-panel.active {{ display: block; }}
.controls {{ margin: 6px 0 2px 0; display: flex; gap: 12px; flex-wrap: wrap; align-items: center; }}
.controls input, .controls select {{ padding: 7px 10px; border: 1px solid {_COLOR_BORDER}; border-radius: 4px; font-size: 13px; background: #ffffff; }}
.controls input {{ min-width: 260px; }}
.coord-val {{ font-family: Consolas, "Courier New", monospace; font-size: 12px; color: #0f172a; }}
.crs-tag {{ font-size: 11px; color: #64748b; }}
.map-link {{ font-size: 11px; color: {_COLOR_PRIMARY}; font-weight: 600; text-decoration: none; margin-left: 4px; }}
.map-link:hover {{ text-decoration: underline; }}
.eudr-note {{ margin-top: 10px; padding: 9px 12px; background: #f0fdf4; border: 1px solid #bbf7d0; border-left: 4px solid {_COLOR_SUCCESS}; border-radius: 5px; font-size: 12.5px; line-height: 1.45; color: #14532d; }}
table.data-table {{ width: 100%; border-collapse: collapse; background: #ffffff; }}
table.data-table th, table.data-table td {{ border: 1px solid {_COLOR_BORDER}; padding: 8px 10px; text-align: left; font-size: 13px; }}
table.data-table th {{ background: {_COLOR_PRIMARY}; color: #ffffff; }}
table.data-table tr:nth-child(even) {{ background: #f8faf8; }}
.review-card {{ background: #ffffff; border: 1px solid {_COLOR_BORDER}; border-radius: 8px; padding: 14px; margin-bottom: 16px; box-shadow: 0 1px 4px rgba(0,0,0,0.06); }}
.review-grid {{ display: grid; grid-template-columns: 460px 1fr; gap: 18px; align-items: start; }}
@media (max-width: 960px) {{ .review-grid {{ grid-template-columns: 1fr; }} }}
.map-box {{ border: 1px solid #cbd5e1; border-radius: 6px; overflow: hidden; background: #0f172a; }}
.map-header {{ display: flex; justify-content: space-between; align-items: center; gap: 8px; padding: 6px 10px; background: #1e293b; color: #f8fafc; font-size: 12px; }}
.scene-tag {{ background: rgba(255,255,255,0.14); padding: 2px 7px; border-radius: 4px; font-size: 11px; white-space: nowrap; }}
.svg-wrap {{ position: relative; width: 100%; aspect-ratio: 460 / 340; background: #16261c; }}
.svg-wrap img, .svg-wrap svg {{ position: absolute; inset: 0; width: 100%; height: 100%; display: block; }}
.map-overlay-label {{ position: absolute; left: 8px; bottom: 8px; background: rgba(15,23,42,0.78); color: #00FF66; padding: 3px 8px; border-radius: 4px; font-size: 11px; font-weight: bold; border: 1px solid rgba(0,255,102,0.5); }}
.map-legend {{ display: flex; gap: 16px; padding: 6px 10px; background: #f8fafc; border-top: 1px solid #e2e8f0; font-size: 11px; color: #334155; }}
.swatch-lot {{ display: inline-block; width: 12px; height: 10px; border: 2px solid #00AA44; background: rgba(0,255,102,0.15); vertical-align: middle; margin-right: 4px; }}
.swatch-loss {{ display: inline-block; width: 12px; height: 10px; border: 2px solid #DC2626; background: rgba(220,38,38,0.45); vertical-align: middle; margin-right: 4px; }}
.map-empty {{ min-height: 200px; display: flex; align-items: center; justify-content: center; color: #cbd5e1; padding: 16px; text-align: center; }}
.info-top {{ display: flex; align-items: center; gap: 10px; margin-bottom: 10px; padding-bottom: 8px; border-bottom: 1px solid #e2e8f0; flex-wrap: wrap; }}
.card-idx {{ background: #e2e8f0; color: #334155; font-weight: bold; font-size: 12px; padding: 2px 8px; border-radius: 4px; }}
.lot-title {{ font-size: 17px; font-weight: bold; color: {_COLOR_PRIMARY}; }}
.status-badge {{ font-size: 12px; font-weight: bold; padding: 3px 10px; border-radius: 12px; margin-left: auto; }}
.meta-table {{ width: 100%; border-collapse: collapse; font-size: 13px; }}
.meta-table th {{ width: 175px; text-align: left; padding: 5px 8px 5px 0; color: #475569; vertical-align: top; font-weight: 600; border-bottom: 1px solid #f1f5f9; }}
.meta-table td {{ padding: 5px 0; color: #0f172a; border-bottom: 1px solid #f1f5f9; }}
.driver-cell {{ color: #9a3412; font-weight: 600; }}
.empty-review {{ background: #ffffff; border: 1px solid {_COLOR_BORDER}; padding: 24px; text-align: center; border-radius: 6px; color: #475569; }}
</style>
</head>
<body>
<div class="sticky-top">
{header_html}
<div class="cards">
    <div class="card" onclick="switchTab('compliant')"><div class="value">{total}</div><div class="label">Tổng số lô kiểm tra</div></div>
    <div class="card" onclick="switchTab('compliant')" style="border-top-color:{_COLOR_SUCCESS};"><div class="value" style="color:{_COLOR_SUCCESS};">{compliant}</div><div class="label">Tuân thủ</div></div>
    <div class="card" onclick="openReviewFiltered('Cảnh báo')" style="border-top-color:{_COLOR_WARNING};"><div class="value" style="color:{_COLOR_WARNING};">{warning}</div><div class="label">Cảnh báo cần check lại</div></div>
    <div class="card" onclick="openReviewFiltered('Vi phạm')" style="border-top-color:{_COLOR_ERROR};"><div class="value" style="color:{_COLOR_ERROR};">{violation}</div><div class="label">Vi phạm sau 31/12/2020</div></div>
</div>

<div class="tabs-bar">
    <button id="btnTabReview" class="tab-btn tab-alert active" onclick="switchTab('review')">⚠️ Vi phạm &amp; Cần check lại ({review_count})</button>
    <button id="btnTabCompliant" class="tab-btn" onclick="switchTab('compliant')">✅ Tuân thủ ({compliant})</button>
</div>

<div id="controlsReview" class="controls">
    <input type="text" id="filterReviewText" placeholder="Tìm theo Mã lô, Chủ hộ, Tiểu khu, Nguyên nhân..." oninput="filterReviewCards()">
    <select id="filterReviewStatus" onchange="filterReviewCards()">
        <option value="">-- Tất cả Vi phạm &amp; Cảnh báo --</option>
        <option value="Vi phạm">Chỉ Vi phạm sau 31/12/2020</option>
        <option value="Cảnh báo">Chỉ Cảnh báo</option>
    </select>
    <select id="filterReviewYear" onchange="filterReviewCards()">
        <option value="">-- Tất cả năm mất rừng --</option>
        {year_options_html}
    </select>
    <span id="reviewCountShown" style="font-size:13px;color:#475569;"></span>
</div>

<div id="controlsCompliant" class="controls" style="display:none;">
    <input type="text" id="filterCompliantText" placeholder="Tìm lô Tuân thủ theo Mã lô, Chủ hộ, Tiểu khu..." oninput="filterCompliantRows()">
</div>
</div>

<div id="tabReview" class="tab-panel active">
    <div id="reviewList">
{review_cards_block}
    </div>
</div>

<div id="tabCompliant" class="tab-panel">
    <div class="eudr-note" style="margin:0 0 12px 0;"><strong>Lưu ý EUDR:</strong> {_html.escape(_EUDR_PLANTATION_NOTE)}</div>
    <table class="data-table" id="compliantTable">
        <thead>
            <tr>
                <th style="text-align:center;width:55px;">STT</th>
                <th>Mã lô</th>
                <th>Chủ hộ</th>
                <th>Vị trí (TK/K/Lô)</th>
                <th>Tọa độ tâm (WGS84)</th>
                <th style="text-align:right;">Diện tích (ha)</th>
                <th>Trạng thái JRC TMF</th>
                <th>Lớp phủ chủ đạo</th>
            </tr>
        </thead>
        <tbody>
{compliant_tbody}
        </tbody>
    </table>
</div>

<script>
function switchTab(name) {{
    var isReview = (name === 'review');
    document.getElementById('tabReview').classList.toggle('active', isReview);
    document.getElementById('tabCompliant').classList.toggle('active', !isReview);
    document.getElementById('btnTabReview').classList.toggle('active', isReview);
    document.getElementById('btnTabCompliant').classList.toggle('active', !isReview);
    document.getElementById('controlsReview').style.display = isReview ? 'flex' : 'none';
    document.getElementById('controlsCompliant').style.display = isReview ? 'none' : 'flex';
}}
function openReviewFiltered(st) {{
    switchTab('review');
    document.getElementById('filterReviewStatus').value = st;
    filterReviewCards();
}}
function filterReviewCards() {{
    var q = document.getElementById('filterReviewText').value.toLowerCase();
    var st = document.getElementById('filterReviewStatus').value;
    var yr = document.getElementById('filterReviewYear').value;
    var cards = document.querySelectorAll('#reviewList .review-card');
    var shown = 0;
    for (var i = 0; i < cards.length; i++) {{
        var c = cards[i];
        var hay = c.getAttribute('data-search') || '';
        var cst = c.getAttribute('data-status') || '';
        var cyr = c.getAttribute('data-year') || '';
        var ok = (q === '' || hay.indexOf(q) !== -1) &&
                 (st === '' || cst === st) &&
                 (yr === '' || cyr === yr);
        c.style.display = ok ? '' : 'none';
        if (ok) shown++;
    }}
    var el = document.getElementById('reviewCountShown');
    if (el) el.textContent = 'Đang hiển thị ' + shown + ' / ' + cards.length + ' lô';
}}
function filterCompliantRows() {{
    var q = document.getElementById('filterCompliantText').value.toLowerCase();
    var rows = document.getElementById('compliantTable').getElementsByTagName('tbody')[0].rows;
    for (var i = 0; i < rows.length; i++) {{
        var row = rows[i];
        var txt = (row.innerText || '').toLowerCase();
        row.style.display = (q === '' || txt.indexOf(q) !== -1) ? '' : 'none';
    }}
}}
filterReviewCards();
</script>
</body>
</html>
"""
    with open(output_path, "w", encoding="utf-8") as handle:
        handle.write(document)
    return output_path
