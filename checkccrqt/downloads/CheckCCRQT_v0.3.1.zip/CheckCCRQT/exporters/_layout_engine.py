# -*- coding: utf-8 -*-
"""CheckCCRQT map layout engine — ported from the sibling plugin LVTLayout.

This module is a direct, trimmed port of
``LVTLayout\\layout_engine\\engine.py``'s ``LvtEngine`` class (Task 14).
LVTLayout is a sibling plugin, not a runtime dependency: this file is a
*copy*, adapted in three ways:

1. ``TEMPLATES``/``ITEM_IDS`` are restricted to a single entry —
   ``("print", "VN")`` — pointing at this plugin's own
   ``templates/Khung_CheckCCRQT_02Line.qpt`` (a byte-identical copy of
   LVTLayout's ``Khung LVT2601_print_27Apr2026_VN.qpt`` double-line frame
   template). The slide/EN template variants are out of scope for
   CheckCCRQT and have been dropped.
2. ``create_layout`` gains one extra step (``_apply_branding``) that runs
   right after label updates: it writes the CheckCCRQT title text (already
   covered by the existing ``_set_label`` label-override mechanism via the
   ``"title"`` param) and repoints/creates a logo picture item to
   ``assets/logo_kiemlam.png``. See the docstring on ``_apply_branding``
   for why a *new* picture item is created rather than an existing one
   being repointed.
3. The legend renderer (``add_legend_block``) is ported separately into
   ``exporters/_legend.py`` (a near-verbatim copy of LVTLayout's
   ``layout_engine/legend.py``) and imported from here, per the task
   brief's "or a private helper module it imports" option.

Everything else — the template-load/refresh/rescale/label/legend-toggle
pipeline, the signature-block helper, the extent-resolution logic — is
unchanged from ``LvtEngine``.
"""

import os

from qgis.PyQt.QtXml import QDomDocument
from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import (
    QgsProject,
    QgsPrintLayout,
    QgsReadWriteContext,
    QgsLayoutItemMap,
    QgsLayoutItemLabel,
    QgsLayoutItemLegend,
    QgsLayoutItemPicture,
    QgsLayoutObject,
    QgsLayoutPoint,
    QgsLayoutSize,
    QgsProperty,
    QgsUnitTypes,
)


# Template file mapping: (mode, lang) -> filename.
# Only the print/VN double-line frame is in scope for CheckCCRQT (the
# slide/EN variants from LVTLayout were dropped per the task brief).
TEMPLATES = {
    ("print", "VN"): "Khung_CheckCCRQT_02Line.qpt",
}

# Element IDs that the engine may update (labels, scalebars, coords).
# These are the ONLY template items the plugin touches -- everything
# else (grids, frames, positions) is left to the template.
#
# Verified against the actual template XML (grep for ` id="..."`
# attributes in templates/Khung_CheckCCRQT_02Line.qpt) -- every value
# below is a real item id found in that file, not a guess:
#   id="Map", id="Tên bản đồ", id="Tên đv xd bản đồ",
#   id="Khu vực bản đồ", id="Dữ liệu bản đồ", id="Viện dẫn",
#   id="Kích thước trang in", id="Scale mét", id="Scalebar độ phút",
#   id="Khung tổng".
ITEM_IDS = {
    ("print", "VN"): {
        "map": "Map",
        "title": "Tên bản đồ",
        "org_name": "Tên đv xd bản đồ",
        "study_area": "Khu vực bản đồ",
        "map_data": "Dữ liệu bản đồ",
        "references": "Viện dẫn",
        "page_size": "Kích thước trang in",
        "scalebar_m": "Scale mét",
        "scalebar_deg": "Scalebar độ phút",
        "main_frame": "Khung tổng",
    },
}

#: Logo file, relative to the plugin dir, repointed onto the layout by
#: ``_apply_branding`` on every ``create_layout`` call.
LOGO_RELATIVE_PATH = os.path.join("assets", "logo_kiemlam.png")

#: id given to the logo picture item this engine creates/reuses, so a
#: second ``create_layout`` call (or a stale layout) can find and reuse it
#: instead of stacking duplicates.
LOGO_ITEM_ID = "CheckCCRQT Logo"


class MapLayoutEngine:
    """Core engine: loads the CheckCCRQT .qpt template, builds layouts.

    Ported from LVTLayout's ``LvtEngine`` -- see module docstring for the
    exact adaptations made.
    """

    def __init__(self, iface, plugin_dir):
        self.iface = iface
        self.plugin_dir = plugin_dir
        self._layout_counter = 0
        self._tpl_cache = {}  # (mode, lang) -> XML string

    # -- Template Resolution --------------------------------------------

    def _resolve_template(self, mode, lang):
        """Find the .qpt template file."""
        fname = TEMPLATES[(mode, lang)]
        p = os.path.join(self.plugin_dir, "templates", fname)
        if os.path.exists(p):
            return p
        p = os.path.join(os.path.dirname(self.plugin_dir), fname)
        if os.path.exists(p):
            return p
        raise FileNotFoundError(
            f"Template not found: {fname}\n"
            f"Place it in: {os.path.join(self.plugin_dir, 'templates')}"
        )

    def _load_template_doc(self, mode, lang):
        """Load and cache template XML as QDomDocument."""
        key = (mode, lang)
        if key not in self._tpl_cache:
            tpl_path = self._resolve_template(mode, lang)
            with open(tpl_path, "r", encoding="utf-8") as f:
                self._tpl_cache[key] = f.read()

        doc = QDomDocument()
        ok, err_msg, err_line, _col = doc.setContent(self._tpl_cache[key])
        if not ok:
            raise RuntimeError(
                f"Template XML error at line {err_line}: {err_msg}"
            )
        return doc

    # -- Layout Creation --------------------------------------------------

    def create_layout(self, params, progress_cb=None):
        """Create a QgsPrintLayout from template + user params.

        Args:
            params: Dict of layout parameters from dialog.
            progress_cb: Optional callback(step, message) for progress updates.

        Pipeline (unchanged from LvtEngine, plus step 8 below):
          1. Load template
          2. Set page size + extent + scale (batch, no refresh yet)
          3. Multi-refresh for DD convergence
          4. Re-enforce scale + single settle refresh
          5. Update labels + toggle visibility (no refresh needed)
          6. Signature block
          7. Legend block
          8. Branding (logo + title) -- new in CheckCCRQT
        """
        def _progress(step, msg):
            if progress_cb:
                progress_cb(step, msg)

        project = QgsProject.instance()
        mode = params.get("mode", "print")
        lang = params.get("lang", "VN")
        tpl_key = (mode, lang)
        ids = ITEM_IDS[tpl_key]

        # Load cached template XML
        _progress(1, "Loading template...")
        doc = self._load_template_doc(mode, lang)

        # Create layout
        self._layout_counter += 1
        layout_name = f"CheckCCRQT_{mode}_{lang}_{self._layout_counter}"
        layout = QgsPrintLayout(project)

        _progress(2, "Applying template design...")
        _items, ok2 = layout.loadFromTemplate(doc, QgsReadWriteContext())
        if not ok2:
            raise RuntimeError("Failed to load template into layout.")

        layout.setName(layout_name)
        project.layoutManager().addLayout(layout)
        layout = project.layoutManager().layoutByName(layout_name)

        # -- Step 1: Batch setup (page + extent + scale) --------------
        _progress(3, "Setting page size & map extent...")
        pw = params["page_width"]
        ph = params["page_height"]
        page = layout.pageCollection().page(0)
        page.setPageSize(
            QgsLayoutSize(pw, ph, QgsUnitTypes.LayoutMillimeters)
        )

        sx = pw / 210.0
        sy = ph / 297.0
        if abs(sx - 1.0) > 1e-3 or abs(sy - 1.0) > 1e-3:
            self._scale_template_items(layout, sx, sy)

        map_item = self._find_item(layout, ids["map"], QgsLayoutItemMap)
        if map_item:
            extent = self._resolve_extent(params)
            map_item.zoomToExtent(extent)
            map_item.setScale(params["scale"])

            # Override template DD scale lock (was hardcoded 10000)
            # Lock to user's chosen scale instead
            user_scale = params["scale"]
            dd = QgsProperty.fromExpression(str(user_scale))
            map_item.dataDefinedProperties().setProperty(
                QgsLayoutObject.DataDefinedProperty.MapScale, dd
            )

        # -- Step 2: Multi-refresh for DD convergence ------------------
        cycles = 3 if mode == "print" else 2
        for i in range(cycles):
            _progress(4 + i, f"Rendering layout (pass {i + 1}/{cycles})...")
            layout.refresh()
            QCoreApplication.processEvents()

        # -- Step 3: Re-enforce scale + settle --------------------------
        _progress(4 + cycles, "Finalizing scale...")
        if map_item:
            map_item.setScale(params["scale"])
            layout.refresh()
            QCoreApplication.processEvents()

        # -- Step 4: Update labels ---------------------------------------
        _progress(5 + cycles, "Writing labels...")
        self._update_labels(layout, ids, params)
        if pw > 250 or ph > 350:
            self._arrange_large_format_footer(layout, ids, pw, ph)

        # -- Step 5: Toggle element visibility -----------------------------
        _progress(6 + cycles, "Configuring elements...")
        if not params.get("show_scalebar", True):
            self._hide_item(layout, ids["scalebar_m"])
            if "scalebar_deg" in ids:
                self._hide_item(layout, ids["scalebar_deg"])

        # Legend handling:
        # - If native legend block is enabled -> remove ALL template legends
        #   (Step 7 will add the new one)
        # - If native legend is disabled but show_legend=True -> keep template legend
        # - If both disabled -> hide template legends
        legend_native_enabled = params.get("legend", {}).get("enabled", False)

        if legend_native_enabled:
            to_remove_leg = [item for item in layout.items()
                              if isinstance(item, QgsLayoutItemLegend)]
            for item in to_remove_leg:
                layout.removeLayoutItem(item)
        elif not params.get("show_legend", True):
            for item in layout.items():
                if isinstance(item, QgsLayoutItemLegend):
                    item.setVisibility(False)

        # -- Step 6: Signature block --------------------------------------
        to_remove = []
        for item in layout.items():
            item_id = getattr(item, 'id', lambda: '')()
            if item_id and item_id.startswith("Sig "):
                to_remove.append(item)
        for item in to_remove:
            layout.removeLayoutItem(item)

        if params.get("signature_block"):
            _progress(7 + cycles, "Adding signature block...")
            self._add_signature_block(layout, params)

        # -- Step 7: Legend block ------------------------------------------
        if params.get("legend", {}).get("enabled"):
            _progress(8 + cycles, "Adding legend block...")
            try:
                from ._legend import add_legend_block
                add_legend_block(layout, params, self.plugin_dir)
            except Exception as e:
                from qgis.core import QgsMessageLog, Qgis
                QgsMessageLog.logMessage(
                    f"Legend block error: {e}",
                    "CheckCCRQT", Qgis.Warning)

        # -- Step 8: Branding (logo + title) -- new in CheckCCRQT ---------
        _progress(9 + cycles, "Applying branding...")
        self._apply_branding(layout, sx=sx, sy=sy)

        # -- Final: re-enforce scale (lightweight, no full refresh) --------
        if map_item:
            map_item.setScale(params["scale"])

        _progress(10 + cycles, "Done!")
        return layout

    def _scale_template_items(self, layout, sx, sy):
        """Proportionally scale A4 template items to target page size (e.g. A3)."""
        from qgis.core import QgsLayoutItemPage
        font_scale = min(sx, sy) * 0.92
        for item in layout.items():
            if isinstance(item, QgsLayoutItemPage):
                continue
            if not hasattr(item, "positionWithUnits") or not hasattr(item, "sizeWithUnits"):
                continue
            p = item.positionWithUnits()
            s = item.sizeWithUnits()
            item.attemptMove(QgsLayoutPoint(p.x() * sx, p.y() * sy, QgsUnitTypes.LayoutMillimeters))
            item.attemptResize(QgsLayoutSize(s.width() * sx, s.height() * sy, QgsUnitTypes.LayoutMillimeters))
            if isinstance(item, QgsLayoutItemLabel) and font_scale > 1.01:
                f = item.font()
                if f.pointSizeF() > 0:
                    f.setPointSizeF(f.pointSizeF() * font_scale)
                    item.setFont(f)

    # -- Label Updates -----------------------------------------------------

    def _update_labels(self, layout, ids, params):
        """Write user-provided text into template label items."""
        if "title" in ids and params.get("title"):
            self._set_label(layout, ids["title"], str(params["title"]).upper())

        if "org_name" in ids and params.get("org_name"):
            self._set_label(layout, ids["org_name"], params["org_name"])

        if "study_area" in ids and params.get("study_area"):
            sa_text = str(params["study_area"])
            self._set_label(layout, ids["study_area"], sa_text)
            sa_item = self._find_item(layout, ids["study_area"], QgsLayoutItemLabel)
            if sa_item is not None:
                from qgis.PyQt.QtCore import Qt
                from qgis.core import QgsLayoutItem

                pw = float(params.get("page_width", 210))
                sx = pw / 210.0
                sy = float(params.get("page_height", 297)) / 297.0
                dd = sa_item.dataDefinedProperties()
                for prop in (
                    QgsLayoutObject.DataDefinedProperty.PositionX,
                    QgsLayoutObject.DataDefinedProperty.PositionY,
                    QgsLayoutObject.DataDefinedProperty.ItemWidth,
                    QgsLayoutObject.DataDefinedProperty.ItemHeight,
                ):
                    dd.setProperty(prop, QgsProperty())
                sa_item.setReferencePoint(QgsLayoutItem.UpperLeft)
                sa_item.attemptMove(
                    QgsLayoutPoint(20.0 * sx, 11.2 * sy, QgsUnitTypes.LayoutMillimeters)
                )
                sa_item.attemptResize(
                    QgsLayoutSize(max(120.0, pw - 26.0 * sx), 6.0 * sy, QgsUnitTypes.LayoutMillimeters)
                )
                sa_item.setHAlign(Qt.AlignHCenter)
                sa_item.setVAlign(Qt.AlignTop)
                font = sa_item.font()
                font.setPointSizeF(6.5 if len(sa_text) > 75 else 7.5)
                font.setBold(False)
                sa_item.setFont(font)

        if "map_data" in ids and params.get("data_sources"):
            self._set_label(layout, ids["map_data"], params["data_sources"])

        if "references" in ids:
            fixed_ref = "Dữ liệu xây dựng bản đồ:"
            self._set_label(layout, ids["references"], fixed_ref)

        if "page_size" in ids:
            ps_item = self._find_item(layout, ids["page_size"], QgsLayoutItemLabel)
            if ps_item is not None:
                ps_item.setVisibility(False)

    def _arrange_large_format_footer(self, layout, ids, pw, ph):
        """Place footer labels in clean non-overlapping columns on A3+ sheets."""
        from qgis.PyQt.QtCore import Qt
        from qgis.core import QgsLayoutItem, QgsLayoutItemScaleBar

        top_hdr = ph - 12.5
        top_body = ph - 9.0
        body_h = 8.5

        def _clear_geom_dd(item):
            dd = item.dataDefinedProperties()
            for prop in (
                QgsLayoutObject.DataDefinedProperty.PositionX,
                QgsLayoutObject.DataDefinedProperty.PositionY,
                QgsLayoutObject.DataDefinedProperty.ItemWidth,
                QgsLayoutObject.DataDefinedProperty.ItemHeight,
            ):
                dd.setProperty(prop, QgsProperty())

        def _place_lbl(item, x, y, w, h, pt, halign, bold=False):
            _clear_geom_dd(item)
            item.setReferencePoint(QgsLayoutItem.UpperLeft)
            item.attemptMove(QgsLayoutPoint(x, y, QgsUnitTypes.LayoutMillimeters))
            item.attemptResize(QgsLayoutSize(w, h, QgsUnitTypes.LayoutMillimeters))
            item.setHAlign(halign)
            item.setVAlign(Qt.AlignTop)
            f = item.font()
            f.setPointSizeF(pt)
            f.setBold(bold)
            item.setFont(f)

        ref_lbl = self._find_item(layout, ids.get("references", ""), QgsLayoutItemLabel)
        if ref_lbl is not None:
            _place_lbl(ref_lbl, 9.0, top_hdr, 134.0, 3.5, 7.5, Qt.AlignLeft, bold=True)

        data_lbl = self._find_item(layout, ids.get("map_data", ""), QgsLayoutItemLabel)
        if data_lbl is not None:
            _place_lbl(data_lbl, 9.0, top_body, 134.0, body_h, 7.0, Qt.AlignLeft, bold=False)

        org_lbl = self._find_item(layout, ids.get("org_name", ""), QgsLayoutItemLabel)
        if org_lbl is not None:
            _place_lbl(org_lbl, pw - 95.0, top_body, 86.0, body_h, 7.0, Qt.AlignRight, bold=False)

        for item in layout.items():
            if isinstance(item, QgsLayoutItemLabel):
                txt = (item.text() or "").strip()
                if txt.startswith("Đơn vị xây dựng"):
                    _place_lbl(item, pw - 95.0, top_hdr, 86.0, 3.5, 7.5, Qt.AlignRight, bold=True)
                elif "Tỷ lệ 1" in txt:
                    _clear_geom_dd(item)
                    item.setReferencePoint(QgsLayoutItem.UpperLeft)
                    item.attemptMove(QgsLayoutPoint(145.0, ph - 7.8, QgsUnitTypes.LayoutMillimeters))
                    item.attemptResize(QgsLayoutSize(64.0, 3.5, QgsUnitTypes.LayoutMillimeters))
                    item.setHAlign(Qt.AlignHCenter)
                    f = item.font(); f.setPointSizeF(7.0); item.setFont(f)
                elif "1 cm trên bản đồ" in txt:
                    _clear_geom_dd(item)
                    item.setReferencePoint(QgsLayoutItem.UpperLeft)
                    item.attemptMove(QgsLayoutPoint(145.0, ph - 4.4, QgsUnitTypes.LayoutMillimeters))
                    item.attemptResize(QgsLayoutSize(64.0, 3.5, QgsUnitTypes.LayoutMillimeters))
                    item.setHAlign(Qt.AlignHCenter)
                    f = item.font(); f.setPointSizeF(7.0); item.setFont(f)
            elif isinstance(item, QgsLayoutItemScaleBar):
                if item.id() in (ids.get("scalebar_m"), ids.get("scalebar_deg")):
                    _clear_geom_dd(item)
                    item.setReferencePoint(QgsLayoutItem.UpperLeft)
                    item.attemptMove(QgsLayoutPoint(150.0, ph - 12.8, QgsUnitTypes.LayoutMillimeters))
                    item.attemptResize(QgsLayoutSize(54.0, 4.5, QgsUnitTypes.LayoutMillimeters))

    # -- Branding (logo + title) --------------------------------------------

    def _apply_branding(self, layout, sx=1.0, sy=1.0):
        """Repoint/create the CheckCCRQT logo picture item."""
        logo_path = os.path.join(self.plugin_dir, LOGO_RELATIVE_PATH)
        if not os.path.isfile(logo_path):
            return

        logo_dim = 13.0 * min(sx, sy)
        picture = self._find_item(layout, LOGO_ITEM_ID, QgsLayoutItemPicture)
        if picture is None:
            picture = QgsLayoutItemPicture(layout)
            picture.setId(LOGO_ITEM_ID)
            picture.attemptMove(
                QgsLayoutPoint(6.0 * sx, 1.5, QgsUnitTypes.LayoutMillimeters)
            )
            picture.attemptResize(
                QgsLayoutSize(logo_dim, logo_dim, QgsUnitTypes.LayoutMillimeters)
            )
            picture.setBackgroundEnabled(False)
            picture.setFrameEnabled(False)
            layout.addLayoutItem(picture)

        picture.setPicturePath(logo_path)
        layout.raiseItem(picture)

    # -- Extent Resolution ---------------------------------------------------

    def _resolve_extent(self, params):
        """Get the map extent based on user selection."""
        mode = params["extent_mode"]
        if mode == "drawn" and params.get("drawn_extent"):
            return params["drawn_extent"]
        elif mode == "layer" and params.get("extent_layer"):
            return params["extent_layer"].extent()
        else:
            return self.iface.mapCanvas().extent()

    # -- Helpers ----------------------------------------------------------------

    @staticmethod
    def _find_item(layout, item_id, item_type=None):
        item = layout.itemById(item_id)
        if item and item_type and not isinstance(item, item_type):
            return None
        return item

    @staticmethod
    def _set_label(layout, item_id, text):
        item = layout.itemById(item_id)
        if item and isinstance(item, QgsLayoutItemLabel):
            item.setText(text)

    @staticmethod
    def _hide_item(layout, item_id):
        item = layout.itemById(item_id)
        if item:
            item.setVisibility(False)

    def _add_signature_block(self, layout, params):
        """Add N signature blocks at bottom-left of layout.

        Each block uses 3 items:
          - QgsLayoutItemShape (rectangle) for border
          - QgsLayoutItemLabel for header (title + date + separator)
          - QgsLayoutItemLabel for name (native VAlign bottom)
        """
        from qgis.PyQt.QtGui import QFont
        from qgis.PyQt.QtCore import Qt
        from qgis.core import QgsLayoutItemShape
        from qgis.core import QgsFillSymbol

        to_remove = []
        for item in layout.items():
            item_id = getattr(item, 'id', lambda: '')()
            if item_id and item_id.startswith("Sig "):
                to_remove.append(item)
        for item in to_remove:
            layout.removeLayoutItem(item)

        sig_h = params.get("sig_height", 50)
        sig_w = params.get("sig_width", 50)
        blocks = params.get("sig_blocks", [])

        ft = params.get("sig_font_title",
                         ("Times New Roman", 12, True, False))
        fd = params.get("sig_font_date",
                         ("Times New Roman", 10, False, True))
        fn = params.get("sig_font_name",
                         ("Times New Roman", 11, True, False))

        map_item = None
        for item in layout.items():
            if isinstance(item, QgsLayoutItemMap):
                map_item = item
                break

        if not map_item:
            return

        map_x = map_item.positionWithUnits().x()
        map_y = map_item.positionWithUnits().y()
        map_h = map_item.sizeWithUnits().height()

        ml = params.get("sig_margin_left", 3)
        mb = params.get("sig_margin_bottom", 3)
        base_x = map_x + ml
        frame_bottom = map_y + map_h
        base_y = frame_bottom - mb - sig_h

        hdr_h = 16  # mm
        name_h = 8  # mm

        def _css(fam, sz, bold, italic):
            w = "bold" if bold else "normal"
            s = "italic" if italic else "normal"
            return (f"font-family:'{fam}';font-size:{sz}pt;"
                    f"font-weight:{w};font-style:{s};")

        def _make_font(fam, sz, bold, italic):
            f = QFont(fam, sz)
            f.setBold(bold)
            f.setItalic(italic)
            return f

        for i, blk in enumerate(blocks):
            x = base_x + i * sig_w
            title = blk.get("title", "")
            sig_date = blk.get("date", "")
            name = blk.get("name", "")

            rect = QgsLayoutItemShape(layout)
            rect.setShapeType(QgsLayoutItemShape.Rectangle)
            rect.attemptMove(
                QgsLayoutPoint(x, base_y,
                               QgsUnitTypes.LayoutMillimeters))
            rect.attemptResize(
                QgsLayoutSize(sig_w, sig_h,
                              QgsUnitTypes.LayoutMillimeters))
            sym = QgsFillSymbol.createSimple({
                'color': '255,255,255,255',
                'outline_color': '0,0,0,255',
                'outline_width': '0.2',
                'outline_width_unit': 'MM',
            })
            rect.setSymbol(sym)
            rect.setBackgroundEnabled(False)
            rect.setFrameEnabled(False)
            rect.setLocked(True)
            rect.setId(f"Sig Frame {i + 1}")
            layout.addLayoutItem(rect)
            layout.raiseItem(rect)

            hdr_html = (
                '<div style="text-align:center;">'
                f'<div style="text-align:center;{_css(*ft)}">'
                f'{title}</div>'
                f'<div style="text-align:center;{_css(*fd)}">'
                f'{sig_date}</div>'
                '<hr style="border:none;border-top:0.2mm solid #000;'
                'width:90%;margin:2mm auto 0 auto;"/>'
                '</div>'
            )
            hdr = QgsLayoutItemLabel(layout)
            hdr.setMode(QgsLayoutItemLabel.ModeHtml)
            hdr.setText(hdr_html)
            hdr.attemptMove(
                QgsLayoutPoint(x, base_y + 3,
                               QgsUnitTypes.LayoutMillimeters))
            hdr.attemptResize(
                QgsLayoutSize(sig_w, hdr_h,
                              QgsUnitTypes.LayoutMillimeters))
            hdr.setBackgroundEnabled(False)
            hdr.setFrameEnabled(False)
            hdr.setLocked(True)
            hdr.setId(f"Sig Header {i + 1}")
            layout.addLayoutItem(hdr)
            layout.raiseItem(hdr)

            name_lbl = QgsLayoutItemLabel(layout)
            name_lbl.setMode(QgsLayoutItemLabel.ModeFont)
            name_lbl.setText(name)
            name_lbl.setFont(_make_font(*fn))
            name_lbl.setHAlign(Qt.AlignHCenter)
            name_lbl.setVAlign(Qt.AlignBottom)
            name_y = base_y + sig_h - name_h - 3
            name_lbl.attemptMove(
                QgsLayoutPoint(x, name_y,
                               QgsUnitTypes.LayoutMillimeters))
            name_lbl.attemptResize(
                QgsLayoutSize(sig_w, name_h,
                              QgsUnitTypes.LayoutMillimeters))
            name_lbl.setBackgroundEnabled(False)
            name_lbl.setFrameEnabled(False)
            name_lbl.setLocked(True)
            name_lbl.setId(f"Sig Name {i + 1}")
            layout.addLayoutItem(name_lbl)
            layout.raiseItem(name_lbl)
