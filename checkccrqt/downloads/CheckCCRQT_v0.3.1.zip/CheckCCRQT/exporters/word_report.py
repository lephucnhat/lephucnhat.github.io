# -*- coding: utf-8 -*-
"""Word (.docx) cycle report exporter (CheckCCRQT v0.3.0).

Chuẩn trình bày báo cáo Kiểm lâm (A4, lề 2.0 cm, bề rộng khả dụng 17.0 cm):
    * Logo Kiểm lâm, Đơn vị thực hiện và Ngày kiểm tra ở đầu trang.
    * Font Arial, tiêu đề màu xanh Kiểm lâm (#1B5E20 / #2E7D32 / #388E3C).
    * Bảng chi tiết 7 cột tối ưu độ rộng (có cột Ngày phát hiện khai thác).
    * Hỗ trợ chèn ảnh minh họa Sentinel-2 từ ``image_pairs`` hoặc ``tmf_visuals``.
    * Thuộc tính Author đặt động theo ``org_name`` (BUG-19).

Author: Phòng Sử dụng và Phát triển rừng — Chi cục Kiểm lâm tỉnh Quảng Trị
License: GPL-3.0
"""

import base64
import io
import os
from datetime import date

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

DEFAULT_AUTHOR = "Phòng Sử dụng và Phát triển rừng — Chi cục Kiểm lâm tỉnh Quảng Trị"

_GREEN_DARK = RGBColor(0x1B, 0x5E, 0x20)
_GREEN_MID = RGBColor(0x2E, 0x7D, 0x32)
_GREEN_LIGHT = RGBColor(0x38, 0x8E, 0x3C)
_BORDER_COLOR = "D0D7DE"

_USABLE_WIDTH_CM = 17.0


def _default_logo_path():
    base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    p = os.path.join(base, "assets", "logo_kiemlam.png")
    return p if os.path.isfile(p) else None


def _set_cell_shading(cell, hex_color):
    shading = OxmlElement("w:shd")
    shading.set(qn("w:fill"), hex_color)
    cell._tc.get_or_add_tcPr().append(shading)


def _set_cell_border(cell, hex_color=_BORDER_COLOR):
    tcPr = cell._tc.get_or_add_tcPr()
    borders = OxmlElement("w:tcBorders")
    for edge in ("top", "left", "bottom", "right"):
        el = OxmlElement(f"w:{edge}")
        el.set(qn("w:val"), "single")
        el.set(qn("w:sz"), "4")
        el.set(qn("w:color"), hex_color)
        borders.append(el)
    tcPr.append(borders)


def _setup_document(d, author=None):
    """Apply the A4/margins/Normal-style/heading-style standard to ``d``."""
    section = d.sections[0]
    section.page_height = Cm(29.7)
    section.page_width = Cm(21.0)
    section.top_margin = Cm(2.0)
    section.bottom_margin = Cm(2.0)
    section.left_margin = Cm(2.0)
    section.right_margin = Cm(2.0)

    normal = d.styles["Normal"]
    normal.font.name = "Arial"
    normal.font.size = Pt(12)
    rpr = normal.element.get_or_add_rPr()
    rFonts = rpr.find(qn("w:rFonts"))
    if rFonts is None:
        rFonts = OxmlElement("w:rFonts")
        rpr.append(rFonts)
    rFonts.set(qn("w:ascii"), "Arial")
    rFonts.set(qn("w:hAnsi"), "Arial")
    rFonts.set(qn("w:eastAsia"), "Arial")
    rFonts.set(qn("w:cs"), "Arial")

    pf = normal.paragraph_format
    pf.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    pf.line_spacing = 1.25
    pf.space_before = Pt(6)
    pf.space_after = Pt(4)

    for heading_name, color in (
        ("Heading 1", _GREEN_DARK),
        ("Heading 2", _GREEN_MID),
        ("Heading 3", _GREEN_LIGHT),
    ):
        style = d.styles[heading_name]
        style.font.name = "Arial"
        style.font.bold = True
        style.font.color.rgb = color
        style.paragraph_format.keep_with_next = True

    d.core_properties.author = (author or "").strip() or DEFAULT_AUTHOR


def _add_header_banner(d, org_name, check_date, logo_path=None):
    """Add forestry logo, executing unit name and inspection date banner."""
    eff_logo = logo_path or _default_logo_path()
    eff_org = (org_name or "").strip() or DEFAULT_AUTHOR
    eff_date = (check_date or "").strip() or date.today().strftime("%d/%m/%Y")

    tbl = d.add_table(rows=1, cols=2)
    tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
    tbl.autofit = False
    c_logo, c_meta = tbl.rows[0].cells
    c_logo.width = Cm(2.6)
    c_meta.width = Cm(_USABLE_WIDTH_CM - 2.6)

    p_logo = c_logo.paragraphs[0]
    p_logo.alignment = WD_ALIGN_PARAGRAPH.CENTER
    if eff_logo and os.path.isfile(eff_logo):
        try:
            p_logo.add_run().add_picture(eff_logo, width=Cm(2.1))
        except Exception:
            pass

    p_org = c_meta.paragraphs[0]
    p_org.alignment = WD_ALIGN_PARAGRAPH.LEFT
    r_org = p_org.add_run(eff_org.upper())
    r_org.bold = True
    r_org.font.name = "Arial"
    r_org.font.size = Pt(11)
    r_org.font.color.rgb = _GREEN_DARK

    p_sub = c_meta.add_paragraph()
    p_sub.alignment = WD_ALIGN_PARAGRAPH.LEFT
    r_sub = p_sub.add_run(f"Hệ thống CheckCCRQT v0.3.1  |  Ngày kiểm tra: {eff_date}")
    r_sub.font.name = "Arial"
    r_sub.font.size = Pt(10)
    r_sub.font.color.rgb = RGBColor(0x47, 0x55, 0x69)


def _add_summary_table(d, summary):
    table = d.add_table(rows=0, cols=2)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    col_widths = (Cm(_USABLE_WIDTH_CM * 0.5), Cm(_USABLE_WIDTH_CM * 0.5))

    header_cells = table.add_row().cells
    headers = ["Chỉ tiêu", "Giá trị"]
    for cell, label in zip(header_cells, headers):
        cell.text = label
        _set_cell_shading(cell, "1B5E20")
        _set_cell_border(cell)
        para = cell.paragraphs[0]
        para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = para.runs[0]
        run.font.bold = True
        run.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
        run.font.name = "Arial"

    rows = [
        ("Đơn vị thực hiện", str(summary.get("org_name") or DEFAULT_AUTHOR), False),
        ("Ngày kiểm tra", str(summary.get("check_date") or date.today().strftime("%d/%m/%Y")), False),
        ("Kỳ báo cáo", str(summary.get("period_label", "")), False),
        ("Tổng số lô", str(summary.get("total", "")), True),
        ("Số lô thay đổi / phát hiện khai thác", str(summary.get("changed", "")), True),
    ]
    for label, value, is_numeric in rows:
        cells = table.add_row().cells
        cells[0].text = label
        cells[1].text = value
        _set_cell_border(cells[0])
        _set_cell_border(cells[1])
        cells[0].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.LEFT
        cells[1].paragraphs[0].alignment = (
            WD_ALIGN_PARAGRAPH.RIGHT if is_numeric else WD_ALIGN_PARAGRAPH.LEFT
        )

    for row in table.rows:
        for cell, width in zip(row.cells, col_widths):
            cell.width = width

    return table


def _add_records_table(d, records):
    """7-column detail table with optimized widths totaling 17.0 cm (BUG-15)."""
    columns = [
        ("Mã lô", "id_lo", "center", 2.2),
        ("Chủ hộ", "chu_ho", "left", 3.4),
        ("Trạng thái", "status", "left", 3.3),
        ("Ngày phát hiện", "harvest_date", "center", 2.2),
        ("EUDR (TMF)", "tmf_status", "left", 2.3),
        ("Năm TMF", "tmf_year", "center", 1.6),
        ("DT TMF (ha)", "tmf_ha", "right", 2.0),
    ]
    table = d.add_table(rows=0, cols=len(columns))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    col_widths = [Cm(w) for _, _, _, w in columns]

    header_cells = table.add_row().cells
    for cell, (label, _key, _align, _w) in zip(header_cells, columns):
        cell.text = label
        _set_cell_shading(cell, "1B5E20")
        _set_cell_border(cell)
        para = cell.paragraphs[0]
        para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = para.runs[0]
        run.font.bold = True
        run.font.size = Pt(10)
        run.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
        run.font.name = "Arial"

    _ALIGN_MAP = {
        "center": WD_ALIGN_PARAGRAPH.CENTER,
        "left": WD_ALIGN_PARAGRAPH.LEFT,
        "right": WD_ALIGN_PARAGRAPH.RIGHT,
    }
    for record in records:
        cells = table.add_row().cells
        for cell, (_label, key, align, _w) in zip(cells, columns):
            val = record.get(key)
            cell.text = "" if val is None else str(val)
            _set_cell_border(cell)
            para = cell.paragraphs[0]
            para.alignment = _ALIGN_MAP[align]
            if para.runs:
                para.runs[0].font.size = Pt(10)

    for row in table.rows:
        for cell, width in zip(row.cells, col_widths):
            cell.width = width

    return table


def _add_image_pairs(d, image_pairs):
    existing_pairs = [
        (before, after)
        for before, after in (image_pairs or [])
        if before and after and os.path.isfile(before) and os.path.isfile(after)
    ]
    if not existing_pairs:
        return

    d.add_heading("Ảnh vệ tinh đối chiếu trước/sau", level=2)
    img_width = Cm(_USABLE_WIDTH_CM / 2 - 0.2)
    for before_path, after_path in existing_pairs:
        table = d.add_table(rows=2, cols=2)
        table.alignment = WD_TABLE_ALIGNMENT.CENTER
        table.rows[0].cells[0].text = "Trước"
        table.rows[0].cells[1].text = "Sau"
        for cell in table.rows[0].cells:
            cell.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
            cell.paragraphs[0].runs[0].font.bold = True
        table.rows[1].cells[0].paragraphs[0].add_run().add_picture(before_path, width=img_width)
        table.rows[1].cells[1].paragraphs[0].add_run().add_picture(after_path, width=img_width)


def _add_tmf_visuals(d, tmf_visuals):
    """Embed Sentinel-2 RGB thumbnails generated by ``exporters.tmf_visual`` (BUG-15)."""
    if not tmf_visuals or not isinstance(tmf_visuals, dict):
        return

    items = []
    for id_lo, vis in tmf_visuals.items():
        uri = (vis or {}).get("img_data_uri") or ""
        if uri.startswith("data:image/") and ";base64," in uri:
            items.append((id_lo, vis, uri.split(";base64,", 1)[1]))
    if not items:
        return

    d.add_heading("Ảnh minh họa Sentinel-2 các lô cảnh báo / vi phạm EUDR", level=2)
    img_width = Cm(12.5)
    for id_lo, vis, b64_data in items:
        try:
            raw = base64.b64decode(b64_data)
            buf = io.BytesIO(raw)
            p_cap = d.add_paragraph()
            p_cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
            r = p_cap.add_run(
                f"Lô {id_lo} — {vis.get('scene_label', 'Ảnh Sentinel-2')}"
            )
            r.bold = True
            r.font.size = Pt(10.5)
            p_img = d.add_paragraph()
            p_img.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p_img.add_run().add_picture(buf, width=img_width)
        except Exception:
            continue


def export_word_report(
    summary: dict,
    records: list,
    image_pairs: list,
    output_path: str,
    org_name: str = None,
    check_date: str = None,
    logo_path: str = None,
    tmf_visuals: dict = None,
) -> str:
    """Write the cycle report as a .docx with forestry branding and visuals."""
    eff_org = (org_name or summary.get("org_name") or "").strip() or DEFAULT_AUTHOR
    eff_date = (check_date or summary.get("check_date") or "").strip() or date.today().strftime("%d/%m/%Y")

    d = Document()
    _setup_document(d, author=eff_org)
    _add_header_banner(d, eff_org, eff_date, logo_path=logo_path)

    period_label = summary.get("period_label", "")
    title = d.add_heading(f"BÁO CÁO CHU KỲ KIỂM TRA: {period_label}", level=1)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER

    d.add_heading("1. Tổng hợp kết quả", level=2)
    merged_summary = dict(summary)
    merged_summary.setdefault("org_name", eff_org)
    merged_summary.setdefault("check_date", eff_date)
    _add_summary_table(d, merged_summary)

    d.add_heading("2. Chi tiết các lô rừng kiểm tra", level=2)
    _add_records_table(d, records)

    _add_image_pairs(d, image_pairs)
    _add_tmf_visuals(d, tmf_visuals)

    d.save(output_path)
    return output_path
