# -*- coding: utf-8 -*-
"""CheckCCRQT — Plugin Controller.

Hệ thống Kiểm tra Tính xác thực & Giám sát Rừng trồng Chứng chỉ.
Main entry point for QGIS interface integration.
Creates menu and toolbar buttons for launching the CheckCCRQT dialog.

Author: Phòng Sử dụng và Phát triển rừng — Chi cục Kiểm lâm tỉnh Quảng Trị
License: GPL-3.0
"""

import os
from qgis.PyQt.QtCore import QCoreApplication
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction


class CheckCCRQTPlugin:
    """QGIS Plugin Implementation for CheckCCRQT."""

    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.actions = []
        self.menu = "&CheckCCRQT"
        self.toolbar = None
        self.dialog = None

    def tr(self, message):
        return QCoreApplication.translate("CheckCCRQTPlugin", message)

    def initGui(self):
        """Create the menu items and toolbar buttons on QGIS launch."""
        icon_path = os.path.join(self.plugin_dir, "icon.png")

        icon = QIcon(icon_path)
        action = QAction(
            icon,
            "CheckCCRQT: Kiểm tra Tính xác thực & Giám sát Rừng trồng Chứng chỉ",
            self.iface.mainWindow()
        )
        action.triggered.connect(self.run)
        action.setToolTip(
            "Kiểm tra tính xác thực và giám sát rừng trồng được cấp chứng chỉ "
            "quản lý rừng bền vững"
        )

        # Add to Plugins menu
        self.iface.addPluginToMenu(self.menu, action)

        # Add to dedicated toolbar
        self.toolbar = self.iface.addToolBar("CheckCCRQT")
        self.toolbar.setObjectName("CheckCCRQTToolBar")
        self.toolbar.addAction(action)

        self.actions.append(action)

    def unload(self):
        """Safely cancel background tasks, close dialog, and remove GUI items (BUG-16)."""
        if self.dialog is not None:
            for attr in ("_sentinel_task", "_tmf_task"):
                task = getattr(self.dialog, attr, None)
                if task is not None:
                    try:
                        task.cancel()
                    except Exception:
                        pass
                    try:
                        setattr(self.dialog, attr, None)
                    except Exception:
                        pass
            try:
                self.dialog.close()
                self.dialog.deleteLater()
            except Exception:
                pass
            self.dialog = None

        for action in self.actions:
            self.iface.removePluginMenu(self.menu, action)
            if self.toolbar:
                self.toolbar.removeAction(action)
        if self.toolbar:
            self.iface.mainWindow().removeToolBar(self.toolbar)
            del self.toolbar
            self.toolbar = None

    def run(self):
        """Open the CheckCCRQT Dialog."""
        from .ui.main_dialog import MainDialog

        if self.dialog is None:
            self.dialog = MainDialog(self.iface, self.plugin_dir)

        self.dialog.refresh()
        self.dialog.show()
        self.dialog.raise_()
        self.dialog.activateWindow()
