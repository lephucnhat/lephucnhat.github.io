# CheckCCRQT

![Logo Kiểm lâm Việt Nam](assets/logo_kiemlam.png)

**CHECK CCRQT — Hệ thống Kiểm tra Tính xác thực & Giám sát Rừng trồng Chứng chỉ (Phiên bản 0.3.1)**

**CheckCCRQT** là phần mềm bổ trợ (Plugin) mã nguồn mở trên nền tảng QGIS, thuộc sáng kiến *"Nghiên cứu ứng dụng AI để xây dựng Plugin mã nguồn mở trên nền tảng QGIS nhằm tự động hóa việc theo dõi kiểm tra, quản lý rừng trồng được cấp chứng chỉ quản lý rừng bền vững trên địa bàn tỉnh Quảng Trị"* do **Tập thể Phòng Sử dụng và Phát triển rừng — Chi cục Kiểm lâm tỉnh Quảng Trị** (Sở Nông nghiệp và Môi trường tỉnh Quảng Trị) nghiên cứu và xây dựng.

Phần mềm phục vụ trực tiếp công tác tham mưu, hướng dẫn và kiểm tra thực hiện phương án quản lý rừng bền vững, cấp chứng chỉ gỗ rừng trồng và giám sát khai thác theo Quyết định số 406/QĐ-CCKL ngày 08/7/2025 của Chi cục Kiểm lâm tỉnh Quảng Trị, đồng thời thiết kế mở để áp dụng trên phạm vi cả nước.

### Chức năng chính
- Chuẩn hóa hệ tọa độ VN-2000 (Quảng Trị mới `106°00'`, Quảng Trị cũ `106°15'`, Quảng Bình cũ `106°00'` và toàn bộ các tỉnh/thành Việt Nam).
- Kiểm tra lỗi hình học, thiếu số liệu thuộc tính, đối soát diện tích bản đồ với diện tích khai báo và xuất báo cáo cảnh báo HTML.
- Kiểm tra tính xác thực theo danh sách ID lô thông báo; dò chuỗi thời gian ảnh vệ tinh Sentinel-2 trực tuyến (không cần đăng nhập) để xác định thời điểm khai thác thực tế chính xác.
- Thẩm định nguy cơ phá rừng, chuyển đổi mục đích sử dụng rừng sau mốc 31/12/2020 căn cứ dữ liệu EC JRC TMF.
- Xuất báo cáo so sánh theo chu kỳ (Excel, Word) và bản đồ in PDF chuẩn khung 02 dòng kẻ.

### Nguồn dữ liệu tham chiếu & Căn cứ khoa học
- **Ảnh vệ tinh Sentinel-2 L2A (ESA Copernicus):** Truy vấn trực tuyến qua chuẩn STAC API (Earth Search / AWS Open Data, không cần đăng nhập) và đọc cửa sổ COG trực tiếp bằng GDAL `/vsicurl/`, kết hợp mặt nạ mây từ lớp phân loại cảnh (SCL) ở độ phân giải 10–20 m để tính chuỗi chỉ số thực vật `NDVI`, `NBR`, `NDMI`.
- **Dữ liệu rừng ẩm nhiệt đới toàn cầu (EC JRC TMF v1_2025):** Sử dụng bộ dữ liệu `DeforestationYear` và `TransitionMap_MainClasses` của Trung tâm Nghiên cứu Chung Ủy ban châu Âu (JRC) phục vụ thẩm định tiêu chí không gây mất rừng sau mốc 31/12/2020 theo Quy định (EU) 2023/1115 (EUDR).
- **Hệ quy chiếu quốc gia VN-2000:** Chuyển đổi tọa độ phẳng bằng bộ 7 tham số Helmert tiêu chuẩn và kinh tuyến trục từng địa phương (đặc biệt Quảng Trị mới `106°00'`, Quảng Trị cũ `106°15'`, Quảng Bình cũ `106°00'`).

### Cập nhật, bảo trì & Tiếp nhận góp ý
Plugin **CheckCCRQT** được nhóm tác giả duy trì cập nhật liên tục và lắng nghe phản hồi từ các Hạt Kiểm lâm, chủ rừng, nhóm hộ chứng chỉ để kịp thời sửa lỗi, tối ưu tốc độ và bổ sung tính năng nghiệp vụ mới. Mọi ý kiến đóng góp vui lòng gửi về `sdptrklqt@gmail.com`.

### Thông tin đơn vị & liên hệ
- **Đơn vị thực hiện:** Phòng Sử dụng và Phát triển rừng — Chi cục Kiểm lâm tỉnh Quảng Trị
- **Cơ quan chủ quản:** Sở Nông nghiệp và Môi trường tỉnh Quảng Trị
- **Đại diện:** Ông Phạm Thanh Trung — Trưởng phòng
- **Email:** `sdptrklqt@gmail.com`
- **Điện thoại:** `0905 822 335`

## Danh sách cán bộ Phòng Sử dụng và Phát triển rừng

| STT | Họ và tên | Chức vụ | Số điện thoại |
| --- | --- | --- | --- |
| 1 | Phạm Thanh Trung | Trưởng phòng Sử dụng và PT rừng | 0905822335 |
| 2 | Phạm Xuân Thành | Phó Trưởng phòng Sử dụng và PT rừng | 0905882755 |
| 3 | Nguyễn Tuấn Anh | Phó Trưởng phòng Sử dụng và PT rừng | 0365643801 |
| 4 | Nguyễn Việt Tú | Kiểm lâm viên | 0822585123 |
| 5 | Phạm Hoàng Hà | Kiểm lâm viên | 0888476979 |
| 6 | Nguyễn Thanh Lý | Kiểm lâm viên | 0916624511 |
| 7 | Dương Chí Anh | Kiểm lâm viên | 0869117555 |
| 8 | Nguyễn Văn Thăng | Kiểm lâm viên | 0946699357 |
| 9 | Trần Phước Lâm | Kiểm lâm viên | 0982353345 |
| 10 | Lê Ngọc Cường | Kiểm lâm viên | 0911431369 |
