# -*- coding: utf-8 -*-
"""CheckCCRQT — QGIS Plugin Entry Point."""


def classFactory(iface):
    """Load CheckCCRQTPlugin class from file plugin.py."""
    from .plugin import CheckCCRQTPlugin
    return CheckCCRQTPlugin(iface)
