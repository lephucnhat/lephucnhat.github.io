"""Auto-detect which attribute columns of a layer correspond to the plugin's canonical fields."""
# Defers annotation evaluation so ``str | None`` (PEP 604) doesn't raise
# TypeError at import time on Python 3.9 (QGIS 3.28/3.34 LTR on Windows).
from __future__ import annotations

import re
import unicodedata

from qgis.core import QgsVectorLayer

CANONICAL_FIELDS = [
    "id_lo",
    "chu_ho",
    "tieu_khu",
    "khoanh",
    "lo",
    "dien_tich_kb",
    "nam_trong",
    "loai_cay",
    "trang_thai_ccr",
]

# Alias values are already normalized (see normalize_field_name).
FIELD_ALIASES: dict[str, list[str]] = {
    "id_lo": ["farmid", "malo", "idlo", "id", "code", "plotid", "maho"],
    "chu_ho": ["farmer", "chuho", "churung", "tenchurung", "owner", "tenchu", "tenchuho"],
    "tieu_khu": ["compartmen", "compartment", "tieukhu", "tk"],
    "khoanh": ["subcompar", "subcompartment", "khoanh"],
    "lo": ["plot", "lo", "solo"],
    "dien_tich_kb": ["areaha", "area", "dientich", "dientichha", "dtha", "dtkhaibao", "dtkb"],
    "nam_trong": ["planted", "namtrong", "yearplanted", "namtr"],
    "loai_cay": ["species", "loaicay", "loai", "sldlr", "maloai"],
    "trang_thai_ccr": ["certificatestatus", "trangthaiccr", "chungchi", "fsc", "pefc", "status"],
}

# Extended FRMS / administrative field aliases for interoperability.
ADMIN_FIELD_ALIASES: dict[str, list[str]] = {
    "ma_tinh": ["matinh", "tinh"],
    "ma_huyen": ["mahuyen", "huyen"],
    "ma_xa": ["maxa", "xa"],
}

_NON_ALNUM = re.compile(r"[^a-z0-9]")


def normalize_field_name(name: str) -> str:
    """Lowercase, strip accents and drop every non-alphanumeric character."""
    # Vietnamese Đ/đ are not decomposed by NFKD, so map them explicitly.
    decomposed = unicodedata.normalize("NFKD", name.replace("Đ", "D").replace("đ", "d"))
    ascii_only = decomposed.encode("ascii", "ignore").decode("ascii")
    return _NON_ALNUM.sub("", ascii_only.lower())


def auto_detect_fields(layer: QgsVectorLayer) -> dict[str, str | None]:
    """Map each canonical key to the first real field on ``layer`` whose normalized name matches an alias.

    Returns ``None`` for keys with no matching field.
    """
    normalized_fields = [(real, normalize_field_name(real)) for real in layer.fields().names()]
    result: dict[str, str | None] = {}
    for key in CANONICAL_FIELDS:
        aliases = FIELD_ALIASES[key]
        result[key] = next(
            (real for real, norm in normalized_fields if norm in aliases),
            None,
        )
    return result
