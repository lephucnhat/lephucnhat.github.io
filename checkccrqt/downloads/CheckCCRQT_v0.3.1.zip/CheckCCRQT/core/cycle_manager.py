# -*- coding: utf-8 -*-
"""Monitoring-cycle period calculation — pure date math, no QGIS dependency.

Resolves a UI-selected cycle type ("monthly", "quarterly", "semiannual",
"annual", "custom") plus a reference date into a concrete (t1, t2) period,
and can enumerate consecutive periods spanning a date range. Used by
Tab 4 (``ui/main_dialog.py``) to display/export periodic reports.
"""

import calendar
from datetime import date, timedelta

CYCLE_TYPES = ("monthly", "quarterly", "semiannual", "annual", "custom")


def generate_period(cycle_type, reference_date, custom_from=None, custom_to=None):
    """Resolve ``cycle_type`` + ``reference_date`` into a ``(t1, t2)`` period.

    - ``monthly``: the reference month's first/last day.
    - ``quarterly``: the containing 3-month block (Jan-Mar/Apr-Jun/Jul-Sep/Oct-Dec).
    - ``semiannual``: Jan-Jun or Jul-Dec, whichever contains the reference date.
    - ``annual``: Jan 1 - Dec 31 of the reference year.
    - ``custom``: ``custom_from``/``custom_to`` passed through unchanged;
      raises ``ValueError`` if either is ``None``.

    Raises ``ValueError`` for any other ``cycle_type``.
    """
    if cycle_type == "custom":
        if custom_from is None or custom_to is None:
            raise ValueError(
                "custom_from and custom_to are required when cycle_type is 'custom'"
            )
        return custom_from, custom_to

    year = reference_date.year

    if cycle_type == "monthly":
        month = reference_date.month
        last_day = calendar.monthrange(year, month)[1]
        return date(year, month, 1), date(year, month, last_day)

    if cycle_type == "quarterly":
        quarter_index = (reference_date.month - 1) // 3  # 0..3
        start_month = quarter_index * 3 + 1
        end_month = start_month + 2
        last_day = calendar.monthrange(year, end_month)[1]
        return date(year, start_month, 1), date(year, end_month, last_day)

    if cycle_type == "semiannual":
        if reference_date.month <= 6:
            return date(year, 1, 1), date(year, 6, 30)
        return date(year, 7, 1), date(year, 12, 31)

    if cycle_type == "annual":
        return date(year, 1, 1), date(year, 12, 31)

    raise ValueError(f"Unknown cycle_type: {cycle_type!r}")


def list_periods_between(cycle_type, start, end):
    """Enumerate consecutive ``generate_period`` periods covering ``start``..``end``.

    Repeatedly advances from ``start``, using the day after each period's
    end as the next reference date, until a generated period's end is
    ``>= end``. Not valid for ``cycle_type == "custom"`` (there's no
    "next" custom period to advance to).
    """
    if cycle_type == "custom":
        raise ValueError("list_periods_between does not support cycle_type='custom'")

    periods = []
    reference_date = start
    while True:
        t1, t2 = generate_period(cycle_type, reference_date)
        periods.append((t1, t2))
        if t2 >= end:
            break
        reference_date = t2 + timedelta(days=1)
    return periods
