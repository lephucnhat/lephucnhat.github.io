# -*- coding: utf-8 -*-
"""JRC Tropical Moist Forest (TMF) post-2020 deforestation screening.

Provides:
  - ``TMF_CUTOFF_DATE``: the EUDR legal deforestation cutoff (2020-12-31).
  - ``MAIN_CLASS_NAMES_VI``: JRC TMF ``TransitionMap_MainClasses`` code ->
    Vietnamese label, ported/adapted from ``LVT_EUDR/core/analyzer.py``'s
    ``main_names``.
  - ``fetch_tmf_raster``: downloads (and caches locally) the 10x10-degree
    JRC TMF v1 COG tile covering a WGS-84 bbox, for a given layer
    (``"DeforestationYear"`` or ``"TransitionMap_MainClasses"``).
  - ``check_deforestation``: screens a WGS-84 polygon against both layers
    and returns a ``TmfResult`` classification.
  - ``TmfCheckTask``: a ``QgsTask`` batch worker running
    ``check_deforestation`` per lot without blocking the UI thread (mirrors
    ``core.change_detector.HarvestDetectionTask``'s pattern, Task 9/10).

Author: Phòng Sử dụng và Phát triển rừng — Chi cục Kiểm lâm tỉnh Quảng Trị
"""

import math
import hashlib
import os
from dataclasses import dataclass
from datetime import date

import numpy as np
try:
    from osgeo import gdal
except ImportError:  # pragma: no cover - allows unit testing outside OSGeo4W
    gdal = None

try:
    # shapely >= 2.0: non-deprecated top-level vectorized predicate.
    from shapely import contains_xy as _contains_xy
except ImportError:  # pragma: no cover - older shapely fallback
    from shapely.vectorized import contains as _contains_xy

try:
    from qgis.core import QgsTask
except ImportError:  # pragma: no cover - allows importing this module
    # outside a QGIS process (e.g. plain pytest without the qgis stack) for
    # the pure check_deforestation/fetch_tmf_raster tests; TmfCheckTask is
    # simply unavailable in that case.
    QgsTask = None


from .sentinel_stac import configure_gdal_vsicurl

try:
    from shapely.geometry import box as _shapely_box
    from shapely.ops import unary_union as _unary_union
except ImportError:  # pragma: no cover
    _shapely_box = None
    _unary_union = None

TMF_CUTOFF_DATE = date(2020, 12, 31)
#: FAO / EUDR Art. 2(4) & Vietnam Forestry Law minimum forest area (0.5 ha),
#: paired with minimum 10% canopy cover and 5 m tree height.
FAO_MIN_FOREST_HA = 0.5

#: JRC TMF ``TransitionMap_MainClasses`` v1_2025 code -> Vietnamese label
#: (aligned with LVT_EUDR/core/analyzer.py). Codes 10/20/30 represent
#: natural/regenerating forest classes; 10/20 are treated as primary/degraded
#: natural forest for pre-cutoff warning screening.
MAIN_CLASS_NAMES_VI = {
    10: "Rừng ẩm tự nhiên nguyên vẹn",
    20: "Rừng tự nhiên suy thoái",
    30: "Rừng tái sinh tự nhiên",
    41: "Đất phá rừng → Rừng trồng/CCN",
    42: "Đất phá rừng → Mặt nước",
    43: "Đất phá rừng → Đất khác/Nương rẫy",
    50: "Biến động rừng đang diễn ra",
    60: "Mặt nước thường xuyên/theo mùa",
    70: "Đất nông nghiệp / Phi rừng",
}

#: Deforestation / land-use conversion drivers (Drivers) from JRC TMF
#: TransitionMap_MainClasses & TransitionMap_Subtypes.
MAIN_CLASS_DRIVERS_VI = {
    10: "Tác động cục bộ trong vùng rừng ẩm tự nhiên",
    20: "Suy thoái rừng tự nhiên (khai thác chọn / tác động tán)",
    30: "Tác động trên rừng tái sinh tự nhiên",
    41: "Chuyển đổi sang rừng trồng / cây công nghiệp",
    42: "Chuyển đổi sang mặt nước / hồ chứa",
    43: "Phát rẫy / chuyển đổi sang đất canh tác, đất khác",
    50: "Biến động tán rừng đang diễn ra (2023–2025)",
    60: "Mở rộng mặt nước / ngập nước",
    70: "Mở rộng đất nông nghiệp / phi rừng",
}

SUBTYPE_DRIVERS_VI = {
    51: "Khai thác / mất tán rừng ngắn hạn (Subtype 51)",
    52: "Cháy rừng / mất tán do nhiệt độ cao (Subtype 52)",
    53: "Biến động tán rừng chưa phục hồi 2023–2025 (Subtype 53)",
}

_NATURAL_FOREST_CLASSES = {10, 20}

#: Verified EC JRC TMF v1_2025 Cloud-Optimized GeoTIFF endpoint on Source
#: Cooperative (matching LVT_EUDR/core/analyzer.py).
JRC_TMF_BASE_URL = (
    "https://data.source.coop/epoch/jrc-tmf/v1_2025/{tile_id}/{layer_name}.tif"
)


@dataclass
class TmfResult:
    status: str
    deforestation_year: "int | None"
    affected_ha: float
    dominant_class_vi: str
    driver_vi: str = ""
    loss_patches: list = None

    def __post_init__(self):
        if self.loss_patches is None:
            self.loss_patches = []


def _format_tile_id(lat_grid, lon_grid):
    lat_prefix = "N" if lat_grid >= 0 else "S"
    lon_prefix = "E" if lon_grid >= 0 else "W"
    return f"{lat_prefix}{abs(lat_grid):02d}_{lon_prefix}{abs(lon_grid):03d}"


def _tile_id_for_bbox(bbox_wgs84):
    """10x10-degree tile id (``N20_E100`` style for Source Cooperative JRC TMF
    v1_2025: latitude ceiled to the northern tile edge, longitude floored to
    the western edge).
    """
    minx, miny, maxx, maxy = bbox_wgs84
    center_lon = (minx + maxx) / 2.0
    center_lat = (miny + maxy) / 2.0

    lat_grid = int(math.ceil(center_lat / 10.0) * 10)
    lon_grid = int(math.floor(center_lon / 10.0) * 10)
    return _format_tile_id(lat_grid, lon_grid)


def _tiles_for_bbox(bbox_wgs84):
    """Return all 10x10-degree JRC TMF tile IDs intersecting ``bbox_wgs84`` (BUG-10)."""
    minx, miny, maxx, maxy = bbox_wgs84
    eps = 1e-9
    lon_start = int(math.floor((minx + eps) / 10.0) * 10)
    lon_end = int(math.floor((maxx - eps) / 10.0) * 10)
    lat_start = int(math.ceil((miny + eps) / 10.0) * 10)
    lat_end = int(math.ceil((maxy - eps) / 10.0) * 10)

    if lon_end < lon_start:
        lon_end = lon_start
    if lat_end < lat_start:
        lat_end = lat_start

    tiles = []
    for lat_g in range(lat_start, lat_end + 1, 10):
        for lon_g in range(lon_start, lon_end + 1, 10):
            tid = _format_tile_id(lat_g, lon_g)
            if tid not in tiles:
                tiles.append(tid)
    return tiles or [_tile_id_for_bbox(bbox_wgs84)]


def fetch_tmf_raster(layer_name, bbox_wgs84, cache_dir, pad=0.02):
    """Return a local path to the JRC TMF COG tile covering ``bbox_wgs84``.

    Checks ``cache_dir`` for an already-downloaded tile first; otherwise
    fetches it via ``gdal.Translate`` over ``/vsicurl/`` with fast multirange
    HTTP options enabled and caches it there. ``pad=0.02`` (matching
    ``LVT_EUDR``) ensures tiny single-lot polygons still produce a valid
    raster window instead of a 0x0 crop.
    """
    tile_id = _tile_id_for_bbox(bbox_wgs84)
    minx, miny, maxx, maxy = bbox_wgs84
    p_minx = minx - pad
    p_miny = miny - pad
    p_maxx = maxx + pad
    p_maxy = maxy + pad
    bbox_key = hashlib.sha1(
        f"{p_minx:.5f},{p_miny:.5f},{p_maxx:.5f},{p_maxy:.5f}".encode("ascii")
    ).hexdigest()[:10]
    cache_path = os.path.join(cache_dir, f"JRC_TMF_{layer_name}_{tile_id}_{bbox_key}.tif")
    if os.path.exists(cache_path) and os.path.getsize(cache_path) > 0:
        return cache_path

    os.makedirs(cache_dir, exist_ok=True)
    configure_gdal_vsicurl()
    cog_url = JRC_TMF_BASE_URL.format(layer_name=layer_name, tile_id=tile_id)
    # projWin expects [ulx, uly, lrx, lry].
    proj_win = [p_minx, p_maxy, p_maxx, p_miny]

    ds = gdal.Translate(
        cache_path,
        "/vsicurl/" + cog_url,
        projWin=proj_win,
        creationOptions=["COMPRESS=DEFLATE", "PREDICTOR=1", "ZLEVEL=6"],
    )
    ds = None
    if not os.path.exists(cache_path) or os.path.getsize(cache_path) == 0:
        if os.path.exists(cache_path):
            try:
                os.remove(cache_path)
            except OSError:
                pass
        raise RuntimeError(f"Không tải được dữ liệu JRC TMF từ {cog_url}")
    return cache_path


def _pixel_centers(geotransform, shape):
    """lon/lat arrays of every pixel CENTER for a raster of ``shape``
    (rows, cols), from its real GDAL geotransform (never reconstructed --
    see Task 9's lesson on this)."""
    ulx, px_w, _, uly, _, px_h = geotransform
    rows, cols = shape
    col_idx, row_idx = np.meshgrid(np.arange(cols), np.arange(rows))
    lons = ulx + (col_idx + 0.5) * px_w
    lats = uly + (row_idx + 0.5) * px_h
    return lons, lats


def _empty_result():
    return TmfResult(
        status="Tuân thủ",
        deforestation_year=None,
        affected_ha=0.0,
        dominant_class_vi="Không xác định",
        driver_vi="",
        loss_patches=[],
    )


def _infer_driver_vi(in_class, post_cutoff_mask, in_subtype=None):
    """Infer deforestation / disturbance driver (Vietnamese) from TMF classes/subtypes."""
    target_mask = post_cutoff_mask if post_cutoff_mask.any() else np.ones_like(in_class, dtype=bool)
    target_classes = in_class[target_mask]
    if target_classes.size == 0:
        return ""
    vals, cnts = np.unique(target_classes, return_counts=True)
    # Prefer explicit conversion/disturbance codes (41,42,43,50) over background if present.
    driver_code = int(vals[np.argmax(cnts)])
    for priority_code in (43, 41, 42, 50):
        if priority_code in vals:
            driver_code = priority_code
            break
    base_driver = MAIN_CLASS_DRIVERS_VI.get(driver_code, MAIN_CLASS_NAMES_VI.get(driver_code, ""))

    if in_subtype is not None:
        sub_vals = in_subtype[target_mask]
        for s_code in (51, 52, 53):
            if (sub_vals == s_code).any():
                sub_desc = SUBTYPE_DRIVERS_VI[s_code]
                if base_driver:
                    return f"{base_driver}; {sub_desc}"
                return sub_desc
    return base_driver


def _extract_loss_patches(polygon_geom_wgs84, sub_year, sub_gt, cutoff_year):
    """Vectorize post-cutoff loss pixels clipped to ``polygon_geom_wgs84``."""
    if _shapely_box is None or _unary_union is None:
        return []
    ulx, px_w, _, uly, _, px_h = sub_gt
    if px_w == 0 or px_h == 0:
        return []
    half_w = abs(px_w) / 2.0
    half_h = abs(px_h) / 2.0

    rows, cols = np.where(sub_year > cutoff_year)
    if rows.size == 0:
        return []

    by_year = {}
    for r, c in zip(rows.tolist(), cols.tolist()):
        yr = int(sub_year[r, c])
        cx = ulx + (c + 0.5) * px_w
        cy = uly + (r + 0.5) * px_h
        px_poly = _shapely_box(cx - half_w, cy - half_h, cx + half_w, cy + half_h)
        if px_poly.intersects(polygon_geom_wgs84):
            by_year.setdefault(yr, []).append(px_poly)

    patches = []
    for yr in sorted(by_year.keys()):
        merged = _unary_union(by_year[yr]).intersection(polygon_geom_wgs84)
        if merged.is_empty:
            continue
        geoms = [merged] if merged.geom_type == "Polygon" else list(getattr(merged, "geoms", []))
        for g in geoms:
            if g.geom_type == "Polygon" and not g.is_empty:
                patches.append({
                    "year": yr,
                    "exterior": list(g.exterior.coords),
                })
    return patches


def _check_deforestation_from_arrays(
    polygon_geom_wgs84,
    year_array,
    class_array,
    geotransform,
    cutoff_date=TMF_CUTOFF_DATE,
    subtype_array=None,
):
    """Evaluate JRC TMF deforestation/warning/compliance from preloaded arrays.

    Slices the array window covering ``polygon_geom_wgs84.bounds`` first so
    running over a large regional AOI raster stays fast per lot.
    """
    bbox = polygon_geom_wgs84.bounds
    ulx, px_w, _, uly, _, px_h = geotransform
    rows, cols = year_array.shape

    if px_w != 0 and px_h != 0:
        c0 = max(0, int(math.floor((bbox[0] - ulx) / px_w)) - 1)
        c1 = min(cols, int(math.ceil((bbox[2] - ulx) / px_w)) + 1)
        r0 = max(0, int(math.floor((bbox[3] - uly) / px_h)) - 1)
        r1 = min(rows, int(math.ceil((bbox[1] - uly) / px_h)) + 1)
        if c1 <= c0 or r1 <= r0:
            return _empty_result()
        sub_year = year_array[r0:r1, c0:c1]
        sub_class = class_array[r0:r1, c0:c1]
        sub_sub = subtype_array[r0:r1, c0:c1] if subtype_array is not None else None
        sub_gt = (ulx + c0 * px_w, px_w, 0.0, uly + r0 * px_h, 0.0, px_h)
    else:
        sub_year = year_array
        sub_class = class_array
        sub_sub = subtype_array
        sub_gt = geotransform

    lons, lats = _pixel_centers(sub_gt, sub_year.shape)
    in_polygon = _contains_xy(polygon_geom_wgs84, lons, lats)
    used_intersect_fallback = False

    if not in_polygon.any():
        # BUG-07 fallback for narrow strip parcels (<30m wide along streams/ridges)
        # that contain no 30m pixel center: test geometric intersection between
        # each pixel footprint box and the polygon, then fall back to sampling
        # the pixel containing polygon.representative_point().
        s_ulx, s_px_w, _, s_uly, _, s_px_h = sub_gt
        half_w = abs(s_px_w) / 2.0
        half_h = abs(s_px_h) / 2.0
        intersect_mask = np.zeros(sub_year.shape, dtype=bool)
        if _shapely_box is not None and half_w > 0 and half_h > 0:
            sub_rows, sub_cols = sub_year.shape
            for r in range(sub_rows):
                for c in range(sub_cols):
                    cx = float(lons[r, c])
                    cy = float(lats[r, c])
                    px_box = _shapely_box(cx - half_w, cy - half_h, cx + half_w, cy + half_h)
                    if px_box.intersects(polygon_geom_wgs84):
                        intersect_mask[r, c] = True

        if not intersect_mask.any() and s_px_w != 0 and s_px_h != 0:
            try:
                rep_pt = polygon_geom_wgs84.representative_point()
                rc = int(math.floor((rep_pt.x - s_ulx) / s_px_w))
                rr = int(math.floor((rep_pt.y - s_uly) / s_px_h))
                if 0 <= rr < sub_year.shape[0] and 0 <= rc < sub_year.shape[1]:
                    intersect_mask[rr, rc] = True
            except Exception:
                pass

        if not intersect_mask.any():
            return _empty_result()

        in_polygon = intersect_mask
        used_intersect_fallback = True

    in_year = sub_year[in_polygon]
    in_class = sub_class[in_polygon]
    in_sub = sub_sub[in_polygon] if sub_sub is not None else None

    values, counts = np.unique(in_class, return_counts=True)
    mode_class = int(values[np.argmax(counts)])
    dominant_class_vi = MAIN_CLASS_NAMES_VI.get(mode_class, "Không xác định")

    post_cutoff_mask = in_year > cutoff_date.year
    pre_cutoff_mask = (in_year > 0) & (in_year <= cutoff_date.year)

    if post_cutoff_mask.any():
        post_years = in_year[post_cutoff_mask]
        deforestation_year = int(post_years.max())

        center_lat = (bbox[1] + bbox[3]) / 2.0
        deg2_to_ha = (111320.0 ** 2 * math.cos(math.radians(center_lat))) / 10000.0
        pixel_area_ha = deg2_to_ha * abs(px_w) * abs(px_h)
        if used_intersect_fallback and _shapely_box is not None and px_w != 0 and px_h != 0:
            # Compute exact intersected area for narrow parcels so a 15m strip
            # does not get inflated to a full 30m x 30m pixel area.
            s_ulx, s_px_w, _, s_uly, _, s_px_h = sub_gt
            half_w = abs(s_px_w) / 2.0
            half_h = abs(s_px_h) / 2.0
            hit_rows, hit_cols = np.where(in_polygon & (sub_year > cutoff_date.year))
            inter_deg2 = 0.0
            for r, c in zip(hit_rows.tolist(), hit_cols.tolist()):
                cx = float(lons[r, c])
                cy = float(lats[r, c])
                px_box = _shapely_box(cx - half_w, cy - half_h, cx + half_w, cy + half_h)
                inter_deg2 += px_box.intersection(polygon_geom_wgs84).area
            affected_ha = round(max(inter_deg2 * deg2_to_ha, 0.0001), 4)
        else:
            affected_ha = round(float(post_cutoff_mask.sum()) * pixel_area_ha, 4)
        driver_vi = _infer_driver_vi(in_class, post_cutoff_mask, in_sub)
        loss_patches = _extract_loss_patches(polygon_geom_wgs84, sub_year, sub_gt, cutoff_date.year)

        # Any post-2020 deforestation inside a forest meeting FAO criteria
        # (>= 0.5 ha, >= 10% canopy, >= 5 m height) is flagged "Vi phạm"
        # regardless of how small the encroached area is; acacia rotation
        # / non-forest patches are clarified in the HTML/report guidance.
        return TmfResult(
            status="Vi phạm",
            deforestation_year=deforestation_year,
            affected_ha=affected_ha,
            dominant_class_vi=dominant_class_vi,
            driver_vi=driver_vi,
            loss_patches=loss_patches,
        )

    if mode_class == 50 or (mode_class in _NATURAL_FOREST_CLASSES and pre_cutoff_mask.any()):
        driver_vi = _infer_driver_vi(in_class, np.zeros_like(in_class, dtype=bool), in_sub)
        if not driver_vi:
            driver_vi = MAIN_CLASS_DRIVERS_VI.get(mode_class, "")
        return TmfResult(
            status="Cảnh báo",
            deforestation_year=None,
            affected_ha=0.0,
            dominant_class_vi=dominant_class_vi,
            driver_vi=driver_vi,
            loss_patches=[],
        )

    return TmfResult(
        status="Tuân thủ",
        deforestation_year=None,
        affected_ha=0.0,
        dominant_class_vi=dominant_class_vi,
        driver_vi="",
        loss_patches=[],
    )


def check_deforestation(polygon_geom_wgs84, cache_dir, cutoff_date=TMF_CUTOFF_DATE):
    """Screen a WGS-84 polygon for post-cutoff (default: post-2020-12-31)
    JRC TMF-detected deforestation.
    """
    bbox = polygon_geom_wgs84.bounds

    year_path = fetch_tmf_raster("DeforestationYear", bbox, cache_dir)
    class_path = fetch_tmf_raster("TransitionMap_MainClasses", bbox, cache_dir)

    year_ds = gdal.Open(year_path)
    year_array = year_ds.GetRasterBand(1).ReadAsArray()
    geotransform = year_ds.GetGeoTransform()
    year_ds = None

    class_ds = gdal.Open(class_path)
    class_array = class_ds.GetRasterBand(1).ReadAsArray()
    class_ds = None

    # BUG-10: Also load TransitionMap_Subtypes in single-lot check_deforestation()
    # so Drivers classification matches batch TmfCheckTask 100%.
    subtype_array = None
    try:
        sub_path = fetch_tmf_raster("TransitionMap_Subtypes", bbox, cache_dir)
        sub_ds = gdal.Open(sub_path)
        if sub_ds is not None:
            subtype_array = sub_ds.GetRasterBand(1).ReadAsArray()
            sub_ds = None
    except Exception:
        subtype_array = None

    return _check_deforestation_from_arrays(
        polygon_geom_wgs84,
        year_array,
        class_array,
        geotransform,
        cutoff_date,
        subtype_array=subtype_array,
    )


if QgsTask is not None:

    class TmfCheckTask(QgsTask):
        """Non-blocking background task running ``check_deforestation`` over
        many lots (mirrors ``core.change_detector.HarvestDetectionTask``).
        """

        def __init__(self, lots, cache_dir, cutoff_date=TMF_CUTOFF_DATE):
            super().__init__(f"CheckCCRQT: dò JRC TMF {len(lots)} lô", QgsTask.Flag.CanCancel)
            self.lots = lots
            self.cache_dir = cache_dir
            self.cutoff_date = cutoff_date
            self.results = []
            self.errors = []

        def run(self):
            total = len(self.lots)
            if total == 0:
                return True

            # Pre-fetch 1 regional AOI window per 10x10-deg tile (when span <= 2.0 deg)
            # so 963 lots trigger 2 COG reads total instead of 1,926 requests.
            tile_groups = {}
            for lot in self.lots:
                tid = _tile_id_for_bbox(lot["geometry_wgs84"].bounds)
                tile_groups.setdefault(tid, []).append(lot)

            tile_arrays = {}
            for tid, group_lots in tile_groups.items():
                if self.isCanceled():
                    return False
                if len(group_lots) <= 1:
                    continue
                bounds = [l["geometry_wgs84"].bounds for l in group_lots]
                ux0 = min(b[0] for b in bounds) - 0.005
                uy0 = min(b[1] for b in bounds) - 0.005
                ux1 = max(b[2] for b in bounds) + 0.005
                uy1 = max(b[3] for b in bounds) + 0.005
                if (ux1 - ux0) <= 2.0 and (uy1 - uy0) <= 2.0:
                    try:
                        union_bbox = (ux0, uy0, ux1, uy1)
                        yp = fetch_tmf_raster("DeforestationYear", union_bbox, self.cache_dir)
                        cp = fetch_tmf_raster("TransitionMap_MainClasses", union_bbox, self.cache_dir)
                        yds = gdal.Open(yp)
                        y_arr = yds.GetRasterBand(1).ReadAsArray()
                        gt = yds.GetGeoTransform()
                        yds = None
                        cds = gdal.Open(cp)
                        c_arr = cds.GetRasterBand(1).ReadAsArray()
                        cds = None
                        s_arr = None
                        try:
                            sp = fetch_tmf_raster("TransitionMap_Subtypes", union_bbox, self.cache_dir)
                            sds = gdal.Open(sp)
                            if sds is not None:
                                s_arr = sds.GetRasterBand(1).ReadAsArray()
                                sds = None
                        except Exception:
                            s_arr = None
                        tile_arrays[tid] = (y_arr, c_arr, gt, s_arr)
                    except Exception:
                        tile_arrays[tid] = None

            for i, lot in enumerate(self.lots):
                if self.isCanceled():
                    return False

                try:
                    tid = _tile_id_for_bbox(lot["geometry_wgs84"].bounds)
                    cached = tile_arrays.get(tid)
                    if cached is not None:
                        y_arr, c_arr, gt, s_arr = cached
                        result = _check_deforestation_from_arrays(
                            lot["geometry_wgs84"], y_arr, c_arr, gt, self.cutoff_date, subtype_array=s_arr
                        )
                    else:
                        result = check_deforestation(
                            lot["geometry_wgs84"], self.cache_dir, self.cutoff_date
                        )
                    self.results.append({
                        "id_lo": lot.get("id_lo"),
                        "tmf_status": result.status,
                        "tmf_year": result.deforestation_year,
                        "tmf_ha": result.affected_ha,
                        "tmf_dominant_class": result.dominant_class_vi,
                        "tmf_driver": result.driver_vi,
                        "loss_patches": result.loss_patches,
                    })
                except Exception as exc:
                    self.errors.append({
                        "id_lo": lot.get("id_lo"),
                        "error": str(exc),
                        "error_type": type(exc).__name__,
                    })

                self.setProgress((i + 1) / total * 100.0)

            return True
