# -*- coding: utf-8 -*-
"""Sentinel-2 STAC search and COG windowed band reads.

Provides:
  - ``search_scenes`` / ``find_nearest_scene``: query a STAC API (default
    Earth Search / AWS Element84) for Sentinel-2 L2A scenes over a bbox and
    date range.
  - ``read_band_window`` / ``read_bands_for_bbox``: windowed reads of
    Cloud-Optimized GeoTIFF band assets (local path or remote ``http(s)``
    href) clipped to a WGS-84 bounding box.
  - ``scan_local_folder``: offline fallback that groups local Sentinel-2
    band files on disk into ``SceneItem`` objects by acquisition date,
    parsed from ESA-style filenames.

Author: Phòng Sử dụng và Phát triển rừng — Chi cục Kiểm lâm tỉnh Quảng Trị
"""

import os
import re
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta

import requests
try:
    from osgeo import gdal
except ImportError:  # pragma: no cover - allows unit testing outside OSGeo4W
    gdal = None

DEFAULT_STAC_URL = "https://earth-search.aws.element84.com/v1/search"

#: ``requests`` (connect, read) timeout in seconds for STAC searches.
STAC_TIMEOUT = (10, 60)

#: Retry backoff delays (seconds) for transient STAC network/HTTP errors (BUG-09).
_RETRY_BACKOFFS = (1.0, 2.0, 4.0)
_RETRYABLE_STATUS_CODES = {429, 500, 502, 503, 504}


@dataclass
class SceneItem:
    id: str
    datetime: datetime
    cloud_cover: float
    assets: dict = field(default_factory=dict)
    bbox: tuple = None


_GDAL_VSICURL_CONFIGURED = False


def configure_gdal_vsicurl():
    """Configure GDAL /vsicurl/ options for fast remote COG windowed reads."""
    global _GDAL_VSICURL_CONFIGURED
    if _GDAL_VSICURL_CONFIGURED:
        return
    gdal.SetConfigOption("GDAL_DISABLE_READDIR_ON_OPEN", "EMPTY_DIR")
    gdal.SetConfigOption("GDAL_HTTP_MULTIRANGE", "YES")
    gdal.SetConfigOption("GDAL_HTTP_MERGE_CONSECUTIVE_RANGES", "YES")
    gdal.SetConfigOption("GDAL_HTTP_UNSAFESSL", "YES")
    gdal.SetConfigOption("CPL_VSIL_CURL_ALLOWED_EXTENSIONS", ".tif,.TIF,.jp2,.vrt")
    gdal.SetConfigOption("VSI_CACHE", "TRUE")
    gdal.SetConfigOption("VSI_CACHE_SIZE", "50000000")
    gdal.SetConfigOption("GDAL_HTTP_CONNECTTIMEOUT", "10")
    gdal.SetConfigOption("GDAL_HTTP_TIMEOUT", "30")
    _GDAL_VSICURL_CONFIGURED = True


def _parse_stac_datetime(value):
    """Parse an ISO8601 STAC datetime string (trailing 'Z' allowed)."""
    if value.endswith("Z"):
        value = value[:-1] + "+00:00"
    return datetime.fromisoformat(value)


def _stac_request_with_retry(method, url, json_body=None, max_retries=3):
    """Execute an HTTP request to a STAC endpoint with exponential backoff.

    Retries up to ``max_retries`` times (1s -> 2s -> 4s) on network errors,
    timeouts, or HTTP 429/5xx responses (BUG-09).
    """
    last_exc = None
    attempts = max(1, int(max_retries))
    for attempt in range(attempts):
        try:
            if method.upper() == "GET":
                resp = requests.get(url, timeout=STAC_TIMEOUT)
            else:
                resp = requests.post(url, json=json_body, timeout=STAC_TIMEOUT)

            if resp.status_code in _RETRYABLE_STATUS_CODES and attempt < attempts - 1:
                delay = _RETRY_BACKOFFS[min(attempt, len(_RETRY_BACKOFFS) - 1)]
                time.sleep(delay)
                continue

            resp.raise_for_status()
            return resp
        except requests.RequestException as exc:
            last_exc = exc
            if attempt < attempts - 1:
                delay = _RETRY_BACKOFFS[min(attempt, len(_RETRY_BACKOFFS) - 1)]
                time.sleep(delay)
                continue
            raise
    if last_exc is not None:
        raise last_exc


def _extract_next_link(payload):
    """Find the STAC ``rel == 'next'`` link dict if present."""
    for link in payload.get("links", []) or []:
        if isinstance(link, dict) and link.get("rel") == "next" and link.get("href"):
            return link
    return None


def search_scenes(
    bbox,
    date_from,
    date_to,
    max_cloud=30,
    limit=50,
    stac_url=DEFAULT_STAC_URL,
    max_items=1000,
):
    """POST a STAC search for Sentinel-2 L2A scenes with automatic pagination.

    Follows STAC API v1.0 ``rel == 'next'`` links (both POST body/merge and
    GET href) up to ``max_items`` (default 1000) so 1-2 year time series are
    never silently truncated (BUG-06).
    """
    base_body = {
        "collections": ["sentinel-2-l2a"],
        "bbox": list(bbox),
        "datetime": f"{date_from.isoformat()}T00:00:00Z/{date_to.isoformat()}T23:59:59Z",
        "query": {"eo:cloud_cover": {"lt": max_cloud}},
        "limit": min(int(limit), int(max_items)) if max_items else int(limit),
    }

    method = "POST"
    url = stac_url
    body = dict(base_body)

    scenes = []
    seen_ids = set()
    max_pages = 50

    for _page in range(max_pages):
        resp = _stac_request_with_retry(method, url, json_body=body if method == "POST" else None)
        payload = resp.json()
        features = payload.get("features", []) or []

        for feature in features:
            feature_id = feature.get("id")
            properties = feature.get("properties", {})
            raw_datetime = properties.get("datetime")
            if feature_id is None or raw_datetime is None:
                continue
            if feature_id in seen_ids:
                continue
            seen_ids.add(feature_id)
            dt = _parse_stac_datetime(raw_datetime)
            cloud_cover = properties.get("eo:cloud_cover", 100.0)
            assets = {
                name: asset_info["href"]
                for name, asset_info in feature.get("assets", {}).items()
                if "href" in asset_info
            }
            raw_bbox = feature.get("bbox")
            scene_bbox = (
                tuple(raw_bbox[:4])
                if isinstance(raw_bbox, (list, tuple)) and len(raw_bbox) >= 4
                else None
            )
            scenes.append(
                SceneItem(
                    id=feature_id,
                    datetime=dt,
                    cloud_cover=cloud_cover,
                    assets=assets,
                    bbox=scene_bbox,
                )
            )
            if max_items and len(scenes) >= max_items:
                return scenes

        next_link = _extract_next_link(payload)
        if not next_link or not features:
            break

        next_method = str(next_link.get("method", "GET")).upper()
        next_href = next_link["href"]
        if next_method == "POST":
            next_body = next_link.get("body") or {}
            if next_link.get("merge", True):
                merged = dict(body if isinstance(body, dict) else base_body)
                merged.update(next_body)
                body = merged
            else:
                body = dict(next_body)
            method = "POST"
            url = next_href
        else:
            method = "GET"
            url = next_href
            body = None

    return scenes


def find_nearest_scene(bbox, target_date, window_days=15, max_cloud=30):
    """Find the lowest-cloud-cover scene within +/- window_days of target_date."""
    date_from = target_date - timedelta(days=window_days)
    date_to = target_date + timedelta(days=window_days)
    scenes = search_scenes(bbox, date_from, date_to, max_cloud=max_cloud)
    if not scenes:
        return None
    # Guard against a mix of None and float cloud_cover values (e.g. if
    # search_scenes is monkeypatched/stubbed and doesn't apply the same
    # "unknown -> worst case" default); None sorts last.
    return min(scenes, key=lambda s: s.cloud_cover if s.cloud_cover is not None else 100.0)


#: Output grid resolution (degrees) for ``read_band_window``: 0.0001 deg is
#: ~11.1 m north-south and ~10.6 m east-west at Quang Tri's ~17N -- close to
#: Sentinel-2's native 10 m (B02/B03/B04/B08) and a ~2x nearest-neighbor
#: upsample of the 20 m bands (B11/B12/SCL).
DEFAULT_GRID_RES_DEG = 0.0001


def _grid_size(span_deg, res_deg):
    return max(1, int(round(span_deg / res_deg)))


def read_band_window(href, bbox_wgs84, res_deg=DEFAULT_GRID_RES_DEG):
    """Read a COG band asset reprojected onto a WGS-84 grid over ``bbox_wgs84``.

    Returns ``(array, geotransform)`` -- both genuinely in EPSG:4326: the
    geotransform's origin is ``(minx, maxy)`` of the bbox and its pixel size
    is in degrees. ``href`` starting with "http" is read via GDAL's
    ``/vsicurl/`` driver; otherwise it is treated as a local path.

    Real Sentinel-2 L2A assets are in UTM (e.g. EPSG:32648 over Quang Tri),
    so this uses ``gdal.Warp`` (reproject + clip) rather than
    ``gdal.Translate(projWin=...)``: the latter would interpret the WGS-84
    degree bbox as UTM meters, fall completely outside the raster and
    silently return a 1x1 nodata array with a meters-scale geotransform.

    The output grid is fixed by the bbox alone (``outputBounds`` + a pixel
    count derived from ``res_deg``), NOT by the source raster, so every
    band read for the same bbox -- 10 m or 20 m natively -- lands on the
    exact same grid (same shape and geotransform). Nearest-neighbor
    resampling keeps discrete SCL class values intact and leaves
    reflectance values unblended for index math. Areas outside the source
    raster's footprint come back as 0 (Sentinel-2's nodata / SCL "no data"
    class), which ``cloud_mask_from_scl`` already treats as unusable.
    """
    if href.startswith("http"):
        configure_gdal_vsicurl()
        src_path = "/vsicurl/" + href
    else:
        src_path = href
    minx, miny, maxx, maxy = bbox_wgs84

    ds = gdal.Warp(
        "",
        src_path,
        format="MEM",
        dstSRS="EPSG:4326",
        outputBounds=(minx, miny, maxx, maxy),
        width=_grid_size(maxx - minx, res_deg),
        height=_grid_size(maxy - miny, res_deg),
        resampleAlg="near",
    )
    if ds is None:
        raise RuntimeError(f"Failed to read band window from {href!r}")
    try:
        array = ds.GetRasterBand(1).ReadAsArray()
        geotransform = ds.GetGeoTransform()
    finally:
        ds = None
    return array, geotransform


def read_bands_for_bbox(scene, bands, bbox):
    """Read multiple band assets of a SceneItem, clipped to bbox.

    Returns {band_name: array} for each band present in scene.assets.
    """
    result = {}
    for band in bands:
        href = scene.assets.get(band)
        if href is None:
            continue
        array, _gt = read_band_window(href, bbox)
        result[band] = array
    return result


# ===================================================================
# Local folder offline fallback
# ===================================================================

_RE_ESA = re.compile(r"S2[ABC]_MSIL[12][AC]_(\d{8})T")
_RE_DATE_UNDERSCORE = re.compile(r"(\d{4})[_-](\d{2})[_-](\d{2})")
_RE_DATE_COMPACT = re.compile(r"(\d{8})")

_BAND_SUFFIX_MAP = {
    "B02": "blue",
    "B03": "green",
    "B04": "red",
    "B08": "nir",
    "B11": "swir16",
    "B12": "swir22",
    "SCL": "scl",
}


def parse_scene_date(filename):
    """Extract acquisition date from a Sentinel-2 filename."""
    basename = os.path.basename(filename)

    m = _RE_ESA.search(basename)
    if m:
        return datetime.strptime(m.group(1), "%Y%m%d")

    m = _RE_DATE_UNDERSCORE.search(basename)
    if m:
        try:
            return datetime(int(m.group(1)), int(m.group(2)), int(m.group(3)))
        except ValueError:
            pass

    m = _RE_DATE_COMPACT.search(basename)
    if m:
        try:
            return datetime.strptime(m.group(1), "%Y%m%d")
        except ValueError:
            pass

    return None


def _band_key_for_filename(filename):
    """Map a filename's band suffix (e.g. '..._B04.tif') to an asset key."""
    stem = os.path.splitext(os.path.basename(filename))[0]
    for suffix, key in _BAND_SUFFIX_MAP.items():
        if stem.upper().endswith("_" + suffix):
            return key
    return None


def scan_local_folder(folder_path, extensions=(".tif", ".tiff", ".jp2", ".vrt")):
    """Scan a folder for Sentinel-2 band files and group into SceneItems by date.

    One SceneItem is produced per distinct acquisition date found; its
    `assets` dict is populated from filename band-suffix heuristics
    (e.g. "*_B04.tif" -> "red"). Cloud cover is unknown locally and set to 0.0.
    """
    folder = folder_path if isinstance(folder_path, str) else str(folder_path)
    if not os.path.isdir(folder):
        return []

    scenes_by_date = {}
    for root, _dirs, files in os.walk(folder):
        for name in files:
            ext = os.path.splitext(name)[1].lower()
            if ext not in extensions or name.startswith("."):
                continue
            full_path = os.path.join(root, name)
            dt = parse_scene_date(name)
            if dt is None:
                continue
            band_key = _band_key_for_filename(name)
            if band_key is None:
                continue
            scene_id = dt.strftime("%Y%m%d")
            scene = scenes_by_date.get(scene_id)
            if scene is None:
                scene = SceneItem(id=scene_id, datetime=dt, cloud_cover=0.0, assets={})
                scenes_by_date[scene_id] = scene
            scene.assets[band_key] = full_path

    return [scenes_by_date[k] for k in sorted(scenes_by_date.keys())]
