# -*- coding: utf-8 -*-
"""NDVI/NBR time-series harvest change detection.

Provides:
  - ``compute_index``: band-math spectral index (NDVI/NBR/NDMI) from a dict
    of band arrays.
  - ``cloud_mask_from_scl``: usable-pixel mask from a Sentinel-2 Scene
    Classification Layer (SCL) array.
  - ``zonal_mean_index``: mean index value (and valid-pixel ratio) over the
    pixels that fall inside a WGS-84 polygon.
  - ``detect_harvest_timeseries``: fetches a Sentinel-2 scene time series
    over a polygon's bbox, computes a zonal index per scene, and classifies
    harvest status (none / partial / clearcut / cloudy) from the drop in the
    index over time.
  - ``HarvestDetectionTask``: ``QgsTask`` batch worker running
    ``detect_harvest_timeseries`` per lot without blocking the UI thread.

Author: Phòng Sử dụng và Phát triển rừng — Chi cục Kiểm lâm tỉnh Quảng Trị
"""

import concurrent.futures
import numpy as np
from dataclasses import dataclass, field
from datetime import date

try:
    from shapely import contains_xy as _contains_xy
except ImportError:  # pragma: no cover - older shapely fallback
    from shapely.vectorized import contains as _contains_xy

try:
    from qgis.core import QgsTask
except ImportError:  # pragma: no cover - allows importing outside QGIS
    QgsTask = object

from . import sentinel_stac

STATUS_NONE = "Chưa khai thác"
STATUS_PARTIAL = "Khai thác một phần"
STATUS_CLEARCUT = "Đã khai thác trắng"
STATUS_CLOUDY = "Bị mây che / Thiếu dữ liệu"

# SCL classes treated as unusable: 0=no-data, 1=saturated/defective,
# 3=cloud shadow, 8=cloud-medium-probability, 9=cloud-high-probability,
# 10=thin cirrus.
_UNUSABLE_SCL_CLASSES = {0, 1, 3, 8, 9, 10}

# Bands required to compute each supported index.
_INDEX_BANDS = {
    "NDVI": ("nir", "red"),
    "NBR": ("nir", "swir22"),
    "NDMI": ("nir", "swir16"),
}

_VALID_RATIO_CLOUDY_THRESHOLD = 0.6


@dataclass
class HarvestDetectionResult:
    status: str
    harvest_date: "date | None"
    series: list = field(default_factory=list)
    pct_decline: float = 0.0


def compute_index(bands, index="NDVI"):
    """Compute a spectral index array from a dict of band arrays.

    ``index`` is one of "NDVI", "NBR", "NDMI". Division-by-zero and
    invalid-value (0/0) pixels are returned as NaN rather than raising or
    producing inf.
    """
    band_a_name, band_b_name = _INDEX_BANDS[index]
    band_a = np.asarray(bands[band_a_name], dtype="float64")
    band_b = np.asarray(bands[band_b_name], dtype="float64")

    numerator = band_a - band_b
    denominator = band_a + band_b
    with np.errstate(divide="ignore", invalid="ignore"):
        result = numerator / denominator
    return np.where(denominator == 0, np.nan, result)


def cloud_mask_from_scl(scl_array):
    """Return a bool mask (True = usable) from a Sentinel-2 SCL array."""
    scl_array = np.asarray(scl_array)
    mask = np.ones(scl_array.shape, dtype=bool)
    for bad_class in _UNUSABLE_SCL_CLASSES:
        mask &= scl_array != bad_class
    return mask


def zonal_mean_index(index_array, cloud_mask, geotransform, polygon_geom_wgs84):
    """Mean index value and valid-pixel ratio over in-polygon pixels.

    ``geotransform`` is the GDAL-style 6-tuple
    ``(ulx, px_w, 0, uly, 0, px_h)``. Returns ``(nan, 0.0)`` if no pixel
    centers fall inside the polygon, rather than raising.
    """
    index_array = np.asarray(index_array)
    cloud_mask = np.asarray(cloud_mask)
    ulx, px_w, _, uly, _, px_h = geotransform
    rows, cols = index_array.shape

    col_idx, row_idx = np.meshgrid(np.arange(cols), np.arange(rows))
    lons = ulx + (col_idx + 0.5) * px_w
    lats = uly + (row_idx + 0.5) * px_h

    in_polygon = _contains_xy(polygon_geom_wgs84, lons, lats)
    if not in_polygon.any():
        return float("nan"), 0.0

    in_polygon_and_valid = in_polygon & cloud_mask
    if not in_polygon_and_valid.any():
        return float("nan"), 0.0

    mean_val = float(index_array[in_polygon_and_valid].mean())
    valid_ratio = float(in_polygon_and_valid.sum() / in_polygon.sum())
    return mean_val, valid_ratio


def _classify_decline(pct_decline, drop_threshold=-0.20):
    """Map a positive fractional decline (0..1+) to a harvest status.

    Uses ``abs(drop_threshold)`` dynamically for ``STATUS_PARTIAL`` while
    keeping ``> 0.70`` for ``STATUS_CLEARCUT`` (BUG-08).
    """
    partial_thr = abs(float(drop_threshold)) if drop_threshold is not None else 0.20
    if pct_decline > 0.70:
        return STATUS_CLEARCUT
    if pct_decline >= partial_thr and pct_decline > 0.0:
        return STATUS_PARTIAL
    return STATUS_NONE


def _drop_threshold_walk(series, drop_threshold, confirm_windows=2):
    """Find the first confirmed harvest drop from the running-max baseline.

    Confirms a harvest event when EITHER (BUG-05):
      1. At least ``confirm_windows`` (default K=2) consecutive valid scenes
         starting at index ``i`` remain below ``drop_threshold`` relative to
         the pre-drop peak ``baseline`` (prevents false negatives on acacia
         plantations that are harvested early and regrow/replant by the end
         of a 12-24 month monitoring window), OR
      2. A deep drop (``>= 40%``) persists for at least 30 days across
         consecutive valid observations, OR
      3. All remaining valid observations through the end of the series stay
         below ``drop_threshold`` (for short tail drops).

    Returns ``(index, pct_decline)`` or ``(None, 0.0)``.
    """
    valid_points = []
    for idx, pt in enumerate(series):
        val = pt.get("value")
        if val is not None and val == val:  # NaN guard
            valid_points.append((idx, float(val), pt.get("date")))

    if len(valid_points) < 2:
        return None, 0.0

    k_req = max(1, int(confirm_windows))
    baseline = None

    for pos, (orig_idx, value, dt_i) in enumerate(valid_points):
        if baseline is None:
            baseline = value
            continue

        rel_change = (
            (value - baseline) / abs(baseline)
            if baseline != 0
            else (0.0 if value == 0 else -1.0)
        )

        if rel_change < drop_threshold:
            # Count consecutive valid scenes below drop_threshold starting at pos
            consec_count = 1
            min_rel = rel_change
            last_drop_dt = dt_i

            for nxt_pos in range(pos + 1, len(valid_points)):
                _nidx, nval, ndt = valid_points[nxt_pos]
                nrel = (
                    (nval - baseline) / abs(baseline)
                    if baseline != 0
                    else (0.0 if nval == 0 else -1.0)
                )
                if nrel < drop_threshold:
                    consec_count += 1
                    if nrel < min_rel:
                        min_rel = nrel
                    last_drop_dt = ndt
                else:
                    break

            days_span = 0
            if dt_i is not None and last_drop_dt is not None:
                try:
                    days_span = (last_drop_dt - dt_i).days
                except Exception:
                    days_span = 0

            deep_drop_30d = (-min_rel >= 0.40) and (days_span >= 30)
            reaches_end = (pos + consec_count) == len(valid_points)
            confirmed = (
                consec_count >= k_req
                or deep_drop_30d
                or (reaches_end and consec_count >= 1)
            )
            if confirmed:
                pct_decline = min(1.0, max(0.0, -min_rel))
                return orig_idx, pct_decline
            # Single-scene transient dip (cloud/shadow residual) -> ignore
            # without lowering baseline.
        else:
            baseline = max(baseline, value)

    return None, 0.0


def _read_scene_bands(scene, band_names, bbox):
    """Read multiple band arrays for a scene, each with its OWN real
    geotransform from ``sentinel_stac.read_band_window``.

    ``sentinel_stac.read_bands_for_bbox`` discards the per-band geotransform
    that GDAL's windowed read actually computes, so it is not used here.
    Reconstructing a geotransform by evenly spanning the requested bbox
    across the returned array shape is WRONG: GDAL's actual output
    geotransform for a small window can differ from that naive
    reconstruction by double-digit percentages in pixel size and several
    meters in pixel-center position at window edges, which is enough to
    flip which boundary pixels ``zonal_mean_index`` counts as in-polygon.

    Returns ``(arrays, geotransforms)``, both ``dict[str, ...]`` keyed by
    band name. A band missing from ``scene.assets`` is silently skipped
    (consistent with ``read_bands_for_bbox``'s prior behavior).
    """
    arrays = {}
    geotransforms = {}
    for band_name in band_names:
        href = scene.assets.get(band_name)
        if href is None:
            continue
        array, geotransform = sentinel_stac.read_band_window(href, bbox)
        arrays[band_name] = array
        geotransforms[band_name] = geotransform
    return arrays, geotransforms


def _align_band_shapes(band_arrays):
    """Resample band arrays to a common shape so bands natively at
    different resolution (Sentinel-2 NIR/Red are 10m; SWIR11/12 and SCL are
    20m) can be combined in ``compute_index``/``cloud_mask_from_scl``
    without a numpy broadcasting error or silent pixel misalignment.

    The target shape is the largest (highest-resolution) shape among the
    given bands. Smaller bands are upsampled to it with nearest-neighbor
    repetition (``numpy.repeat``), which is exact for the clean 2x ratio
    between Sentinel-2's 10m and 20m grids. Raises ``ValueError`` with a
    specific message -- rather than letting a bad combination fail later
    with a cryptic broadcast error -- if a band's shape is not an
    integer-ratio multiple of the target shape.

    No-op (returns ``band_arrays`` unchanged) when all bands already share
    one shape -- which, since ``sentinel_stac.read_band_window`` now warps
    every band onto the same bbox-defined WGS-84 grid, is the normal case
    for real reads. Kept as a safety net for callers/readers that return
    native-resolution arrays (e.g. stubs, or a future offline reader).
    """
    shapes = {name: arr.shape for name, arr in band_arrays.items()}
    if len(set(shapes.values())) <= 1:
        return band_arrays

    target_shape = max(shapes.values(), key=lambda shape: shape[0] * shape[1])
    aligned = {}
    for name, arr in band_arrays.items():
        shape = arr.shape
        if shape == target_shape:
            aligned[name] = arr
            continue
        if target_shape[0] % shape[0] != 0 or target_shape[1] % shape[1] != 0:
            raise ValueError(
                f"Band '{name}' shape {shape} is not an integer-ratio multiple "
                f"of the target (highest-resolution) shape {target_shape}; "
                "cannot align band resolutions for a combined index/mask."
            )
        row_ratio = target_shape[0] // shape[0]
        col_ratio = target_shape[1] // shape[1]
        aligned[name] = np.repeat(np.repeat(arr, row_ratio, axis=0), col_ratio, axis=1)
    return aligned


def _bboxes_overlap(b1, b2):
    """Return True if two (minx, miny, maxx, maxy) boxes intersect."""
    return not (b1[2] < b2[0] or b1[0] > b2[2] or b1[3] < b2[1] or b1[1] > b2[3])


def _subsample_scenes_by_step(ordered_scenes, step_days):
    """Keep the lowest-cloud scene per ``step_days`` window (dekad cadence).

    When ``step_days`` is ``None`` or ``<= 1`` (or <= 2 scenes total), all
    scenes are returned unchanged.
    """
    if not step_days or step_days <= 1 or len(ordered_scenes) <= 2:
        return ordered_scenes

    start_date = ordered_scenes[0].datetime.date()
    buckets = {}
    for scene in ordered_scenes:
        bucket_idx = (scene.datetime.date() - start_date).days // int(step_days)
        current = buckets.get(bucket_idx)
        cloud = scene.cloud_cover if scene.cloud_cover is not None else 100.0
        if current is None:
            buckets[bucket_idx] = (cloud, scene)
        else:
            cur_cloud, _ = current
            if cloud < cur_cloud:
                buckets[bucket_idx] = (cloud, scene)
    return [buckets[k][1] for k in sorted(buckets.keys())]


def _read_scenes_parallel(ordered_scenes, needed_bands, bbox, max_workers=6):
    """Read required band windows across scenes concurrently."""
    tasks = []
    for idx, scene in enumerate(ordered_scenes):
        if not all(scene.assets.get(b) for b in needed_bands):
            continue
        for band_name in needed_bands:
            tasks.append((idx, band_name, scene.assets[band_name]))

    per_scene_arrays = {idx: {} for idx in range(len(ordered_scenes))}
    per_scene_gts = {idx: {} for idx in range(len(ordered_scenes))}

    if not tasks:
        return per_scene_arrays, per_scene_gts

    workers = min(max(1, int(max_workers or 1)), len(tasks))
    if workers == 1 or len(tasks) == 1:
        for idx, band_name, href in tasks:
            arr, gt = sentinel_stac.read_band_window(href, bbox)
            per_scene_arrays[idx][band_name] = arr
            per_scene_gts[idx][band_name] = gt
        return per_scene_arrays, per_scene_gts

    def _fetch_one(item):
        idx, band_name, href = item
        arr, gt = sentinel_stac.read_band_window(href, bbox)
        return idx, band_name, arr, gt

    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
        futures = [pool.submit(_fetch_one, t) for t in tasks]
        for fut in concurrent.futures.as_completed(futures):
            try:
                idx, band_name, arr, gt = fut.result()
                per_scene_arrays[idx][band_name] = arr
                per_scene_gts[idx][band_name] = gt
            except Exception:
                # Skip failed band read for this scene; caller skips incomplete scenes.
                pass

    return per_scene_arrays, per_scene_gts


def detect_harvest_timeseries(
    polygon_geom_wgs84,
    date_from,
    date_to,
    cloud_max=30,
    index="NDVI",
    drop_threshold=-0.20,
    step_days=10,
    stac_url=sentinel_stac.DEFAULT_STAC_URL,
    prefetched_scenes=None,
    offline_folder=None,
    max_workers=6,
):
    """Detect a harvest event from a Sentinel-2 index time series over a polygon.

    Supports:
      - Online STAC search (or ``prefetched_scenes`` shared across a batch).
      - Local GeoTIFF offline folder via ``offline_folder``.
      - ``step_days`` dekad/cadence subsampling (picks lowest-cloud scene per
        ``step_days`` window; set ``0`` or ``1`` to keep every scene).
      - Concurrent GDAL ``/vsicurl/`` band reads via ``ThreadPoolExecutor``.
    """
    bbox = polygon_geom_wgs84.bounds
    if prefetched_scenes is not None:
        scenes = [
            s for s in prefetched_scenes
            if (date_from is None or s.datetime.date() >= date_from)
            and (date_to is None or s.datetime.date() <= date_to)
            and (s.cloud_cover is None or s.cloud_cover <= cloud_max)
            and (getattr(s, "bbox", None) is None or _bboxes_overlap(s.bbox, bbox))
        ]
    elif offline_folder:
        local_scenes = sentinel_stac.scan_local_folder(offline_folder)
        scenes = [
            s for s in local_scenes
            if (date_from is None or s.datetime.date() >= date_from)
            and (date_to is None or s.datetime.date() <= date_to)
        ]
    else:
        scenes = sentinel_stac.search_scenes(
            bbox, date_from, date_to, max_cloud=cloud_max, stac_url=stac_url
        )

    if not scenes:
        return HarvestDetectionResult(
            status=STATUS_CLOUDY, harvest_date=None, series=[], pct_decline=0.0
        )

    # Dedupe by date (keep lowest cloud per date), sort ascending by datetime,
    # then subsample by step_days (dekad cadence) to avoid redundant reads.
    scenes_by_date = {}
    for scene in scenes:
        scene_date = scene.datetime.date()
        existing = scenes_by_date.get(scene_date)
        if existing is None:
            scenes_by_date[scene_date] = scene
        else:
            c_new = scene.cloud_cover if scene.cloud_cover is not None else 100.0
            c_old = existing.cloud_cover if existing.cloud_cover is not None else 100.0
            if c_new < c_old:
                scenes_by_date[scene_date] = scene

    ordered_scenes = sorted(scenes_by_date.values(), key=lambda s: s.datetime)
    ordered_scenes = _subsample_scenes_by_step(ordered_scenes, step_days)

    authoritative_band = _INDEX_BANDS[index][0]
    needed_bands = list(_INDEX_BANDS[index]) + ["scl"]

    per_scene_arrays, per_scene_gts = _read_scenes_parallel(
        ordered_scenes, needed_bands, bbox, max_workers=max_workers
    )

    series = []
    for idx, scene in enumerate(ordered_scenes):
        band_arrays = per_scene_arrays.get(idx, {})
        geotransforms = per_scene_gts.get(idx, {})
        if not all(b in band_arrays for b in needed_bands):
            continue
        band_arrays = _align_band_shapes(band_arrays)
        index_array = compute_index(band_arrays, index)
        cloud_mask = cloud_mask_from_scl(band_arrays["scl"])
        geotransform = geotransforms[authoritative_band]
        mean_val, valid_ratio = zonal_mean_index(
            index_array, cloud_mask, geotransform, polygon_geom_wgs84
        )
        series.append({
            "date": scene.datetime.date(),
            "value": mean_val,
            "valid_ratio": valid_ratio,
        })

    if not series:
        return HarvestDetectionResult(
            status=STATUS_CLOUDY, harvest_date=None, series=[], pct_decline=0.0
        )

    harvest_idx, pct_decline = _drop_threshold_walk(series, drop_threshold)
    harvest_date = series[harvest_idx]["date"] if harvest_idx is not None else None
    status = _classify_decline(pct_decline, drop_threshold=drop_threshold)

    # Only mark STATUS_CLOUDY (and clear harvest_date) when fewer than 2
    # cloud-clear scenes (valid_ratio >= 0.6) are available AND no valid
    # harvest event was detected (BUG-08).
    clear_scene_count = sum(
        1
        for point in series
        if point.get("valid_ratio") is not None
        and point["valid_ratio"] == point["valid_ratio"]
        and point["valid_ratio"] >= _VALID_RATIO_CLOUDY_THRESHOLD
    )
    if clear_scene_count < 2 and harvest_idx is None:
        status = STATUS_CLOUDY
        harvest_date = None

    return HarvestDetectionResult(
        status=status, harvest_date=harvest_date, series=series, pct_decline=pct_decline
    )


class HarvestDetectionTask(QgsTask):
    """Non-blocking background task running harvest detection over many lots."""

    def __init__(self, lots, params):
        super().__init__(f"CheckCCRQT: dò {len(lots)} lô", QgsTask.Flag.CanCancel)
        self.lots = lots
        self.params = params
        self.results = []
        self.errors = []

    def run(self):
        total = len(self.lots)
        if total == 0:
            return True

        date_from = self.params.get("date_from")
        date_to = self.params.get("date_to")
        cloud_max = self.params.get("cloud_max", 30)
        stac_url = self.params.get("stac_url", sentinel_stac.DEFAULT_STAC_URL)
        offline_folder = self.params.get("offline_folder")
        max_workers = self.params.get("max_workers", 6)

        prefetched_scenes = None
        if offline_folder:
            prefetched_scenes = sentinel_stac.scan_local_folder(offline_folder)
        elif total > 1:
            bounds_list = [lot["geometry_wgs84"].bounds for lot in self.lots]
            ux0 = min(b[0] for b in bounds_list)
            uy0 = min(b[1] for b in bounds_list)
            ux1 = max(b[2] for b in bounds_list)
            uy1 = max(b[3] for b in bounds_list)
            if (ux1 - ux0) <= 1.5 and (uy1 - uy0) <= 1.5:
                try:
                    batch_scenes = sentinel_stac.search_scenes(
                        (ux0, uy0, ux1, uy1),
                        date_from,
                        date_to,
                        max_cloud=cloud_max,
                        limit=200,
                        stac_url=stac_url,
                        max_items=1000,
                    )
                    if batch_scenes:
                        prefetched_scenes = batch_scenes
                except Exception:
                    # Fall back to per-lot search so error rows match per-lot behavior.
                    prefetched_scenes = None

        for i, lot in enumerate(self.lots):
            if self.isCanceled():
                return False

            try:
                result = detect_harvest_timeseries(
                    lot["geometry_wgs84"],
                    date_from,
                    date_to,
                    cloud_max=cloud_max,
                    index=self.params.get("index", "NDVI"),
                    drop_threshold=self.params.get("drop_threshold", -0.20),
                    step_days=self.params.get("step_days", 10),
                    stac_url=stac_url,
                    prefetched_scenes=prefetched_scenes,
                    offline_folder=offline_folder,
                    max_workers=max_workers,
                )
                self.results.append({
                    "id_lo": lot.get("id_lo"),
                    "status": result.status,
                    "harvest_date": result.harvest_date,
                    "series": result.series,
                    "pct_decline": result.pct_decline,
                })
            except Exception as exc:
                self.errors.append({
                    "id_lo": lot.get("id_lo"),
                    "error": str(exc),
                    "error_type": type(exc).__name__,
                })

            self.setProgress((i + 1) / total * 100.0)

        return True
