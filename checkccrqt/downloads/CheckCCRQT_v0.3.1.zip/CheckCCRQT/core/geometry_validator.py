"""Geometry, attribute and area validation for a CCR polygon layer.

``validate_layer`` is the sole public entry point: given a QgsVectorLayer, a
field-map dict shaped like ``core.field_mapper.auto_detect_fields``'s return
value, and the CRS to measure area in, it returns a ``ValidationResult``
aggregating per-feature issues (bad geometry, slivers, overlaps, gaps,
missing attributes, and declared-vs-computed area mismatches).

Every ``FeatureIssue.message`` is user-facing Vietnamese (100% Vietnamese UI
constraint); the ``ISSUE_TYPES`` values and severities stay as stable
internal ASCII codes that other code branches on -- exporters translate
them for display (``exporters.html_report``).
"""
# Defers annotation evaluation so ``str | None`` (PEP 604) doesn't raise
# TypeError at import time on Python 3.9 (QGIS 3.28/3.34 LTR on Windows).
from __future__ import annotations

from dataclasses import dataclass, field
from types import SimpleNamespace

from qgis.core import (
    NULL,
    QgsCoordinateTransform,
    QgsFeature,
    QgsGeometry,
    QgsSpatialIndex,
    QgsVectorLayer,
)

from .crs_manager import area_transform, compute_area_ha, resolve_area_crs

ISSUE_TYPES = SimpleNamespace(
    INVALID_GEOM="INVALID_GEOM",
    EMPTY_GEOM="EMPTY_GEOM",
    DUPLICATE_VERTEX="DUPLICATE_VERTEX",
    DUPLICATE_ID="DUPLICATE_ID",
    SLIVER="SLIVER",
    OVERLAP="OVERLAP",
    GAP="GAP",
    MISSING_ATTR="MISSING_ATTR",
    AREA_MISMATCH="AREA_MISMATCH",
)

_GEOM_ERROR_TYPES = {ISSUE_TYPES.INVALID_GEOM, ISSUE_TYPES.EMPTY_GEOM}

# Canonical field-map keys that have their own dedicated handling and should
# never be treated as a generic "optional attribute to check for null".
_SPECIAL_KEYS = {"id_lo", "dien_tich_kb"}

#: Vietnamese display label per canonical field-map key, for MISSING_ATTR
#: messages (mirrors ``ui.main_dialog.FIELD_LABELS``).
_FIELD_LABELS_VI = {
    "id_lo": "ID lô",
    "chu_ho": "Chủ hộ",
    "tieu_khu": "Tiểu khu",
    "khoanh": "Khoảnh",
    "lo": "Lô",
    "dien_tich_kb": "Diện tích khai báo",
    "nam_trong": "Năm trồng",
    "loai_cay": "Loài cây",
    "trang_thai_ccr": "Trạng thái chứng chỉ",
}


@dataclass
class FeatureIssue:
    fid: int
    id_lo: str
    issue_type: str
    message: str
    severity: str


@dataclass
class ValidationResult:
    total: int
    ok_count: int
    geom_error_count: int
    missing_attr_count: int
    area_mismatch_count: int
    issues: list = field(default_factory=list)
    per_feature: list = field(default_factory=list)


def _resolve_id_lo(feature: QgsFeature, id_lo_field: str | None) -> str:
    if id_lo_field:
        try:
            value = feature[id_lo_field]
        except KeyError:
            value = None
        if not _is_blank(value):
            return str(value)
    return str(feature.id())


def _has_duplicate_adjacent_vertex(geom: QgsGeometry) -> bool:
    try:
        vertices = list(geom.vertices())
    except Exception:
        return False
    for i in range(1, len(vertices)):
        prev = vertices[i - 1]
        cur = vertices[i]
        if prev.x() == cur.x() and prev.y() == cur.y():
            return True
    return False


def _is_blank(value) -> bool:
    if value is None or value == NULL:
        return True
    if isinstance(value, str) and value.strip() == "":
        return True
    return False


def _computed_area_ha(geom: QgsGeometry, transform: QgsCoordinateTransform) -> float | None:
    # Single shared routine (core.crs_manager) -- Tab 3's audit-record area
    # uses the exact same one, so Tab 2 and Tab 3 can't disagree.
    return compute_area_ha(geom, transform)


def validate_layer(
    layer: QgsVectorLayer,
    field_map: dict,
    area_crs,
    sliver_ha: float = 0.01,
    mismatch_pct: float = 5.0,
    check_gaps: bool = False,
    only_selected: bool = False,
) -> ValidationResult:
    id_lo_field = field_map.get("id_lo")
    dien_tich_field = field_map.get("dien_tich_kb")
    other_optional_fields = {
        key: fname
        for key, fname in field_map.items()
        if key not in _SPECIAL_KEYS and fname
    }

    # Area is only meaningful in a planar CRS. If a caller hands us a
    # geographic one (e.g. an EPSG:4326 layer's own CRS), measuring there
    # would yield degrees²/10000 and flag every real lot as SLIVER +
    # AREA_MISMATCH -- fall back to the layer's own projected CRS or the
    # local UTM zone instead (see core.crs_manager.resolve_area_crs).
    if area_crs is None or not area_crs.isValid() or area_crs.isGeographic():
        area_crs = resolve_area_crs(layer.crs(), None, layer.extent())
    transform = area_transform(layer.crs(), area_crs)

    features = list(layer.selectedFeatures()) if only_selected else list(layer.getFeatures())

    issues: list[FeatureIssue] = []
    per_feature: list[dict] = []

    # First pass: compute per-feature basics and collect valid geometries for
    # the spatial index used by overlap (and gap) detection.
    geom_errors_by_fid = {}
    computed_area_by_fid = {}
    valid_geoms = []  # list of (fid, geometry) for features without geom errors

    for f in features:
        fid = f.id()
        geom = f.geometry()
        local_issues: list[FeatureIssue] = []
        id_lo_value = _resolve_id_lo(f, id_lo_field)

        is_empty = geom is None or geom.isEmpty()
        is_invalid = False if is_empty else (not geom.isGeosValid())
        has_dup_vertex = False if is_empty else _has_duplicate_adjacent_vertex(geom)

        if is_empty:
            local_issues.append(FeatureIssue(
                fid, id_lo_value, ISSUE_TYPES.EMPTY_GEOM,
                "Hình học rỗng (lô không có ranh giới)", "error",
            ))
        elif is_invalid:
            local_issues.append(FeatureIssue(
                fid, id_lo_value, ISSUE_TYPES.INVALID_GEOM,
                "Hình học không hợp lệ (tự cắt, sai cấu trúc vòng ranh giới...)", "error",
            ))

        if has_dup_vertex:
            local_issues.append(FeatureIssue(
                fid, id_lo_value, ISSUE_TYPES.DUPLICATE_VERTEX,
                "Có đỉnh trùng lặp liền kề trên ranh giới", "warning",
            ))

        has_geom_error = is_empty or is_invalid
        geom_errors_by_fid[fid] = has_geom_error

        computed_area = None
        if not has_geom_error:
            computed_area = _computed_area_ha(geom, transform)
            if computed_area is not None:
                if computed_area < sliver_ha:
                    local_issues.append(
                        FeatureIssue(
                            fid, id_lo_value, ISSUE_TYPES.SLIVER,
                            f"Diện tích {computed_area:.4f} ha nhỏ hơn ngưỡng lô mảnh vụn {sliver_ha} ha",
                            "warning",
                        )
                    )

                if dien_tich_field:
                    declared_raw = f[dien_tich_field] if dien_tich_field in f.fields().names() else None
                    if not _is_blank(declared_raw):
                        try:
                            declared = float(declared_raw)
                        except (TypeError, ValueError):
                            declared = None
                        if declared is not None and declared != 0:
                            pct_diff = (computed_area - declared) / declared * 100.0
                            if abs(pct_diff) > mismatch_pct:
                                local_issues.append(
                                    FeatureIssue(
                                        fid,
                                        id_lo_value,
                                        ISSUE_TYPES.AREA_MISMATCH,
                                        f"Diện tích bản đồ {computed_area:.4f} ha lệch {pct_diff:+.1f}% "
                                        f"so với diện tích khai báo {declared:.4f} ha",
                                        "warning",
                                    )
                                )

            valid_geoms.append((fid, QgsGeometry(geom)))

        computed_area_by_fid[fid] = computed_area

        for key, fname in other_optional_fields.items():
            if fname not in f.fields().names():
                continue
            value = f[fname]
            if _is_blank(value):
                local_issues.append(
                    FeatureIssue(
                        fid, id_lo_value, ISSUE_TYPES.MISSING_ATTR,
                        f"Thiếu giá trị {_FIELD_LABELS_VI.get(key, key)} (trường '{fname}')",
                        "warning",
                    )
                )

        issues.extend(local_issues)
        per_feature.append(
            {
                "fid": fid,
                "id_lo": id_lo_value,
                "issue_types": [i.issue_type for i in local_issues],
                "computed_area_ha": computed_area,
            }
        )

    # Overlap detection via spatial index over valid geometries.
    if len(valid_geoms) > 1:
        index = QgsSpatialIndex()
        geom_by_fid = {}
        for fid, geom in valid_geoms:
            gf = QgsFeature()
            gf.setId(fid)
            gf.setGeometry(geom)
            index.addFeature(gf)
            geom_by_fid[fid] = geom

        overlap_fids = set()
        checked_pairs = set()
        for fid, geom in valid_geoms:
            candidate_ids = index.intersects(geom.boundingBox())
            for other_fid in candidate_ids:
                if other_fid == fid:
                    continue
                pair = tuple(sorted((fid, other_fid)))
                if pair in checked_pairs:
                    continue
                checked_pairs.add(pair)
                other_geom = geom_by_fid.get(other_fid)
                if other_geom is None:
                    continue
                if geom.intersects(other_geom):
                    try:
                        overlap_area = geom.intersection(other_geom).area()
                    except Exception:
                        overlap_area = 0
                    if overlap_area > 0:
                        overlap_fids.add(fid)
                        overlap_fids.add(other_fid)

        id_lo_by_fid = {pf["fid"]: pf["id_lo"] for pf in per_feature}
        for fid in overlap_fids:
            issue = FeatureIssue(
                fid, id_lo_by_fid.get(fid, str(fid)), ISSUE_TYPES.OVERLAP,
                "Ranh giới chồng lấn với lô khác", "warning",
            )
            issues.append(issue)
            for pf in per_feature:
                if pf["fid"] == fid:
                    pf["issue_types"].append(ISSUE_TYPES.OVERLAP)

    # Duplicate ID_LO detection (BUG-02b): normalize whitespace & case.
    if id_lo_field:
        seen_ids: dict[str, list[tuple[int, str]]] = {}
        for pf in per_feature:
            raw_id = pf["id_lo"]
            norm_id = " ".join(str(raw_id).strip().lower().split())
            if norm_id:
                seen_ids.setdefault(norm_id, []).append((pf["fid"], str(raw_id)))
        dup_fids: dict[int, tuple[str, int]] = {}
        for _norm_id, entries in seen_ids.items():
            if len(entries) > 1:
                for fid, raw_id in entries:
                    dup_fids[fid] = (raw_id, len(entries))
        if dup_fids:
            for pf in per_feature:
                fid = pf["fid"]
                if fid in dup_fids:
                    raw_id, cnt = dup_fids[fid]
                    issues.append(
                        FeatureIssue(
                            fid,
                            raw_id,
                            ISSUE_TYPES.DUPLICATE_ID,
                            f"Trùng mã lô '{raw_id}' (xuất hiện {cnt} lần trong hồ sơ)",
                            "error",
                        )
                    )
                    pf["issue_types"].append(ISSUE_TYPES.DUPLICATE_ID)

    # Gap detection: optional, gated behind check_gaps (BUG-04).
    # Detect genuine interior holes (interior rings) of unaryUnion combined
    # with a small local closing buffer (~10m) between adjacent parcels instead
    # of convexHull().difference(union_geom) which creates false positives on
    # scattered parcels.
    if check_gaps and len(valid_geoms) > 0:
        try:
            projected_geoms = []
            for _, g in valid_geoms:
                pg = QgsGeometry(g)
                pg.transform(transform)
                projected_geoms.append(pg)
            union_geom = QgsGeometry.unaryUnion(projected_geoms)
            if union_geom and not union_geom.isEmpty():
                # 1) Direct interior rings of unaryUnion
                gap_candidates = []
                polys = (
                    union_geom.asMultiPolygon()
                    if union_geom.isMultipart()
                    else [union_geom.asPolygon()]
                )
                for poly in polys:
                    if len(poly) > 1:
                        for hole_ring in poly[1:]:
                            hole_geom = QgsGeometry.fromPolygonXY([hole_ring])
                            if hole_geom and not hole_geom.isEmpty():
                                gap_candidates.append(hole_geom)

                # 2) Small local closing (buffer +10m then -10m) to catch narrow
                # sliver gaps between neighboring lots without spanning distant parcels.
                try:
                    closed = union_geom.buffer(10.0, 4).buffer(-10.0, 4)
                    local_gaps = closed.difference(union_geom)
                    if local_gaps and not local_gaps.isEmpty():
                        parts = (
                            local_gaps.asGeometryCollection()
                            if local_gaps.isMultipart()
                            else [local_gaps]
                        )
                        gap_candidates.extend(parts)
                except Exception:
                    pass

                if gap_candidates:
                    merged_gaps = QgsGeometry.unaryUnion(gap_candidates)
                    gap_parts = (
                        merged_gaps.asGeometryCollection()
                        if merged_gaps.isMultipart()
                        else [merged_gaps]
                    )
                    for part in gap_parts:
                        if part is None or part.isEmpty():
                            continue
                        part_area_ha = part.area() / 10000.0
                        if part_area_ha > sliver_ha:
                            issues.append(
                                FeatureIssue(
                                    -1,
                                    "",
                                    ISSUE_TYPES.GAP,
                                    f"Phát hiện khe hở nội bộ {part_area_ha:.4f} ha giữa các lô giáp ranh",
                                    "info",
                                )
                            )
        except Exception:
            pass

    total = len(features)
    geom_error_count = sum(1 for v in geom_errors_by_fid.values() if v)
    # Count distinct LOTS with >= 1 missing attribute (not issues: one lot
    # missing 3 fields is still one "lô thiếu dữ liệu").
    missing_attr_count = len({i.fid for i in issues if i.issue_type == ISSUE_TYPES.MISSING_ATTR})
    area_mismatch_count = sum(1 for i in issues if i.issue_type == ISSUE_TYPES.AREA_MISMATCH)

    fids_with_issues = {i.fid for i in issues}
    ok_count = sum(1 for f in features if f.id() not in fids_with_issues)

    return ValidationResult(
        total=total,
        ok_count=ok_count,
        geom_error_count=geom_error_count,
        missing_attr_count=missing_attr_count,
        area_mismatch_count=area_mismatch_count,
        issues=issues,
        per_feature=per_feature,
    )
