# -*- coding: utf-8 -*-
"""VN-2000 coordinate reference system catalog, reprojection and symbology.

Provides the CRS dropdown data used by Tab 1 of the CheckCCRQT dialog
(pinned entries for Quang Tri / Quang Binh plus a national VN-2000
catalog), a helper to turn a catalog entry into a real
``QgsCoordinateReferenceSystem``, a thin wrapper around the
``native:reprojectlayer`` processing algorithm, and a symbology helper
for coloring audited parcel layers.

Author: Phòng Sử dụng và Phát triển rừng — Chi cục Kiểm lâm tỉnh Quảng Trị
License: GPL-3.0

Danh mục hệ quy chiếu quốc gia VN-2000 múi chiếu 3° (k = 0.9999, x_0 = 500000)
được hiệu đính kinh tuyến trục theo Quyết định số 05/2007/QĐ-BTNMT ngày
27/02/2007 của Bộ Tài nguyên và Môi trường (sử dụng 7 tham số chuyển đổi
Helmert giữa WGS-84 và VN-2000). Các tỉnh Quảng Trị và Quảng Bình được ghim
riêng ở ``PINNED_CRS`` và không lặp lại trong ``NATIONAL_VN2000_CRS``.
"""

try:
    from qgis.core import QgsCoordinateReferenceSystem
except ImportError:  # pragma: no cover - allows importing outside QGIS
    QgsCoordinateReferenceSystem = None


# ---------------------------------------------------------------------------
# Pinned entries (exact values -- unit-tested verbatim, do not alter keys)
# ---------------------------------------------------------------------------

PINNED_CRS = [
    {
        "id": "qt_moi",
        "label": "Quảng Trị (Mới - sau sáp nhập) — VN-2000 / TM-3 106°00'",
        "lon_0": 106.0,
        "k": 0.9999,
        "x_0": 500000,
    },
    {
        "id": "qt_cu",
        "label": "Quảng Trị (Cũ) — VN-2000 / TM-3 106°15'",
        "lon_0": 106.25,
        "k": 0.9999,
        "x_0": 500000,
    },
    {
        "id": "qb_cu",
        "label": "Quảng Bình (Cũ) — VN-2000 / TM-3 106°00'",
        "lon_0": 106.0,
        "k": 0.9999,
        "x_0": 500000,
    },
]


# ---------------------------------------------------------------------------
# National VN-2000 catalog (QĐ 05/2007/QĐ-BTNMT, TM-3: k=0.9999, x_0=500000).
# Quảng Trị and Quảng Bình are pinned in PINNED_CRS above and intentionally
# excluded here to avoid duplicate entries in the UI dropdown (BUG-03).
# ---------------------------------------------------------------------------

def _tm3(slug, ten_tinh, lon_0):
    return {
        "id": slug,
        "label": f"{ten_tinh} — VN-2000 / TM-3 {lon_0}°",
        "lon_0": lon_0,
        "k": 0.9999,
        "x_0": 500000,
    }


NATIONAL_VN2000_CRS = [
    _tm3("lai_chau", "Lai Châu", 103.0),
    _tm3("dien_bien", "Điện Biên", 103.0),
    _tm3("son_la", "Sơn La", 104.0),
    _tm3("lao_cai", "Lào Cai", 104.75),
    _tm3("yen_bai", "Yên Bái", 104.75),
    _tm3("ha_giang", "Hà Giang", 105.5),
    _tm3("tuyen_quang", "Tuyên Quang", 106.0),
    _tm3("cao_bang", "Cao Bằng", 105.75),
    _tm3("bac_kan", "Bắc Kạn", 106.5),
    _tm3("lang_son", "Lạng Sơn", 107.25),
    _tm3("quang_ninh", "Quảng Ninh", 107.75),
    _tm3("phu_tho", "Phú Thọ", 104.75),
    _tm3("vinh_phuc", "Vĩnh Phúc", 105.0),
    _tm3("thai_nguyen", "Thái Nguyên", 106.5),
    _tm3("bac_giang", "Bắc Giang", 107.0),
    _tm3("bac_ninh", "Bắc Ninh", 105.5),
    _tm3("ha_noi", "Hà Nội", 105.0),
    _tm3("hung_yen", "Hưng Yên", 105.5),
    _tm3("hai_duong", "Hải Dương", 105.5),
    _tm3("hai_phong", "Hải Phòng", 105.75),
    _tm3("hoa_binh", "Hòa Bình", 106.0),
    _tm3("ha_nam", "Hà Nam", 105.0),
    _tm3("nam_dinh", "Nam Định", 105.5),
    _tm3("thai_binh", "Thái Bình", 105.5),
    _tm3("ninh_binh", "Ninh Bình", 105.0),
    _tm3("thanh_hoa", "Thanh Hóa", 105.0),
    _tm3("nghe_an", "Nghệ An", 104.75),
    _tm3("ha_tinh", "Hà Tĩnh", 105.5),
    _tm3("thua_thien_hue", "Thừa Thiên Huế", 107.0),
    _tm3("da_nang", "Đà Nẵng", 107.75),
    _tm3("quang_nam", "Quảng Nam", 107.75),
    _tm3("quang_ngai", "Quảng Ngãi", 108.0),
    _tm3("binh_dinh", "Bình Định", 108.25),
    _tm3("phu_yen", "Phú Yên", 108.5),
    _tm3("khanh_hoa", "Khánh Hòa", 108.25),
    _tm3("ninh_thuan", "Ninh Thuận", 108.25),
    _tm3("binh_thuan", "Bình Thuận", 108.5),
    _tm3("kon_tum", "Kon Tum", 107.5),
    _tm3("gia_lai", "Gia Lai", 108.5),
    _tm3("dak_lak", "Đắk Lắk", 108.5),
    _tm3("dak_nong", "Đắk Nông", 108.5),
    _tm3("lam_dong", "Lâm Đồng", 107.75),
    _tm3("binh_phuoc", "Bình Phước", 106.25),
    _tm3("tay_ninh", "Tây Ninh", 105.5),
    _tm3("binh_duong", "Bình Dương", 105.75),
    _tm3("dong_nai", "Đồng Nai", 107.75),
    _tm3("ba_ria_vung_tau", "Bà Rịa - Vũng Tàu", 107.75),
    _tm3("ho_chi_minh", "Thành phố Hồ Chí Minh", 105.75),
    _tm3("long_an", "Long An", 105.75),
    _tm3("tien_giang", "Tiền Giang", 105.75),
    _tm3("ben_tre", "Bến Tre", 105.75),
    _tm3("tra_vinh", "Trà Vinh", 105.5),
    _tm3("vinh_long", "Vĩnh Long", 105.5),
    _tm3("dong_thap", "Đồng Tháp", 105.0),
    _tm3("an_giang", "An Giang", 104.75),
    _tm3("kien_giang", "Kiên Giang", 104.5),
    _tm3("can_tho", "Cần Thơ", 105.0),
    _tm3("hau_giang", "Hậu Giang", 105.0),
    _tm3("soc_trang", "Sóc Trăng", 105.5),
    _tm3("bac_lieu", "Bạc Liêu", 105.0),
    _tm3("ca_mau", "Cà Mau", 104.5),
]


def get_crs_catalog():
    """Return the full CRS catalog, pinned entries first.

    Order: PINNED_CRS (exactly as-is) -> NATIONAL_VN2000_CRS -> WGS-84 ->
    a WGS-84 / UTM entry covering central Vietnam (zone 48N).
    """
    catalog = []
    catalog.extend(PINNED_CRS)
    catalog.extend(NATIONAL_VN2000_CRS)
    catalog.append({"id": "WGS84", "label": "WGS-84 (EPSG:4326)", "epsg": 4326})
    catalog.append({"id": "utm_48n", "label": "WGS-84 / UTM zone 48N (EPSG:32648)", "epsg": 32648})
    return catalog


# ---------------------------------------------------------------------------
# CRS construction
# ---------------------------------------------------------------------------

# Standard 7-parameter Helmert datum shift published for VN-2000 -> WGS-84.
VN2000_TOWGS84 = "-191.90441429,-39.30318279,-111.45032835,-0.00928836,0.01975479,-0.00427372,0.252906278"
_VN2000_TOWGS84 = VN2000_TOWGS84


def build_qgs_crs(entry):
    """Build a ``QgsCoordinateReferenceSystem`` from a catalog entry dict.

    Entries with an ``epsg`` key (e.g. the WGS-84 / UTM entries) are built
    via ``QgsCoordinateReferenceSystem.fromEpsgId``. VN-2000 entries
    (``lon_0``/``k``/``x_0``) are built from a proj4 string using VN-2000's
    standard datum-shift parameters.
    """
    if "epsg" in entry:
        return QgsCoordinateReferenceSystem.fromEpsgId(entry["epsg"])

    lon_0 = entry["lon_0"]
    k = entry["k"]
    x_0 = entry["x_0"]
    proj_str = (
        f"+proj=tmerc +lat_0=0 +lon_0={lon_0} +k={k} +x_0={x_0} +y_0=0 "
        f"+ellps=WGS84 +towgs84={_VN2000_TOWGS84} +units=m +no_defs"
    )
    return QgsCoordinateReferenceSystem.fromProj(proj_str)


# ---------------------------------------------------------------------------
# Area measurement (shared by Tab 2 validation and Tab 3 audit records)
# ---------------------------------------------------------------------------

def _is_planar(crs):
    return crs is not None and crs.isValid() and not crs.isGeographic()


def utm_crs_for_lonlat(lon, lat):
    """WGS-84 / UTM zone CRS (EPSG:326xx north, 327xx south) containing
    the given WGS-84 lon/lat -- the fallback planar CRS for area math when
    nothing better is available."""
    zone = int((lon + 180.0) // 6.0) + 1
    zone = min(max(zone, 1), 60)
    epsg = (32600 if lat >= 0 else 32700) + zone
    return QgsCoordinateReferenceSystem.fromEpsgId(epsg)


def resolve_area_crs(layer_crs, preferred_crs=None, extent=None):
    """Pick a genuinely PLANAR (meters) CRS to measure areas of a layer in.

    Precedence:
      1. ``layer_crs`` itself, if it is already projected -- the data's own
         survey CRS (usually VN-2000 TM-3), which is what declared areas
         were measured in.
      2. ``preferred_crs`` -- the CRS picked in Tab 1's "Hệ tọa độ" combo --
         if the layer is geographic and that pick is projected.
      3. The WGS-84 / UTM zone containing the centre of ``extent`` (a
         ``QgsRectangle`` in ``layer_crs``), or zone 48N (central Vietnam)
         if no usable extent is given.

    Never returns a geographic CRS, so ``area()`` can never be computed in
    degrees² again (the root cause of false SLIVER + AREA_MISMATCH flags on
    EPSG:4326 layers).
    """
    if _is_planar(layer_crs):
        return layer_crs
    if _is_planar(preferred_crs):
        return preferred_crs

    if extent is not None and not extent.isNull() and not extent.isEmpty() and layer_crs is not None \
            and layer_crs.isValid():
        from qgis.core import QgsCoordinateTransform, QgsPointXY, QgsProject

        wgs84 = QgsCoordinateReferenceSystem("EPSG:4326")
        center = QgsPointXY(extent.center())
        try:
            if layer_crs != wgs84:
                center = QgsCoordinateTransform(layer_crs, wgs84, QgsProject.instance()).transform(center)
            return utm_crs_for_lonlat(center.x(), center.y())
        except Exception:
            pass
    return QgsCoordinateReferenceSystem.fromEpsgId(32648)


def area_transform(source_crs, area_crs):
    """``QgsCoordinateTransform`` from a layer's CRS to its area CRS."""
    from qgis.core import QgsCoordinateTransform, QgsProject

    return QgsCoordinateTransform(source_crs, area_crs, QgsProject.instance())


def compute_area_ha(geom, transform):
    """Planar area of ``geom`` in hectares, after reprojecting a CLONE of it
    with ``transform`` (see ``area_transform``/``resolve_area_crs``).

    The ONE area routine used by both Tab 2 (``geometry_validator``) and
    Tab 3 (audit records' ``dien_tich_bando``), so the two can't disagree.
    Returns ``None`` for a null/empty geometry or a failed transform.
    """
    from qgis.core import QgsGeometry

    if geom is None or geom.isNull() or geom.isEmpty():
        return None
    try:
        projected = QgsGeometry(geom)
        projected.transform(transform)
        return projected.area() / 10000.0
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Reprojection
# ---------------------------------------------------------------------------

def reproject_layer(layer, target_crs):
    """Reproject ``layer`` to ``target_crs`` via the ``native:reprojectlayer``
    processing algorithm. Returns the resulting (in-memory) ``QgsVectorLayer``.

    ``processing`` is imported lazily so importing this module stays light
    (and importable outside a fully initialized QGIS processing registry).
    """
    import processing

    result = processing.run(
        "native:reprojectlayer",
        {
            "INPUT": layer,
            "TARGET_CRS": target_crs,
            "OUTPUT": "memory:",
        },
    )
    return result["OUTPUT"]


# ---------------------------------------------------------------------------
# Symbology
# ---------------------------------------------------------------------------

def apply_symbology(layer, fill_color, outline_color, outline_width, opacity, transparent_fill=False):
    """Apply a simple fill symbol to ``layer`` and repaint it.

    ``fill_color``/``outline_color`` are ``QColor`` instances, ``outline_width``
    is in millimeters, ``opacity`` is a 0.0-1.0 layer-wide transparency
    multiplier, and ``transparent_fill=True`` sets ``Qt.NoBrush`` so only the
    outline is drawn over a satellite basemap.
    """
    from qgis.PyQt.QtCore import Qt
    from qgis.core import QgsFillSymbol, QgsSingleSymbolRenderer

    symbol = QgsFillSymbol.createSimple({
        "color": fill_color.name(),
        "outline_color": outline_color.name(),
        "outline_width": str(outline_width),
    })
    symbol.setColor(fill_color)
    symbol.setOpacity(opacity)

    symbol_layer = symbol.symbolLayer(0)
    if symbol_layer is not None:
        if transparent_fill:
            symbol_layer.setBrushStyle(Qt.NoBrush)
        symbol_layer.setStrokeColor(outline_color)
        symbol_layer.setStrokeWidth(outline_width)

    renderer = QgsSingleSymbolRenderer(symbol)
    layer.setRenderer(renderer)
    layer.triggerRepaint()
