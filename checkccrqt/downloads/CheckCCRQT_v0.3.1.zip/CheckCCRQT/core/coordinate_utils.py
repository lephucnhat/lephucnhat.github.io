# -*- coding: utf-8 -*-
"""Vertex Distance Filtering and Coordinate Formatting.

Extracts polygon boundary vertices, filters by cumulative distance
along the perimeter, and formats coordinates in VN-2000 (.2f) or
WGS-84 (.6f) for map annotation and Word table insertion.

Algorithm: Adaptive Distance Thinning
  1. Extract exterior ring vertices V0..Vn
  2. Walk perimeter accumulating distance
  3. Show vertex only when cumulated distance >= threshold (e.g. 50m)
  4. Reset accumulator after each displayed vertex
  5. Always include V0 (start) and last corner before closing

Every function that converts between VN-2000 and WGS-84 takes an explicit
central meridian ``lon_0_deg`` with no hardcoded default, because the plugin
serves several provinces with different zones. Where a conversion is
optional (format_coordinate), a missing value raises ValueError.

Author: Phòng Sử dụng và Phát triển rừng — Chi cục Kiểm lâm tỉnh Quảng Trị
License: GPL-3.0
"""

import math

try:
    from .crs_manager import VN2000_TOWGS84
except Exception:  # pragma: no cover - standalone import fallback
    VN2000_TOWGS84 = "-191.90441429,-39.30318279,-111.45032835,-0.00928836,0.01975479,-0.00427372,0.252906278"


# Meters per degree latitude (meridional) and dynamic longitude helper
_DEG_TO_M_LAT = 110_574.0  # 1 degree latitude in meters
_DEG_TO_M_LON_EQ = 111_320.0  # 1 degree longitude at equator in meters


def _deg_to_m_lon(lat_deg):
    """Dynamic meters per degree of longitude at latitude ``lat_deg``."""
    return _DEG_TO_M_LON_EQ * math.cos(math.radians(lat_deg))


def _vn2000_proj_str(lon_0_deg):
    """Standard VN-2000 TM-3 PROJ string with 7-parameter Helmert shift."""
    return (
        f"+proj=tmerc +lat_0=0 +lon_0={lon_0_deg} +k=0.9999 +x_0=500000 +y_0=0 "
        f"+ellps=WGS84 +towgs84={VN2000_TOWGS84} +units=m +no_defs +type=crs"
    )


def vn2000_to_wgs84(x, y, lon_0_deg):
    """Convert VN-2000 coordinates (meters) to WGS-84 (degrees: lon, lat).

    Prioritizes ``QgsCoordinateTransform`` inside QGIS, falling back to
    ``pyproj.Transformer`` with full 7-parameter Helmert ``+towgs84`` shift.
    ``lon_0_deg`` is the central meridian of the caller's zone (required).
    """
    proj_str = _vn2000_proj_str(lon_0_deg)

    # 1. Prefer QGIS native transform when running inside QGIS
    try:
        from qgis.core import (
            QgsCoordinateReferenceSystem,
            QgsCoordinateTransform,
            QgsPointXY,
            QgsProject,
        )
        crs_vn = QgsCoordinateReferenceSystem.fromProj(proj_str)
        crs_wgs = QgsCoordinateReferenceSystem.fromEpsgId(4326)
        if crs_vn is not None and crs_vn.isValid() and crs_wgs.isValid():
            tr = QgsCoordinateTransform(crs_vn, crs_wgs, QgsProject.instance())
            pt = tr.transform(QgsPointXY(float(x), float(y)))
            if math.isfinite(pt.x()) and math.isfinite(pt.y()):
                return float(pt.x()), float(pt.y())
    except Exception:
        pass

    # 2. Fallback to pyproj with full 7-parameter Helmert shift
    try:
        import pyproj
        crs_vn = pyproj.CRS.from_proj4(proj_str)
        t = pyproj.Transformer.from_crs(crs_vn, pyproj.CRS.from_epsg(4326), always_xy=True)
        lon, lat = t.transform(x, y)
        return float(lon), float(lat)
    except Exception:
        pass

    # Pure Python Gauss-Kruger / Transverse Mercator inverse
    a = 6378137.0
    f = 1.0 / 298.257223563
    e2 = 2 * f - f * f
    e_prime2 = e2 / (1.0 - e2)
    k0 = 0.9999
    x0 = 500000.0
    y0 = 0.0

    x_p = (x - x0) / k0
    y_p = (y - y0) / k0

    phi = y_p / (a * (1 - e2/4 - 3*e2**2/64 - 5*e2**3/256))
    for _ in range(5):
        M = a * ((1 - e2/4 - 3*e2**2/64 - 5*e2**3/256)*phi
                 - (3*e2/8 + 3*e2**2/32 + 45*e2**3/1024)*math.sin(2*phi)
                 + (15*e2**2/256 + 45*e2**3/1024)*math.sin(4*phi)
                 - (35*e2**3/3072)*math.sin(6*phi))
        dM = a * (1 - e2) / ((1 - e2 * math.sin(phi)**2)**1.5)
        phi = phi + (y_p - M) / dM

    sin_phi = math.sin(phi)
    cos_phi = math.cos(phi)
    tan_phi = math.tan(phi)

    N = a / math.sqrt(1 - e2 * sin_phi**2)
    T = tan_phi**2
    C = e_prime2 * cos_phi**2
    D = x_p / N

    lat = phi - (N * tan_phi / (a * (1 - e2) / ((1 - e2 * sin_phi**2)**1.5))) * (
        D**2 / 2.0 - (5 + 3*T + 10*C - 4*C**2 - 9*e_prime2) * D**4 / 24.0
    )
    lon = math.radians(lon_0_deg) + (
        D - (1 + 2*T + C) * D**3 / 6.0
        + (5 - 2*C + 28*T - 3*C**2 + 8*e_prime2 + 24*T**2) * D**5 / 120.0
    ) / cos_phi

    return math.degrees(lon), math.degrees(lat)


def wgs84_to_vn2000(lon, lat, lon_0_deg):
    """Convert WGS-84 (lon, lat in degrees) to VN-2000 (x, y in meters).

    Prioritizes ``QgsCoordinateTransform`` inside QGIS, falling back to
    ``pyproj.Transformer`` with full 7-parameter Helmert ``+towgs84`` shift.
    ``lon_0_deg`` is the central meridian of the caller's zone (required).
    """
    proj_str = _vn2000_proj_str(lon_0_deg)

    # 1. Prefer QGIS native transform when running inside QGIS
    try:
        from qgis.core import (
            QgsCoordinateReferenceSystem,
            QgsCoordinateTransform,
            QgsPointXY,
            QgsProject,
        )
        crs_wgs = QgsCoordinateReferenceSystem.fromEpsgId(4326)
        crs_vn = QgsCoordinateReferenceSystem.fromProj(proj_str)
        if crs_vn is not None and crs_vn.isValid() and crs_wgs.isValid():
            tr = QgsCoordinateTransform(crs_wgs, crs_vn, QgsProject.instance())
            pt = tr.transform(QgsPointXY(float(lon), float(lat)))
            if math.isfinite(pt.x()) and math.isfinite(pt.y()):
                return float(pt.x()), float(pt.y())
    except Exception:
        pass

    # 2. Fallback to pyproj with full 7-parameter Helmert shift
    try:
        import pyproj
        crs_vn = pyproj.CRS.from_proj4(proj_str)
        t = pyproj.Transformer.from_crs(pyproj.CRS.from_epsg(4326), crs_vn, always_xy=True)
        x, y = t.transform(lon, lat)
        return float(x), float(y)
    except Exception:
        pass

    # Dynamic latitude-aware approximation (only if both QGIS and pyproj unavailable)
    d_lon = (lon - lon_0_deg) * _deg_to_m_lon(lat)
    d_lat = lat * _DEG_TO_M_LAT
    return 500000.0 + d_lon * 0.9999, d_lat * 0.9999


def _is_coord_geographic(x, y):
    """Check if coordinates are likely degrees (-180..180, -90..90)."""
    return -180.0 <= x <= 180.0 and -90.0 <= y <= 90.0


def _distance_m(p1, p2, is_geographic):
    """Compute distance in meters between two points."""
    x1, y1 = (p1[0], p1[1]) if isinstance(p1, (list, tuple)) else (p1.x(), p1.y())
    x2, y2 = (p2[0], p2[1]) if isinstance(p2, (list, tuple)) else (p2.x(), p2.y())

    if is_geographic:
        mean_lat = 0.5 * (y1 + y2)
        dx = (x2 - x1) * _deg_to_m_lon(mean_lat)
        dy = (y2 - y1) * _DEG_TO_M_LAT
        return math.sqrt(dx * dx + dy * dy)
    else:
        dx = x2 - x1
        dy = y2 - y1
        return math.sqrt(dx * dx + dy * dy)


def extract_polygon_vertices(geometry_coords):
    """Extract exterior ring coordinate list from various geometry types."""
    pts = []

    # Case 1: already a list of tuples/lists or dicts
    if isinstance(geometry_coords, (list, tuple)):
        if len(geometry_coords) > 0 and isinstance(geometry_coords[0], dict):
            pts = [(float(p["x"]), float(p["y"])) for p in geometry_coords if "x" in p and "y" in p]
        else:
            pts = [(float(p[0]), float(p[1])) for p in geometry_coords]

    # Case 2: shapely geometry
    elif hasattr(geometry_coords, "exterior"):
        coords = list(geometry_coords.exterior.coords)
        pts = [(float(c[0]), float(c[1])) for c in coords]

    # Case 3: QgsGeometry
    elif hasattr(geometry_coords, "asPolygon"):
        if geometry_coords.isMultipart():
            parts = geometry_coords.asMultiPolygon()
            if parts:
                largest = max(parts, key=lambda p: len(p[0]) if p else 0)
                pts = [(pt.x(), pt.y()) for pt in largest[0]]
        else:
            ring = geometry_coords.asPolygon()
            if ring and ring[0]:
                pts = [(pt.x(), pt.y()) for pt in ring[0]]

    # Remove closing duplicate
    if len(pts) > 1:
        dx = pts[0][0] - pts[-1][0]
        dy = pts[0][1] - pts[-1][1]
        if math.sqrt(dx * dx + dy * dy) < 1e-6:
            pts.pop()

    return pts


def filter_vertices_by_distance(vertices, min_spacing_m=50.0, is_geographic=False):
    """Filter vertices so displayed labels are spaced >= min_spacing_m apart."""
    if not vertices or len(vertices) < 3:
        return []

    # Auto-detect if coords are degrees
    if not is_geographic and _is_coord_geographic(vertices[0][0], vertices[0][1]):
        is_geographic = True

    result = []
    n = len(vertices)

    # Always include first vertex
    result.append({
        "index": 0,
        "original_index": 0,
        "x": vertices[0][0],
        "y": vertices[0][1],
        "cumulative_dist": 0.0,
    })

    accumulated = 0.0
    last_shown_idx = 0

    for i in range(1, n):
        d = _distance_m(vertices[i - 1], vertices[i], is_geographic)
        accumulated += d

        if accumulated >= min_spacing_m:
            result.append({
                "index": len(result),
                "original_index": i,
                "x": vertices[i][0],
                "y": vertices[i][1],
                "cumulative_dist": accumulated,
            })
            accumulated = 0.0
            last_shown_idx = i

    # Ensure last vertex before closing is included if far enough from V0
    if last_shown_idx < n - 1:
        closing_dist = _distance_m(vertices[-1], vertices[0], is_geographic)
        if closing_dist >= min_spacing_m * 0.3:
            result.append({
                "index": len(result),
                "original_index": n - 1,
                "x": vertices[-1][0],
                "y": vertices[-1][1],
                "cumulative_dist": accumulated,
            })

    return result


def _require_lon_0(lon_0_deg):
    """Fail loudly instead of guessing a central meridian."""
    if lon_0_deg is None:
        raise ValueError(
            "lon_0_deg (central meridian of the zone) is required for "
            "VN-2000 <-> WGS-84 conversion"
        )
    return lon_0_deg


def format_coordinate(x, y, crs_mode="VN2000", *, lon_0_deg=None):
    """Format a coordinate pair strictly according to CRS rules.

    Rules:
      - VN-2000: ALWAYS in meters, exactly 2 decimal places (.2f)
      - WGS-84:  ALWAYS in degrees, exactly 6 decimal places (.6f)

    Auto-converts between meters and degrees if necessary.
    ``lon_0_deg`` (keyword-only) is the zone's central meridian. It is only
    consumed when a VN-2000 <-> WGS-84 conversion is actually needed; if that
    happens and it was not passed, ValueError is raised. There is no fallback
    meridian.
    """
    is_target_wgs = str(crs_mode).upper() in ("WGS84", "WGS-84", "EPSG:4326")
    is_src_geo = _is_coord_geographic(x, y)

    if is_target_wgs:
        # User wants WGS-84 (6 decimals, degrees)
        if is_src_geo:
            lon, lat = x, y
        else:
            lon, lat = vn2000_to_wgs84(x, y, _require_lon_0(lon_0_deg))
        return (f"{lon:.6f}", f"{lat:.6f}")
    else:
        # User wants VN-2000 (2 decimals, meters)
        if not is_src_geo:
            x_m, y_m = x, y
        else:
            x_m, y_m = wgs84_to_vn2000(x, y, _require_lon_0(lon_0_deg))
        return (f"{x_m:.2f}", f"{y_m:.2f}")


def compute_perimeter_m(vertices, is_geographic=False):
    """Compute total perimeter in meters."""
    if len(vertices) < 3:
        return 0.0
    if not is_geographic and _is_coord_geographic(vertices[0][0], vertices[0][1]):
        is_geographic = True
    total = 0.0
    n = len(vertices)
    for i in range(n):
        total += _distance_m(vertices[i], vertices[(i + 1) % n], is_geographic)
    return total


def compute_area_ha(vertices, is_geographic=False):
    """Compute polygon area in hectares using Shoelace formula."""
    if len(vertices) < 3:
        return 0.0
    if not is_geographic and _is_coord_geographic(vertices[0][0], vertices[0][1]):
        is_geographic = True

    if is_geographic:
        ref_lon, ref_lat = vertices[0]
        mean_lat = sum(y for _, y in vertices) / len(vertices)
        m_per_lon = _deg_to_m_lon(mean_lat)
        pts_m = []
        for x, y in vertices:
            mx = (x - ref_lon) * m_per_lon
            my = (y - ref_lat) * _DEG_TO_M_LAT
            pts_m.append((mx, my))
    else:
        pts_m = vertices

    n = len(pts_m)
    area = 0.0
    for i in range(n):
        j = (i + 1) % n
        area += pts_m[i][0] * pts_m[j][1]
        area -= pts_m[j][0] * pts_m[i][1]
    return abs(area) / 2.0 / 10_000.0  # m2 -> ha


def filter_polygon_vertices(geometry_or_coords, spacing_meters=50.0, crs_mode="VN2000", *, lon_0_deg):
    """Filter polygon vertices with spacing and format coordinates.

    ``lon_0_deg`` is keyword-only and required (central meridian of the zone).
    """
    raw = extract_polygon_vertices(geometry_or_coords)
    is_geo = _is_coord_geographic(raw[0][0], raw[0][1]) if raw else False
    filtered = filter_vertices_by_distance(raw, min_spacing_m=spacing_meters, is_geographic=is_geo)

    result = []
    for i, item in enumerate(filtered, 1):
        x = item["x"]
        y = item["y"]
        xf, yf = format_coordinate(x, y, crs_mode, lon_0_deg=lon_0_deg)
        result.append({
            "stt": i,
            "x": x,
            "y": y,
            "x_fmt": xf,
            "y_fmt": yf,
            "cumulative_dist": item.get("cumulative_dist", 0.0)
        })
    return result
