# -*- coding: utf-8 -*-
"""CheckCCRQT — Main dialog shell.

5-tab sidebar UI shell: a fixed-width dark-green sidebar with the Kiem Lam
logo, title/subtitle, five checkable nav buttons and a footer contact
block, paired with a QStackedWidget holding one placeholder page per tab.
Later tasks fill in the placeholder pages.
"""

from __future__ import annotations

import configparser
import csv
import datetime
import importlib.util
import os
import tempfile
import time

import shapely.wkt

from qgis.core import (
    NULL,
    QgsApplication,
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsFeature,
    QgsField,
    QgsGeometry,
    QgsProject,
    QgsVectorLayer,
    QgsWkbTypes,
)
from qgis.PyQt.QtCore import QDate, QSettings, QUrl, Qt, QVariant
from qgis.PyQt.QtGui import QColor, QDesktopServices, QGuiApplication, QPixmap
from qgis.PyQt.QtWidgets import (
    QButtonGroup,
    QCheckBox,
    QColorDialog,
    QComboBox,
    QDateEdit,
    QDialog,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QFrame,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QPlainTextEdit,
    QProgressBar,
    QPushButton,
    QRadioButton,
    QScrollArea,
    QSizePolicy,
    QSpinBox,
    QStackedWidget,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QTextBrowser,
    QVBoxLayout,
    QWidget,
)

# Intra-plugin imports MUST be relative: QGIS ("Install from ZIP") only puts
# the folder CONTAINING ``CheckCCRQT/`` on sys.path, so top-level names like
# ``core``/``exporters`` do not exist at runtime (tests/test_installed_layout.py).
from ..core.change_detector import STATUS_CLOUDY, STATUS_NONE, HarvestDetectionTask
from ..core.cycle_manager import generate_period
from ..core.jrc_tmf_checker import TmfCheckTask
from ..core.crs_manager import (
    apply_symbology,
    area_transform,
    build_qgs_crs,
    compute_area_ha,
    get_crs_catalog,
    reproject_layer,
    resolve_area_crs,
)
from ..core.field_mapper import CANONICAL_FIELDS, auto_detect_fields
from ..core.geometry_validator import validate_layer
from ..core.sentinel_stac import DEFAULT_STAC_URL
from ..exporters.html_report import export_html_report
from ..exporters.map_layout_exporter import export_overview_map, export_per_lot_maps

# NOTE: ``exporters.excel_report`` (openpyxl) and ``exporters.word_report``
# (python-docx) are imported lazily inside their export handlers. Neither
# library ships with QGIS by default, and an eager import here would make a
# machine without them unable to even OPEN this dialog.
MISSING_DOCX_MESSAGE = "Thiếu thư viện python-docx, không thể xuất Word."
MISSING_OPENPYXL_MESSAGE = "Thiếu thư viện openpyxl, không thể xuất/đọc Excel."
MISSING_PYPDF2_MESSAGE = "Thiếu thư viện PyPDF2, không thể gộp PDF."


def qgs_geometry_to_shapely_wgs84(qgs_geom, source_crs):
    """Reproject a ``QgsGeometry`` to EPSG:4326 and return it as shapely geometry.

    ``core.change_detector``/``core.sentinel_stac`` (Task 9) and the JRC TMF
    checker (Task 11) are WGS-84-only, while the layer the user picked on
    Tab 1 may be in VN-2000, UTM, or anything else -- so every lot geometry
    handed to either of them must go through this conversion first.

    ``qgs_geom`` is cloned before transforming (``QgsGeometry.transform``
    mutates in place), so the caller's original geometry -- still in the
    layer's native CRS, as needed by Tab 1 symbology / Tab 2 validation --
    is left untouched. ``source_crs`` is the CRS ``qgs_geom`` is currently
    in (normally ``layer.crs()``), not necessarily WGS-84.

    This is a module-level function (not a method) specifically so Task 11's
    JRC TMF screening can import and reuse it against the same Tab 3 lot
    geometries without duplicating the conversion.
    """
    if qgs_geom is None or qgs_geom.isNull() or qgs_geom.isEmpty():
        # shapely.wkt.loads("") raises GEOSException -- report it as a
        # clear per-lot problem instead (see _build_lots_from_features).
        raise ValueError("Lô không có dữ liệu hình học")
    geom = QgsGeometry(qgs_geom)
    target_crs = QgsCoordinateReferenceSystem("EPSG:4326")
    if source_crs != target_crs:
        transform = QgsCoordinateTransform(source_crs, target_crs, QgsProject.instance())
        geom.transform(transform)
    return shapely.wkt.loads(geom.asWkt())


#: Status shown for a lot whose geometry is null/empty (I2) -- it is skipped
#: before any background task runs, instead of crashing the whole batch.
STATUS_MISSING_GEOMETRY = "Thiếu dữ liệu: lô không có hình học"
#: Status for lots never processed because the user cancelled the task.
STATUS_NOT_CHECKED_CANCELLED = "Chưa kiểm tra (đã hủy)"

_NETWORK_ERROR_TYPES = {
    "ConnectionError", "ConnectTimeout", "ReadTimeout", "Timeout", "SSLError",
    "ProxyError", "ChunkedEncodingError",
}


def short_error_vi(error):
    """Short Vietnamese reason for a background task's per-lot ``errors``
    entry (``{"id_lo", "error", "error_type"?}``), for the results table."""
    error_type = error.get("error_type") or ""
    if error_type in _NETWORK_ERROR_TYPES:
        return "không kết nối được máy chủ dữ liệu (kiểm tra mạng)"
    if error_type == "HTTPError":
        return "máy chủ dữ liệu trả về lỗi"
    message = str(error.get("error") or "không rõ nguyên nhân").strip().splitlines()[0]
    return message if len(message) <= 80 else message[:77] + "..."


def error_status_vi(error):
    return f"Lỗi: {short_error_vi(error)}"


def split_id_list(text):
    """Split pasted/typed ID text on both newlines and commas, stripping blanks."""
    raw = text.replace(",", "\n")
    return [line.strip() for line in raw.splitlines() if line.strip()]


def load_ids_from_file(path):
    """Read the first column of a ``.csv`` or ``.txt`` file as a list of ID strings.

    Excel (.xlsx/.xls) import from UI is intentionally disabled.
    """
    ext = os.path.splitext(path)[1].lower()
    if ext in (".xlsx", ".xls"):
        raise ValueError(
            "Không hỗ trợ nhập dữ liệu từ file Excel. Vui lòng dùng CSV/TXT hoặc dán trực tiếp danh sách ID."
        )
    ids = []
    with open(path, "r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.reader(handle)
        for row in reader:
            if not row:
                continue
            text_value = row[0].strip()
            if text_value:
                ids.append(text_value)
    return ids

#: (canonical_key, Vietnamese display label) for the field-mapping grid, in order.
FIELD_LABELS = [
    ("id_lo", "ID lô"),
    ("chu_ho", "Chủ hộ"),
    ("tieu_khu", "Tiểu khu"),
    ("khoanh", "Khoảnh"),
    ("lo", "Lô"),
    ("dien_tich_kb", "Diện tích khai báo (ha)"),
    ("nam_trong", "Năm trồng"),
    ("loai_cay", "Loài cây"),
    ("trang_thai_ccr", "Trạng thái chứng chỉ"),
]

NO_FIELD_PLACEHOLDER = "— Không có —"

#: (cycle_type, Vietnamese combo label) for Tab 4's cycle-picker, in order.
CYCLE_TYPE_CHOICES = [
    ("monthly", "Hàng tháng"),
    ("quarterly", "Hàng quý"),
    ("semiannual", "6 tháng"),
    ("annual", "Hàng năm"),
    ("custom", "Tùy chọn"),
]

#: (object_name, display_label) for each sidebar tab, in order.
#: Order and labels are fixed by PLAN.md §2.
TAB_DEFS = [
    ("tab_data", "1. Dữ liệu & Hệ tọa độ"),
    ("tab_validate", "2. Kiểm tra lỗi & Diện tích"),
    ("tab_sentinel", "3. Truy xuất khai thác"),
    ("tab_tmf", "4. Kiểm tra JRC TMF"),
    ("tab_report", "5. Báo cáo chu kỳ"),
    ("tab_config", "6. Cấu hình & Nhật ký"),
]

SIDEBAR_FOOTER_TEXT = (
    "Chi cục Kiểm lâm tỉnh Quảng Trị\n"
    "Trưởng phòng: Phạm Thanh Trung\n"
    "sdptrklqt@gmail.com · 0905 822 335"
)

#: QSettings organization/application names (Tab 5 -- Task 15). Every
#: persisted config value lives under this one ``QSettings`` instance,
#: created once in ``MainDialog.__init__`` (before ``_build_ui``) so Tabs
#: 2/3's spin boxes can read it as their initial value, not just Tab 5's
#: own form.
SETTINGS_ORG = "CheckCCRQT"
SETTINGS_APP = "config"

#: key -> default value (its Python type also picks the type used to read
#: it back out of QSettings, which stores everything as text/QVariant).
#: - ``sliver_ha``/``mismatch_pct``: Tab 2's validation thresholds.
#: - ``drop_threshold``/``cloud_max``: Tab 3's Sentinel-2 harvest-detection
#:   thresholds.
#: - ``stac_url``: override for ``core.sentinel_stac.DEFAULT_STAC_URL``.
#: - ``tmf_cache_dir``: local cache directory for JRC TMF COG tiles
#:   (``core.jrc_tmf_checker.fetch_tmf_raster``); defaults to a
#:   subdirectory under the OS temp folder, matching the hardcoded path
#:   this replaces (``_on_run_tmf_clicked`` previously built it inline).
CONFIG_DEFAULTS = {
    "sliver_ha": 0.01,
    "mismatch_pct": 5.0,
    "drop_threshold": -0.20,
    "cloud_max": 30.0,
    "stac_url": DEFAULT_STAC_URL,
    "tmf_cache_dir": os.path.join(tempfile.gettempdir(), "checkccrqt_jrc_tmf_cache"),
    "org_name": "Phòng Sử dụng và Phát triển rừng — Chi cục Kiểm lâm tỉnh Quảng Trị",
}

#: Official plugin intro text (Vietnamese), verbatim from
#: ``GIOI_THIEU_CLAUDE.md`` §2 -- the same canonical source already copied
#: into ``README.md`` (Task 0). Rendered as rich text in the "Giới thiệu"
#: sub-tab of Tab 5 via ``QTextBrowser.setHtml``.
def _read_plugin_version(plugin_dir):
    """Read plugin version string from ``metadata.txt`` (fallback ``0.3.1``)."""
    meta_path = os.path.join(plugin_dir, "metadata.txt") if plugin_dir else ""
    if meta_path and os.path.isfile(meta_path):
        cp = configparser.ConfigParser()
        try:
            cp.read(meta_path, encoding="utf-8")
            ver = cp.get("general", "version", fallback="").strip()
            if ver:
                return ver
        except Exception:
            pass
    return "0.3.1"


ABOUT_TEXT_VI = """
<h2>CHECK CCRQT — Hệ thống Kiểm tra Tính xác thực &amp; Giám sát Rừng trồng Chứng chỉ</h2>
<p><b>CheckCCRQT</b> là phần mềm bổ trợ (Plugin) mã nguồn mở trên nền tảng QGIS,
thuộc sáng kiến <i>"Nghiên cứu ứng dụng AI để xây dựng Plugin mã nguồn mở trên
nền tảng QGIS nhằm tự động hóa việc theo dõi kiểm tra, quản lý rừng trồng
được cấp chứng chỉ quản lý rừng bền vững trên địa bàn tỉnh Quảng Trị"</i> do
<b>Tập thể Phòng Sử dụng và Phát triển rừng — Chi cục Kiểm lâm tỉnh Quảng
Trị</b> (Sở Nông nghiệp và Môi trường tỉnh Quảng Trị) nghiên cứu và xây
dựng.</p>
<p>Phần mềm phục vụ trực tiếp công tác tham mưu, hướng dẫn và kiểm tra thực
hiện phương án quản lý rừng bền vững, cấp chứng chỉ gỗ rừng trồng và giám
sát khai thác theo Quyết định số 406/QĐ-CCKL ngày 08/7/2025 của Chi cục
Kiểm lâm tỉnh Quảng Trị, đồng thời thiết kế mở để áp dụng trên phạm vi cả
nước.</p>
<h3>Chức năng chính</h3>
<ul>
<li>Chuẩn hóa hệ tọa độ VN-2000 (Quảng Trị mới 106°00', Quảng Trị cũ
106°15', Quảng Bình cũ 106°00' và toàn bộ các tỉnh/thành Việt Nam).</li>
<li>Kiểm tra lỗi hình học, thiếu số liệu thuộc tính, đối soát diện tích
bản đồ với diện tích khai báo và xuất báo cáo cảnh báo HTML.</li>
<li>Kiểm tra tính xác thực theo danh sách ID lô thông báo; dò chuỗi thời
gian ảnh vệ tinh Sentinel-2 trực tuyến (STAC + GDAL /vsicurl/ đa luồng)
hoặc thư mục ảnh offline để xác định thời điểm khai thác thực tế.</li>
<li>Thẩm định nguy cơ phá rừng, chuyển đổi mục đích sử dụng rừng sau mốc
31/12/2020 căn cứ dữ liệu EC JRC TMF v1_2025 (chuẩn EUDR).</li>
<li>Xuất báo cáo so sánh theo chu kỳ (Excel, Word) và bản đồ in PDF chuẩn
khung 02 dòng kẻ.</li>
</ul>
<h3>Nguồn dữ liệu &amp; Cập nhật liên tục</h3>
<p>Dữ liệu vệ tinh tham chiếu sử dụng <b>Sentinel-2 L2A</b> (ESA Copernicus /
AWS Earth Search STAC) và <b>EC JRC Tropical Moist Forest (TMF v1_2025)</b>.
Plugin được nhóm tác giả <b>liên tục cập nhật, tiếp thu ý kiến góp ý</b> từ
cán bộ kiểm lâm và các chủ rừng để sửa lỗi, tối ưu tốc độ và hoàn thiện
tính năng qua từng phiên bản.</p>
<h3>Thông tin đơn vị &amp; liên hệ</h3>
<p>
<b>Đơn vị thực hiện:</b> Phòng Sử dụng và Phát triển rừng — Chi cục Kiểm
lâm tỉnh Quảng Trị<br/>
<b>Cơ quan chủ quản:</b> Sở Nông nghiệp và Môi trường tỉnh Quảng Trị<br/>
<b>Đại diện:</b> Ông Phạm Thanh Trung — Trưởng phòng<br/>
<b>Email góp ý &amp; hỗ trợ:</b> <a href="mailto:sdptrklqt@gmail.com">sdptrklqt@gmail.com</a><br/>
<b>Điện thoại:</b> 0905 822 335
</p>
"""

#: (STT, Họ và tên, Chức vụ, Số điện thoại) for the "Giới thiệu" roster
#: table, in the exact order from ``GIOI_THIEU_CLAUDE.md``/``README.md``.
TEAM_ROSTER = [
    (1, "Phạm Thanh Trung", "Trưởng phòng Sử dụng và PT rừng", "0905822335"),
    (2, "Phạm Xuân Thành", "Phó Trưởng phòng Sử dụng và PT rừng", "0905882755"),
    (3, "Nguyễn Tuấn Anh", "Phó Trưởng phòng Sử dụng và PT rừng", "0365643801"),
    (4, "Nguyễn Việt Tú", "Kiểm lâm viên", "0822585123"),
    (5, "Phạm Hoàng Hà", "Kiểm lâm viên", "0888476979"),
    (6, "Nguyễn Thanh Lý", "Kiểm lâm viên", "0916624511"),
    (7, "Dương Chí Anh", "Kiểm lâm viên", "0869117555"),
    (8, "Nguyễn Văn Thăng", "Kiểm lâm viên", "0946699357"),
    (9, "Trần Phước Lâm", "Kiểm lâm viên", "0982353345"),
    (10, "Lê Ngọc Cường", "Kiểm lâm viên", "0911431369"),
]


class MainDialog(QDialog):
    """Main CheckCCRQT dialog: sidebar navigation + stacked content pages."""

    SIDEBAR_WIDTH = 235

    def __init__(self, iface, plugin_dir=None):
        super().__init__(iface.mainWindow() if iface is not None else None)
        self.iface = iface
        self.plugin_dir = plugin_dir or os.path.dirname(os.path.dirname(__file__))
        self.plugin_version = _read_plugin_version(self.plugin_dir)

        self.setWindowTitle(f"CheckCCRQT v{self.plugin_version}")
        screen = QGuiApplication.primaryScreen()
        avail = screen.availableGeometry() if screen is not None else None
        if avail is not None and avail.height() > 0:
            target_w = min(1020, max(820, int(avail.width() * 0.85)))
            target_h = min(680, max(500, int(avail.height() * 0.88)))
            self.resize(target_w, target_h)
        else:
            self.resize(1000, 640)
        self.setMinimumSize(760, 480)

        #: Currently selected layer on Tab 1 (``None`` until the user picks one).
        self.active_layer = None
        #: canonical_key -> real field name (or ``None``), kept in sync with
        #: the Tab 1 field-mapping combo boxes. Read directly by later tabs.
        self.field_map = {key: None for key in CANONICAL_FIELDS}
        #: Most recent core.geometry_validator.ValidationResult (``None``
        #: until "Chạy kiểm tra" on Tab 2 succeeds at least once).
        self.last_validation_result = None
        #: Resolved reporting period from Tab 4's cycle-picker, as
        #: ``(date, date)`` -- ``None`` until the dialog finishes building
        #: (set by ``_build_tab_report``). Read by Task 13's exports.
        self.current_period = None

        #: Persisted config (Tab 5 -- Task 15). Created before ``_build_ui``
        #: so Tab 2/3's spin boxes can read persisted values as their
        #: initial value, not just Tab 5's own form.
        self.settings = QSettings(SETTINGS_ORG, SETTINGS_APP)

        self._build_ui()
        self._load_stylesheet()

    # ------------------------------------------------------------------
    # Tab 5 config persistence helpers
    # ------------------------------------------------------------------
    def _config_value(self, key):
        """Read a Tab 5 config value from ``self.settings``, typed from ``CONFIG_DEFAULTS``."""
        default = CONFIG_DEFAULTS[key]
        return self.settings.value(f"config/{key}", default, type=type(default))

    def _org_name_value(self):
        """Return active executing unit name from Tab 1/Tab 6 or persisted default."""
        for attr in ("line_org_name", "line_cfg_org_name"):
            widget = getattr(self, attr, None)
            if widget is not None:
                text = widget.text().strip()
                if text:
                    return text
        return self._config_value("org_name") or CONFIG_DEFAULTS["org_name"]

    def _on_org_name_edited(self, source):
        """Persist executing unit immediately and mirror between Tab 1 and Tab 6."""
        val = source.text().strip() if source is not None else ""
        if not val:
            val = CONFIG_DEFAULTS["org_name"]
        for attr in ("line_org_name", "line_cfg_org_name"):
            widget = getattr(self, attr, None)
            if widget is not None and widget.text().strip() != val:
                widget.blockSignals(True)
                widget.setText(val)
                widget.blockSignals(False)
        self.settings.setValue("config/org_name", val)
        self.settings.sync()

    def _log(self, message):
        """Append a timestamped line to the "Nhật ký" log (Tab 5, Task 15).

        Called by every prior tab's long-running action (validation run +
        HTML export on Tab 2; Sentinel-2 audit + JRC TMF check on Tab 3;
        Excel/Word/map exports on Tab 4) once it completes.
        """
        timestamp = datetime.datetime.now().strftime("%H:%M:%S")
        text_log = getattr(self, "text_log", None)
        if text_log is not None:
            text_log.appendPlainText(f"[{timestamp}] {message}")

    # ------------------------------------------------------------------
    # UI construction
    # ------------------------------------------------------------------
    def _build_ui(self):
        root_layout = QHBoxLayout(self)
        root_layout.setContentsMargins(0, 0, 0, 0)
        root_layout.setSpacing(0)

        root_layout.addWidget(self._build_sidebar())
        root_layout.addWidget(self._build_content_stack())

    def _build_sidebar(self):
        sidebar = QFrame(self)
        sidebar.setObjectName("sidebarFrame")
        sidebar.setFixedWidth(self.SIDEBAR_WIDTH)

        layout = QVBoxLayout(sidebar)
        layout.setContentsMargins(12, 16, 12, 12)
        layout.setSpacing(8)

        # Logo
        logo_label = QLabel(sidebar)
        logo_path = os.path.join(self.plugin_dir, "assets", "logo_kiemlam.png")
        pixmap = QPixmap(logo_path)
        self.logo_pixmap = pixmap
        if not pixmap.isNull():
            logo_label.setPixmap(
                pixmap.scaled(
                    120, 120, Qt.KeepAspectRatio, Qt.SmoothTransformation
                )
            )
        logo_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(logo_label)

        # Title / subtitle
        title_label = QLabel("CHECK CCRQT", sidebar)
        title_label.setObjectName("sidebarTitle")
        title_label.setAlignment(Qt.AlignCenter)
        title_label.setWordWrap(True)
        layout.addWidget(title_label)

        subtitle_label = QLabel("Phòng Sử dụng & Phát triển rừng", sidebar)
        subtitle_label.setObjectName("sidebarSubtitle")
        subtitle_label.setAlignment(Qt.AlignCenter)
        subtitle_label.setWordWrap(True)
        layout.addWidget(subtitle_label)

        layout.addSpacing(12)

        # Nav buttons
        self.nav_button_group = QButtonGroup(self)
        self.nav_button_group.setExclusive(True)
        self.nav_buttons = []
        for index, (attr_name, label) in enumerate(TAB_DEFS):
            button = QPushButton(label.replace("&", "&&"), sidebar)
            button.setObjectName("navButton")
            button.setCheckable(True)
            button.setSizePolicy(
                QSizePolicy.Expanding, QSizePolicy.Fixed
            )
            self.nav_button_group.addButton(button, index)
            self.nav_buttons.append(button)
            layout.addWidget(button)

        self.nav_buttons[0].setChecked(True)

        # Push "Giới thiệu" + footer to the bottom-left
        layout.addStretch(1)

        about_button = QPushButton("Giới thiệu", sidebar)
        about_button.setObjectName("navButton")
        about_button.setCheckable(True)
        about_button.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.nav_button_group.addButton(about_button, len(TAB_DEFS))
        self.nav_buttons.append(about_button)
        layout.addWidget(about_button)

        footer_label = QLabel(f"Phiên bản {self.plugin_version}\n{SIDEBAR_FOOTER_TEXT}", sidebar)
        footer_label.setObjectName("sidebarFooter")
        footer_label.setWordWrap(True)
        footer_label.setAlignment(Qt.AlignLeft | Qt.AlignBottom)
        layout.addWidget(footer_label)

        # Wire navigation: each button's toggled(True) switches the stack page.
        self.nav_button_group.idToggled.connect(self._on_nav_toggled)

        return sidebar

    def _wrap_in_scroll(self, inner):
        """Wrap a tab's content widget in a QScrollArea while keeping the outer page ref."""
        outer_page = QWidget(self.content_stack)
        outer_page.setObjectName("contentPage")
        outer_ly = QVBoxLayout(outer_page)
        outer_ly.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea(outer_page)
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll.setWidget(inner)
        outer_ly.addWidget(scroll)
        return outer_page

    def _build_content_stack(self):
        self.content_stack = QStackedWidget(self)
        self.content_stack.setObjectName("contentStack")

        for attr_name, label in TAB_DEFS:
            if attr_name == "tab_data":
                inner = self._build_tab_data(label)
            elif attr_name == "tab_validate":
                inner = self._build_tab_validate(label)
            elif attr_name == "tab_sentinel":
                inner = self._build_tab_sentinel(label)
            elif attr_name == "tab_tmf":
                inner = self._build_tab_tmf(label)
            elif attr_name == "tab_report":
                inner = self._build_tab_report(label)
            elif attr_name == "tab_config":
                inner = self._build_tab_config(label)
            else:
                inner = self._build_placeholder_page(label)
            page = self._wrap_in_scroll(inner)
            setattr(self, attr_name, page)
            self.content_stack.addWidget(page)

        # Index len(TAB_DEFS): "Giới thiệu" placed at bottom-left of sidebar
        about_inner = self._build_about_page(self.content_stack)
        about_page = self._wrap_in_scroll(about_inner)
        self.tab_about = about_page
        self.content_stack.addWidget(about_page)

        self.content_stack.setCurrentIndex(0)
        return self.content_stack

    @staticmethod
    def _build_placeholder_page(label):
        page = QWidget()
        page.setObjectName("contentPage")
        layout = QVBoxLayout(page)
        tab_number = label.split(".", 1)[0]
        placeholder = QLabel(f"(Tab {tab_number} placeholder)", page)
        placeholder.setAlignment(Qt.AlignCenter)
        layout.addWidget(placeholder)
        return page

    def _build_tab_data(self, label):
        page = QWidget()
        page.setObjectName("contentPage")
        layout = QVBoxLayout(page)

        tab_number = label.split(".", 1)[0]
        title = QLabel(f"Tab {tab_number}: {label.split('.', 1)[1].strip()}", page)
        title.setObjectName("tabTitle")
        layout.addWidget(title)

        layout.addWidget(self._build_layer_section(page))
        layout.addWidget(self._build_crs_section(page))
        layout.addWidget(self._build_field_mapping_section(page))
        layout.addWidget(self._build_symbology_section(page))
        layout.addStretch(1)

        # Populating the layer combo above sets currentIndex to 0 without
        # emitting currentIndexChanged (signals were blocked during the
        # initial fill); initialize active_layer/field_map for whatever
        # ends up selected by default.
        self._on_layer_selection_changed(self.layer_combo.currentIndex())

        return page

    def _build_tab_validate(self, label):
        page = QWidget()
        page.setObjectName("contentPage")
        layout = QVBoxLayout(page)

        tab_number = label.split(".", 1)[0]
        title = QLabel(f"Tab {tab_number}: {label.split('.', 1)[1].strip()}", page)
        title.setObjectName("tabTitle")
        layout.addWidget(title)

        layout.addWidget(self._build_validate_params_section(page))
        layout.addWidget(self._build_validate_summary_section(page))
        layout.addStretch(1)

        return page

    def _build_tab_sentinel(self, label):
        page = QWidget()
        page.setObjectName("contentPage")
        layout = QVBoxLayout(page)

        tab_number = label.split(".", 1)[0]
        title = QLabel(f"Tab {tab_number}: {label.split('.', 1)[1].strip()}", page)
        title.setObjectName("tabTitle")
        layout.addWidget(title)

        layout.addWidget(self._build_sentinel_scope_section(page))
        layout.addWidget(self._build_sentinel_run_controls_section(page))

        self.label_unmatched_ids = QLabel("", page)
        self.label_unmatched_ids.setWordWrap(True)
        layout.addWidget(self.label_unmatched_ids)

        self.label_sentinel_status = QLabel("", page)
        self.label_sentinel_status.setWordWrap(True)
        layout.addWidget(self.label_sentinel_status)

        layout.addWidget(self._build_sentinel_results_section(page))

        map_row = QHBoxLayout()
        self.combo_trace_map_mode = QComboBox(page)
        self.combo_trace_map_mode.addItems([
            "Mỗi lô 1 bản đồ — Gộp chung 1 PDF",
            "Mỗi lô 1 bản đồ — Tách riêng từng PDF",
            "Nhiều lô trên 1 bản đồ tổng thể (A3)",
        ])
        map_row.addWidget(self.combo_trace_map_mode)

        self.btn_export_traceability_map = QPushButton(
            "Xuất Bản đồ Truy xuất Nguồn gốc (Ảnh vệ tinh + Khung 02 dòng kẻ chuẩn Kiểm lâm)", page
        )
        self.btn_export_traceability_map.clicked.connect(self._on_export_traceability_map_clicked)
        map_row.addWidget(self.btn_export_traceability_map, 1)
        layout.addLayout(map_row)

        layout.addStretch(1)

        #: Running/last-submitted HarvestDetectionTask (``None`` until the
        #: first "Chạy kiểm tra xác thực" click).
        self._sentinel_task = None
        #: id_lo -> snapshot of mapped attributes, captured when the task's
        #: lots were built (feature attributes may no longer be reachable
        #: once the background task finishes, e.g. selection changed).
        self._sentinel_attr_snapshot = {}
        #: Exported for Task 13 (Excel/Word export); one dict per lot in the
        #: most recently completed audit run.
        self.last_audit_records = []
        #: Lot dicts ({"id_lo", "geometry_wgs84"}) from the most recent
        #: Sentinel-2 run, reused (NOT rebuilt) by the Task 11 JRC TMF check
        #: so both checks screen exactly the same WGS-84 geometries.
        self._sentinel_lots = []
        #: ``{"id_lo", "status"}`` for lots skipped before the task ran
        #: (null/empty geometry) -- shown as their own rows.
        self._sentinel_skipped = []
        #: id_lo -> row index in table_sentinel_results, so the JRC TMF
        #: check (run as a second step, see ``_on_run_tmf_clicked``) can
        #: fill in its 3 extra columns on the SAME rows the Sentinel-2
        #: results populated, instead of rebuilding the table.
        self._sentinel_row_by_id = {}
        #: Running/last-submitted TmfCheckTask (``None`` until the first
        #: "Kiểm tra JRC TMF" click).
        self._tmf_task = None

        return page

    def _build_tab_tmf(self, label):
        page = QWidget()
        page.setObjectName("contentPage")
        layout = QVBoxLayout(page)

        tab_number = label.split(".", 1)[0]
        title = QLabel(f"Tab {tab_number}: {label.split('.', 1)[1].strip()}", page)
        title.setObjectName("tabTitle")
        layout.addWidget(title)

        scope_box = QGroupBox("Phạm vi kiểm tra JRC TMF (sau 31/12/2020)", page)
        scope_row = QHBoxLayout(scope_box)
        self.tmf_scope_group = QButtonGroup(scope_box)
        self.radio_tmf_scope_all = QRadioButton("Toàn bộ lớp", scope_box)
        self.radio_tmf_scope_selected = QRadioButton("Các lô đang chọn", scope_box)
        self.radio_tmf_scope_checked = QRadioButton("Các lô đã tích ở Tab 3", scope_box)
        self.radio_tmf_scope_all.setChecked(True)
        self.tmf_scope_group.addButton(self.radio_tmf_scope_all, 0)
        self.tmf_scope_group.addButton(self.radio_tmf_scope_selected, 1)
        self.tmf_scope_group.addButton(self.radio_tmf_scope_checked, 2)
        scope_row.addWidget(self.radio_tmf_scope_all)
        scope_row.addWidget(self.radio_tmf_scope_selected)
        scope_row.addWidget(self.radio_tmf_scope_checked)
        layout.addWidget(scope_box)

        layout.addWidget(self._build_tmf_check_section(page))

        self.label_tmf_status = QLabel("", page)
        self.label_tmf_status.setWordWrap(True)
        layout.addWidget(self.label_tmf_status)

        results_box = QGroupBox("Kết quả kiểm tra JRC TMF", page)
        results_layout = QVBoxLayout(results_box)

        self.tmf_result_tabs = QTabWidget(results_box)

        # Tab 1: Tuân thủ
        tab_compliant = QWidget(self.tmf_result_tabs)
        ly_comp = QVBoxLayout(tab_compliant)
        ly_comp.setContentsMargins(4, 4, 4, 4)
        self.table_tmf_compliant = QTableWidget(0, 6, tab_compliant)
        self.table_tmf_compliant.setHorizontalHeaderLabels([
            "Mã lô", "Chủ hộ", "Vị trí (TK/K/Lô)", "Diện tích (ha)",
            "Trạng thái JRC TMF", "Loại rừng chủ đạo",
        ])
        self.table_tmf_compliant.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table_tmf_compliant.horizontalHeader().setStretchLastSection(True)
        ly_comp.addWidget(self.table_tmf_compliant)
        self.tmf_result_tabs.addTab(tab_compliant, "✅ Tuân thủ (0)")

        # Tab 2: Vi phạm & Cần check lại
        tab_review = QWidget(self.tmf_result_tabs)
        ly_rev = QVBoxLayout(tab_review)
        ly_rev.setContentsMargins(4, 4, 4, 4)
        self.table_tmf_results = QTableWidget(0, 9, tab_review)
        self.table_tmf_results.setHorizontalHeaderLabels([
            "Mã lô", "Chủ hộ", "Vị trí (TK/K/Lô)", "DT Lô (ha)",
            "Trạng thái JRC TMF", "Năm mất rừng", "DT ảnh hưởng (ha)",
            "Loại rừng chủ đạo", "Nguyên nhân (Drivers)",
        ])
        self.table_tmf_results.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table_tmf_results.horizontalHeader().setStretchLastSection(True)
        ly_rev.addWidget(self.table_tmf_results)
        self.tmf_result_tabs.addTab(tab_review, "⚠️ Vi phạm && Cần check lại (0)")

        results_layout.addWidget(self.tmf_result_tabs)
        layout.addWidget(results_box)

        eudr_opt_row = QHBoxLayout()
        self.check_eudr_point_under_4ha = QCheckBox(
            "Rút gọn lô < 4 ha thành điểm (Point) theo Điều 9 EUDR", page
        )
        self.check_eudr_point_under_4ha.setChecked(False)
        eudr_opt_row.addWidget(self.check_eudr_point_under_4ha)
        eudr_opt_row.addStretch(1)
        layout.addLayout(eudr_opt_row)

        export_row = QHBoxLayout()
        self.btn_export_tmf_html = QPushButton("Xuất Báo cáo HTML (JRC TMF)", page)
        self.btn_export_tmf_html.clicked.connect(self._on_export_tmf_html_clicked)
        export_row.addWidget(self.btn_export_tmf_html)

        self.btn_export_tmf_excel = QPushButton("Xuất Excel (JRC TMF)", page)
        self.btn_export_tmf_excel.clicked.connect(self._on_export_tmf_excel_clicked)
        export_row.addWidget(self.btn_export_tmf_excel)

        self.btn_export_tmf_geojson = QPushButton("Xuất GeoJSON EUDR", page)
        self.btn_export_tmf_geojson.clicked.connect(self._on_export_tmf_geojson_clicked)
        export_row.addWidget(self.btn_export_tmf_geojson)
        layout.addLayout(export_row)

        map_export_row = QHBoxLayout()
        self.combo_tmf_map_mode = QComboBox(page)
        self.combo_tmf_map_mode.addItems([
            "Mỗi lô 1 bản đồ — Gộp chung 1 PDF",
            "Mỗi lô 1 bản đồ — Tách riêng từng PDF",
            "Nhiều lô trên 1 bản đồ tổng thể (A3)",
        ])
        map_export_row.addWidget(self.combo_tmf_map_mode)

        self.btn_export_tmf_map = QPushButton(
            "Xuất Bản đồ JRC TMF (Nền Sentinel-2 + Khung 02 dòng kẻ chuẩn Kiểm lâm)", page
        )
        self.btn_export_tmf_map.clicked.connect(self._on_export_tmf_map_clicked)
        map_export_row.addWidget(self.btn_export_tmf_map, 1)
        layout.addLayout(map_export_row)

        layout.addStretch(1)
        self.last_tmf_records = []
        return page

    def _build_tab_report(self, label):
        page = QWidget()
        page.setObjectName("contentPage")
        layout = QVBoxLayout(page)

        tab_number = label.split(".", 1)[0]
        title = QLabel(f"Tab {tab_number}: {label.split('.', 1)[1].strip()}", page)
        title.setObjectName("tabTitle")
        layout.addWidget(title)

        layout.addWidget(self._build_cycle_picker_section(page))
        layout.addWidget(self._build_report_export_section(page))
        layout.addStretch(1)

        # Resolve the initial period from the default combo selection/dates
        # before anything else can read self.current_period.
        self._on_cycle_picker_changed()

        return page

    def _build_report_export_section(self, parent):
        box = QGroupBox("Xuất báo cáo chu kỳ", parent)
        layout = QVBoxLayout(box)

        button_row = QHBoxLayout()
        self.btn_export_excel_report = QPushButton("Xuất Excel", box)
        self.btn_export_excel_report.clicked.connect(self._on_export_excel_report_clicked)
        button_row.addWidget(self.btn_export_excel_report)

        self.btn_export_word_report = QPushButton("Xuất Word", box)
        self.btn_export_word_report.clicked.connect(self._on_export_word_report_clicked)
        button_row.addWidget(self.btn_export_word_report)
        layout.addLayout(button_row)

        self.label_report_export_status = QLabel("", box)
        self.label_report_export_status.setWordWrap(True)
        layout.addWidget(self.label_report_export_status)

        return box

    def _build_cycle_picker_section(self, parent):
        box = QGroupBox("Chu kỳ báo cáo", parent)
        form = QFormLayout(box)

        self.combo_cycle_type = QComboBox(box)
        for _cycle_type, vn_label in CYCLE_TYPE_CHOICES:
            self.combo_cycle_type.addItem(vn_label)
        self.combo_cycle_type.currentIndexChanged.connect(self._on_cycle_picker_changed)
        form.addRow("Loại chu kỳ:", self.combo_cycle_type)

        today = QDate.currentDate()

        self.date_cycle_reference = QDateEdit(box)
        self.date_cycle_reference.setDisplayFormat("dd/MM/yyyy")
        self.date_cycle_reference.setCalendarPopup(True)
        self.date_cycle_reference.setDate(today)
        self.date_cycle_reference.dateChanged.connect(self._on_cycle_picker_changed)
        form.addRow("Ngày tham chiếu:", self.date_cycle_reference)

        self.date_cycle_custom_from = QDateEdit(box)
        self.date_cycle_custom_from.setDisplayFormat("dd/MM/yyyy")
        self.date_cycle_custom_from.setCalendarPopup(True)
        self.date_cycle_custom_from.setDate(today)
        self.date_cycle_custom_from.setEnabled(False)
        self.date_cycle_custom_from.dateChanged.connect(self._on_cycle_picker_changed)
        form.addRow("Từ ngày (tùy chọn):", self.date_cycle_custom_from)

        self.date_cycle_custom_to = QDateEdit(box)
        self.date_cycle_custom_to.setDisplayFormat("dd/MM/yyyy")
        self.date_cycle_custom_to.setCalendarPopup(True)
        self.date_cycle_custom_to.setDate(today)
        self.date_cycle_custom_to.setEnabled(False)
        self.date_cycle_custom_to.dateChanged.connect(self._on_cycle_picker_changed)
        form.addRow("Đến ngày (tùy chọn):", self.date_cycle_custom_to)

        self.label_cycle_period = QLabel("", box)
        self.label_cycle_period.setWordWrap(True)
        form.addRow(self.label_cycle_period)

        return box

    def _on_cycle_picker_changed(self, *_args):
        cycle_type = CYCLE_TYPE_CHOICES[self.combo_cycle_type.currentIndex()][0]
        is_custom = cycle_type == "custom"
        self.date_cycle_reference.setEnabled(not is_custom)
        self.date_cycle_custom_from.setEnabled(is_custom)
        self.date_cycle_custom_to.setEnabled(is_custom)

        reference_date = self.date_cycle_reference.date().toPyDate()
        custom_from = self.date_cycle_custom_from.date().toPyDate()
        custom_to = self.date_cycle_custom_to.date().toPyDate()

        try:
            t1, t2 = generate_period(
                cycle_type, reference_date, custom_from=custom_from, custom_to=custom_to
            )
        except ValueError as exc:
            self.current_period = None
            self.label_cycle_period.setText(str(exc))
            return

        self.current_period = (t1, t2)
        self.label_cycle_period.setText(
            f"Kỳ: {t1.strftime('%d/%m/%Y')} – {t2.strftime('%d/%m/%Y')}"
        )

    def _build_sentinel_scope_section(self, parent):
        box = QGroupBox("Nạp thuộc tính && Chọn mã lô cần truy xuất khai thác", parent)
        layout = QVBoxLayout(box)

        top_row = QHBoxLayout()
        self.btn_load_attr_lots = QPushButton("Nạp thuộc tính từ lớp dữ liệu", box)
        self.btn_load_attr_lots.clicked.connect(self._populate_lot_picker_table)
        top_row.addWidget(self.btn_load_attr_lots)

        self.line_search_lots = QLineEdit(box)
        self.line_search_lots.setPlaceholderText(
            "Tìm kiếm / Lọc theo Mã lô, Chủ hộ, Tiểu khu, Khoảnh, Lô..."
        )
        self.line_search_lots.textChanged.connect(self._filter_lot_picker_table)
        top_row.addWidget(self.line_search_lots, 1)

        self.btn_select_map_selected_lots = QPushButton("Các lô được chọn", box)
        self.btn_select_map_selected_lots.setToolTip(
            "Tích chọn các lô đang được chọn trên bản đồ QGIS"
        )
        self.btn_select_map_selected_lots.clicked.connect(
            self._on_select_map_selected_lots_clicked
        )
        top_row.addWidget(self.btn_select_map_selected_lots)

        self.btn_select_all_lots = QPushButton("Chọn tất cả", box)
        self.btn_select_all_lots.clicked.connect(lambda: self._set_visible_lots_checked(True))
        top_row.addWidget(self.btn_select_all_lots)

        self.btn_clear_all_lots = QPushButton("Bỏ chọn", box)
        self.btn_clear_all_lots.clicked.connect(lambda: self._set_visible_lots_checked(False))
        top_row.addWidget(self.btn_clear_all_lots)
        layout.addLayout(top_row)

        self.table_lot_picker = QTableWidget(0, 8, box)
        self.table_lot_picker.setHorizontalHeaderLabels([
            "Chọn", "Mã lô", "Chủ hộ", "Tiểu khu", "Khoảnh", "Lô", "Năm trồng", "DT (ha)"
        ])
        self.table_lot_picker.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table_lot_picker.verticalHeader().setVisible(False)
        self.table_lot_picker.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        self.table_lot_picker.horizontalHeader().setStretchLastSection(True)
        self.table_lot_picker.setMinimumHeight(115)
        self.table_lot_picker.setMaximumHeight(165)
        layout.addWidget(self.table_lot_picker)

        return box

    def _build_sentinel_run_controls_section(self, parent):
        box = QGroupBox("Thông số dò quét Sentinel-2", parent)
        form = QFormLayout(box)

        today = QDate.currentDate()
        self.date_sentinel_from = QDateEdit(box)
        self.date_sentinel_from.setDisplayFormat("dd/MM/yyyy")
        self.date_sentinel_from.setCalendarPopup(True)
        self.date_sentinel_from.setDate(today.addMonths(-12))
        form.addRow("Từ ngày:", self.date_sentinel_from)

        self.date_sentinel_to = QDateEdit(box)
        self.date_sentinel_to.setDisplayFormat("dd/MM/yyyy")
        self.date_sentinel_to.setCalendarPopup(True)
        self.date_sentinel_to.setDate(today)
        form.addRow("Đến ngày:", self.date_sentinel_to)

        self.combo_sentinel_index = QComboBox(box)
        self.combo_sentinel_index.addItems(["NDVI", "NBR", "NDMI"])
        form.addRow("Chỉ số:", self.combo_sentinel_index)

        self.spin_sentinel_cloud = QDoubleSpinBox(box)
        self.spin_sentinel_cloud.setRange(0.0, 100.0)
        self.spin_sentinel_cloud.setSingleStep(1.0)
        self.spin_sentinel_cloud.setValue(self._config_value("cloud_max"))
        form.addRow("Mây tối đa (%):", self.spin_sentinel_cloud)

        self.spin_sentinel_step_days = QSpinBox(box)
        self.spin_sentinel_step_days.setRange(0, 60)
        self.spin_sentinel_step_days.setSingleStep(5)
        self.spin_sentinel_step_days.setValue(10)
        self.spin_sentinel_step_days.setToolTip(
            "Số ngày mỗi kỳ lấy mẫu ảnh ít mây nhất (mặc định 10 ngày/dekad; đặt 0 để quét tất cả các cảnh)."
        )
        form.addRow("Bước lấy mẫu ảnh (ngày):", self.spin_sentinel_step_days)

        offline_row = QHBoxLayout()
        self.btn_offline_folder = QPushButton("Chọn thư mục ảnh offline...", box)
        self.btn_offline_folder.clicked.connect(self._on_pick_offline_folder_clicked)
        offline_row.addWidget(self.btn_offline_folder)
        self.btn_clear_offline_folder = QPushButton("Dùng trực tuyến", box)
        self.btn_clear_offline_folder.clicked.connect(self._on_clear_offline_folder_clicked)
        offline_row.addWidget(self.btn_clear_offline_folder)
        self.label_offline_folder = QLabel("(chưa chọn — dùng trực tuyến STAC)", box)
        self.label_offline_folder.setWordWrap(True)
        offline_row.addWidget(self.label_offline_folder, 1)
        form.addRow(offline_row)
        self.offline_folder_path = None

        progress_row = QHBoxLayout()
        self.progress_sentinel = QProgressBar(box)
        self.progress_sentinel.setRange(0, 100)
        progress_row.addWidget(self.progress_sentinel)
        self.btn_cancel_sentinel = QPushButton("Hủy", box)
        self.btn_cancel_sentinel.setEnabled(False)
        self.btn_cancel_sentinel.clicked.connect(self._on_cancel_sentinel_clicked)
        progress_row.addWidget(self.btn_cancel_sentinel)
        form.addRow(progress_row)

        action_row = QHBoxLayout()
        self.btn_run_sentinel = QPushButton("Chạy kiểm tra xác thực", box)
        self.btn_run_sentinel.clicked.connect(self._on_run_sentinel_clicked)
        action_row.addWidget(self.btn_run_sentinel, 1)

        self.btn_run_sentinel_one_click = QPushButton(
            "⚡ Kiểm tra 1-Click (Sentinel-2 + JRC TMF + Báo cáo)", box
        )
        self.btn_run_sentinel_one_click.setStyleSheet(
            "QPushButton{background-color:#1B5E20;color:#FFFFFF;font-weight:bold;padding:6px 12px;border-radius:4px;}"
            "QPushButton:hover{background-color:#2E7D32;}"
        )
        self.btn_run_sentinel_one_click.clicked.connect(self._on_run_sentinel_one_click_clicked)
        action_row.addWidget(self.btn_run_sentinel_one_click, 1)

        self.btn_reset_sentinel = QPushButton("Reset", box)
        self.btn_reset_sentinel.clicked.connect(self._on_reset_sentinel_clicked)
        action_row.addWidget(self.btn_reset_sentinel)
        form.addRow(action_row)

        return box

    def _build_sentinel_results_section(self, parent):
        box = QGroupBox("Kết quả kiểm tra", parent)
        layout = QVBoxLayout(box)

        self.table_sentinel_results = QTableWidget(0, 8, box)
        self.table_sentinel_results.setHorizontalHeaderLabels(
            [
                "Chủ hộ",
                "Năm trồng",
                "Năm khai thác khai báo",
                "Trạng thái phát hiện",
                "Ngày phát hiện",
                "Trạng thái JRC TMF",
                "Năm mất rừng (TMF)",
                "DT ảnh hưởng (ha)",
            ]
        )
        self.table_sentinel_results.horizontalHeader().setStretchLastSection(True)
        self.table_sentinel_results.setMinimumHeight(115)
        self.table_sentinel_results.setMaximumHeight(190)
        layout.addWidget(self.table_sentinel_results)

        return box

    def _build_tmf_check_section(self, parent):
        """"Bước 2" của Tab 3 / Tab 4: chạy kiểm tra mất rừng JRC TMF v1_2025."""
        box = QGroupBox("Kiểm tra JRC TMF (sau 31/12/2020)", parent)
        vbox = QVBoxLayout(box)
        layout = QHBoxLayout()

        self.btn_run_tmf = QPushButton(
            "⚡ Kiểm tra JRC TMF 1-Click (sau 31/12/2020)", box
        )
        self.btn_run_tmf.setStyleSheet(
            "QPushButton{background-color:#1B5E20;color:#FFFFFF;font-weight:bold;padding:6px 14px;border-radius:4px;}"
            "QPushButton:hover{background-color:#2E7D32;}"
        )
        self.btn_run_tmf.clicked.connect(self._on_tmf_primary_clicked)
        self.btn_run_tmf_one_click = self.btn_run_tmf
        layout.addWidget(self.btn_run_tmf)

        self.progress_tmf = QProgressBar(box)
        self.progress_tmf.setRange(0, 100)
        layout.addWidget(self.progress_tmf, 1)

        self.btn_cancel_tmf = QPushButton("Hủy", box)
        self.btn_cancel_tmf.setEnabled(False)
        self.btn_cancel_tmf.clicked.connect(self._on_cancel_tmf_clicked)
        layout.addWidget(self.btn_cancel_tmf)
        vbox.addLayout(layout)

        self.check_tmf_auto_export = QCheckBox(
            "Tự động xuất hồ sơ 1-Click sau khi kiểm tra (HTML + Excel + GeoJSON EUDR + Bản đồ PDF)", box
        )
        self.check_tmf_auto_export.setChecked(True)
        vbox.addWidget(self.check_tmf_auto_export)

        return box

    def _build_validate_params_section(self, parent):
        box = QGroupBox("Thông số kiểm tra", parent)
        form = QFormLayout(box)

        self.spin_sliver_ha = QDoubleSpinBox(box)
        self.spin_sliver_ha.setRange(0.0, 1000.0)
        self.spin_sliver_ha.setDecimals(4)
        self.spin_sliver_ha.setSingleStep(0.01)
        self.spin_sliver_ha.setValue(self._config_value("sliver_ha"))
        form.addRow("Ngưỡng lô mảnh vụn (ha):", self.spin_sliver_ha)

        self.spin_mismatch_pct = QDoubleSpinBox(box)
        self.spin_mismatch_pct.setRange(0.0, 100.0)
        self.spin_mismatch_pct.setSingleStep(0.5)
        self.spin_mismatch_pct.setValue(self._config_value("mismatch_pct"))
        form.addRow("Ngưỡng lệch diện tích (%):", self.spin_mismatch_pct)

        self.check_gaps = QCheckBox("Kiểm tra khoảng trống (gap)", box)
        self.check_gaps.setChecked(False)
        form.addRow(self.check_gaps)

        button_row = QHBoxLayout()
        self.btn_run_validation = QPushButton("Chạy kiểm tra", box)
        self.btn_run_validation.clicked.connect(self._on_run_validation_clicked)
        button_row.addWidget(self.btn_run_validation)

        self.btn_export_html_report = QPushButton("Xuất báo cáo HTML", box)
        self.btn_export_html_report.clicked.connect(self._on_export_html_report_clicked)
        button_row.addWidget(self.btn_export_html_report)
        form.addRow(button_row)

        return box

    def _build_validate_summary_section(self, parent):
        box = QGroupBox("Kết quả kiểm tra", parent)
        layout = QVBoxLayout(box)

        self.label_validate_status = QLabel("", box)
        self.label_validate_status.setWordWrap(True)
        layout.addWidget(self.label_validate_status)

        grid = QGridLayout()
        self.label_total_count = QLabel("—", box)
        self.label_ok_count = QLabel("—", box)
        self.label_geom_error_count = QLabel("—", box)
        self.label_missing_attr_count = QLabel("—", box)
        self.label_area_mismatch_count = QLabel("—", box)

        summary_rows = [
            ("Tổng số lô:", self.label_total_count),
            ("Số lô đạt:", self.label_ok_count),
            ("Số lô lỗi hình học:", self.label_geom_error_count),
            ("Số lô thiếu dữ liệu:", self.label_missing_attr_count),
            ("Số lô lệch diện tích:", self.label_area_mismatch_count),
        ]
        for row, (caption, value_label) in enumerate(summary_rows):
            grid.addWidget(QLabel(caption, box), row, 0)
            grid.addWidget(value_label, row, 1)
        layout.addLayout(grid)

        return box

    def _build_layer_section(self, parent):
        box = QGroupBox("Lớp dữ liệu", parent)
        layout = QVBoxLayout(box)

        self.layer_combo = QComboBox(box)
        self._populate_layer_combo()
        self.layer_combo.currentIndexChanged.connect(self._on_layer_selection_changed)
        layout.addWidget(self.layer_combo)

        scope_row = QHBoxLayout()
        self.scope_button_group = QButtonGroup(box)
        self.radio_scope_all = QRadioButton("Toàn bộ lớp", box)
        self.radio_scope_selected = QRadioButton("Các lô đang chọn", box)
        self.radio_scope_all.setChecked(True)
        self.scope_button_group.addButton(self.radio_scope_all, 0)
        self.scope_button_group.addButton(self.radio_scope_selected, 1)
        scope_row.addWidget(self.radio_scope_all)
        scope_row.addWidget(self.radio_scope_selected)
        layout.addLayout(scope_row)

        org_row = QHBoxLayout()
        org_row.addWidget(QLabel("Đơn vị thực hiện:", box))
        self.line_org_name = QLineEdit(box)
        self.line_org_name.setText(self._config_value("org_name"))
        self.line_org_name.setPlaceholderText("Nhập tên đơn vị thực hiện kiểm tra...")
        self.line_org_name.editingFinished.connect(
            lambda: self._on_org_name_edited(self.line_org_name)
        )
        org_row.addWidget(self.line_org_name, 1)
        layout.addLayout(org_row)

        return box

    def _populate_layer_combo(self):
        """(Re)fill the layer combo with vector polygon layers from the project."""
        self.layer_combo.blockSignals(True)
        self.layer_combo.clear()
        self._combo_layers = []
        for layer in QgsProject.instance().mapLayers().values():
            if (
                isinstance(layer, QgsVectorLayer)
                and layer.geometryType() == QgsWkbTypes.PolygonGeometry
            ):
                self._combo_layers.append(layer)
                self.layer_combo.addItem(layer.name())
        self.layer_combo.blockSignals(False)

    def _build_crs_section(self, parent):
        box = QGroupBox("Hệ tọa độ (VN-2000 / WGS-84 / UTM)", parent)
        layout = QHBoxLayout(box)

        self.crs_combo = QComboBox(box)
        self._crs_catalog = get_crs_catalog()
        for entry in self._crs_catalog:
            self.crs_combo.addItem(entry["label"])
        layout.addWidget(self.crs_combo, 1)

        self.btn_reproject = QPushButton("Chuyển hệ tọa độ", box)
        self.btn_reproject.clicked.connect(self._on_reproject_clicked)
        layout.addWidget(self.btn_reproject)

        return box

    def _build_field_mapping_section(self, parent):
        box = QGroupBox("Ánh xạ cột dữ liệu", parent)
        grid = QGridLayout(box)

        self.field_combos = {}
        for row, (key, vn_label) in enumerate(FIELD_LABELS):
            grid.addWidget(QLabel(vn_label, box), row, 0)
            combo = QComboBox(box)
            combo.addItem(NO_FIELD_PLACEHOLDER)
            combo.currentIndexChanged.connect(
                lambda _index, k=key: self._on_field_combo_changed(k)
            )
            grid.addWidget(combo, row, 1)
            self.field_combos[key] = combo

        return box

    def _build_symbology_section(self, parent):
        box = QGroupBox("Ký hiệu hóa (Symbology)", parent)
        layout = QHBoxLayout(box)

        self.fill_color = QColor(230, 126, 34)
        self.outline_color = QColor(0, 0, 0)

        self.btn_fill_color = QPushButton("Màu nền", box)
        self.btn_fill_color.clicked.connect(self._on_pick_fill_color)
        layout.addWidget(self.btn_fill_color)

        self.check_transparent_fill = QCheckBox("Nền trong suốt", box)
        self.check_transparent_fill.toggled.connect(self._on_transparent_fill_toggled)
        layout.addWidget(self.check_transparent_fill)

        self.btn_outline_color = QPushButton("Màu viền", box)
        self.btn_outline_color.clicked.connect(self._on_pick_outline_color)
        layout.addWidget(self.btn_outline_color)

        layout.addWidget(QLabel("Độ rộng viền:", box))
        self.spin_outline_width = QDoubleSpinBox(box)
        self.spin_outline_width.setRange(0.0, 10.0)
        self.spin_outline_width.setSingleStep(0.1)
        self.spin_outline_width.setValue(0.5)
        self.spin_outline_width.valueChanged.connect(self._on_symbology_changed)
        layout.addWidget(self.spin_outline_width)

        layout.addWidget(QLabel("Độ trong suốt:", box))
        self.spin_opacity = QDoubleSpinBox(box)
        self.spin_opacity.setRange(0.0, 1.0)
        self.spin_opacity.setSingleStep(0.05)
        self.spin_opacity.setValue(1.0)
        self.spin_opacity.valueChanged.connect(self._on_symbology_changed)
        layout.addWidget(self.spin_opacity)

        return box

    # ------------------------------------------------------------------
    # Tab 1 behavior
    # ------------------------------------------------------------------
    def _on_layer_selection_changed(self, index):
        if index < 0 or index >= len(self._combo_layers):
            self.active_layer = None
        else:
            self.active_layer = self._combo_layers[index]

        # Always re-sync field_map/field combos, whether a layer was picked
        # (auto-detect against it) or the selection became invalid (clear
        # stale values from whatever layer was previously active).
        self._refresh_field_combos_for_active_layer()
        if hasattr(self, "table_lot_picker"):
            self._populate_lot_picker_table()

    def _refresh_field_combos_for_active_layer(self):
        layer = self.active_layer
        detected = auto_detect_fields(layer) if layer is not None else {
            key: None for key in CANONICAL_FIELDS
        }
        field_names = layer.fields().names() if layer is not None else []

        for key, combo in self.field_combos.items():
            combo.blockSignals(True)
            combo.clear()
            combo.addItem(NO_FIELD_PLACEHOLDER)
            combo.addItems(field_names)

            detected_name = detected.get(key)
            if detected_name is not None:
                combo.setCurrentText(detected_name)
            else:
                combo.setCurrentIndex(0)
            combo.blockSignals(False)

            self.field_map[key] = detected_name

    def _on_field_combo_changed(self, key):
        combo = self.field_combos[key]
        text = combo.currentText()
        self.field_map[key] = None if text == NO_FIELD_PLACEHOLDER else text

    def _on_reproject_clicked(self):
        if self.active_layer is None:
            return
        index = self.crs_combo.currentIndex()
        if index < 0 or index >= len(self._crs_catalog):
            return
        entry = self._crs_catalog[index]
        target_crs = build_qgs_crs(entry)
        reprojected = reproject_layer(self.active_layer, target_crs)
        QgsProject.instance().addMapLayer(reprojected)
        self._populate_layer_combo()

        # Switch the dialog onto the newly reprojected layer so active_layer/
        # field_map/field combos reflect the CRS the user just asked for,
        # instead of silently continuing to operate on the old layer.
        # setCurrentIndex() won't emit currentIndexChanged if the combo
        # already happens to land on that index after the blocked-signal
        # repopulate above, so sync explicitly rather than relying on it.
        new_index = self._combo_layers.index(reprojected)
        self.layer_combo.setCurrentIndex(new_index)
        self._on_layer_selection_changed(new_index)

    def _on_pick_fill_color(self):
        color = QColorDialog.getColor(self.fill_color, self, "Chọn màu nền")
        if color.isValid():
            self.fill_color = color
            self._on_symbology_changed()

    def _on_pick_outline_color(self):
        color = QColorDialog.getColor(self.outline_color, self, "Chọn màu viền")
        if color.isValid():
            self.outline_color = color
            self._on_symbology_changed()

    def _on_transparent_fill_toggled(self, checked):
        self.btn_fill_color.setEnabled(not checked)
        self._on_symbology_changed()

    def _on_symbology_changed(self, *_args):
        if self.active_layer is None:
            return
        transparent = (
            self.check_transparent_fill.isChecked()
            if hasattr(self, "check_transparent_fill")
            else False
        )
        apply_symbology(
            self.active_layer,
            self.fill_color,
            self.outline_color,
            self.spin_outline_width.value(),
            self.spin_opacity.value(),
            transparent_fill=transparent,
        )

    # ------------------------------------------------------------------
    # Shared area measurement (Tab 2 validation + Tab 3 audit records)
    # ------------------------------------------------------------------
    def _resolve_area_crs(self):
        """Return ``(area_crs, label)``: the ONE planar CRS both Tab 2's
        validation and Tab 3's ``dien_tich_bando`` measure area in, via
        ``core.crs_manager.resolve_area_crs`` (layer CRS if projected, else
        the Tab 1 combo's pick if projected, else the local UTM zone).
        """
        layer = self.active_layer
        preferred = None
        preferred_label = ""
        index = self.crs_combo.currentIndex() if hasattr(self, "crs_combo") else -1
        if 0 <= index < len(self._crs_catalog):
            entry = self._crs_catalog[index]
            try:
                preferred = build_qgs_crs(entry)
                preferred_label = entry["label"]
            except Exception:
                preferred = None
        area_crs = resolve_area_crs(layer.crs(), preferred, layer.extent())
        if preferred is not None and area_crs == preferred and preferred_label:
            label = preferred_label
        else:
            label = area_crs.description() or area_crs.authid()
        return area_crs, label

    # ------------------------------------------------------------------
    # Tab 2 behavior
    # ------------------------------------------------------------------
    def _on_run_validation_clicked(self):
        if self.active_layer is None:
            self.label_validate_status.setText("Vui lòng chọn lớp dữ liệu ở Tab 1 trước.")
            return

        only_selected = False
        scope_group = getattr(self, "scope_button_group", None)
        if scope_group is not None:
            only_selected = scope_group.checkedId() == 1

        area_crs, area_crs_label = self._resolve_area_crs()
        result = validate_layer(
            self.active_layer,
            self.field_map,
            area_crs,
            sliver_ha=self.spin_sliver_ha.value(),
            mismatch_pct=self.spin_mismatch_pct.value(),
            check_gaps=self.check_gaps.isChecked(),
            only_selected=only_selected,
        )
        self.last_validation_result = result

        self.label_total_count.setText(str(result.total))
        self.label_ok_count.setText(str(result.ok_count))
        self.label_geom_error_count.setText(str(result.geom_error_count))
        self.label_missing_attr_count.setText(str(result.missing_attr_count))
        self.label_area_mismatch_count.setText(str(result.area_mismatch_count))
        status_text = f"Đã kiểm tra {result.total} lô: {len(result.issues)} vấn đề được phát hiện."
        if self.active_layer.crs().isGeographic():
            status_text += (
                "\nLưu ý: Lớp đang ở hệ tọa độ địa lý (độ) — diện tích được tính sau "
                f"khi chuyển tạm sang hệ tọa độ phẳng: {area_crs_label}. Nên chuyển "
                "lớp sang hệ tọa độ VN-2000 ở Tab 1 để đối soát chính xác với diện "
                "tích khai báo."
            )
        self.label_validate_status.setText(status_text)
        self._log(
            f"Chạy kiểm tra hình học/diện tích: {result.total} lô, "
            f"{len(result.issues)} vấn đề được phát hiện."
        )

    def _on_export_html_report_clicked(self):
        if self.last_validation_result is None:
            self.label_validate_status.setText(
                "Vui lòng chạy kiểm tra trước khi xuất báo cáo."
            )
            return

        output_path, _filter = QFileDialog.getSaveFileName(
            self,
            "Xuất báo cáo HTML",
            "bao_cao_kiem_tra.html",
            "HTML (*.html)",
        )
        if not output_path:
            return

        export_html_report(
            self.last_validation_result,
            output_path,
            org_name=self._org_name_value(),
        )
        self._log(f"Xuất báo cáo HTML kiểm tra: {output_path}")
        QDesktopServices.openUrl(QUrl.fromLocalFile(output_path))

    # ------------------------------------------------------------------
    # Tab 3 behavior
    # ------------------------------------------------------------------
    def _populate_lot_picker_table(self):
        """Load mapped attributes from ``self.active_layer`` into ``table_lot_picker``."""
        table = getattr(self, "table_lot_picker", None)
        if table is None:
            return
        table.setRowCount(0)
        self._lot_picker_features = []
        layer = self.active_layer
        if layer is None:
            return

        def _fval(feat, key):
            fname = self.field_map.get(key)
            if not fname:
                return ""
            try:
                val = feat[fname]
            except KeyError:
                return ""
            return "" if val is None or val == NULL else str(val)

        features = list(layer.getFeatures())
        table.setRowCount(len(features))
        for row, feat in enumerate(features):
            self._lot_picker_features.append(feat)
            chk_item = QTableWidgetItem()
            chk_item.setFlags(Qt.ItemIsUserCheckable | Qt.ItemIsEnabled | Qt.ItemIsSelectable)
            chk_item.setCheckState(Qt.Unchecked)
            table.setItem(row, 0, chk_item)

            id_val = _fval(feat, "id_lo") or str(feat.id())
            table.setItem(row, 1, QTableWidgetItem(id_val))
            table.setItem(row, 2, QTableWidgetItem(_fval(feat, "chu_ho")))
            table.setItem(row, 3, QTableWidgetItem(_fval(feat, "tieu_khu")))
            table.setItem(row, 4, QTableWidgetItem(_fval(feat, "khoanh")))
            table.setItem(row, 5, QTableWidgetItem(_fval(feat, "lo")))
            table.setItem(row, 6, QTableWidgetItem(_fval(feat, "nam_trong")))
            table.setItem(row, 7, QTableWidgetItem(_fval(feat, "dien_tich_kb")))

        if hasattr(self, "line_search_lots"):
            self._filter_lot_picker_table(self.line_search_lots.text())

    def _filter_lot_picker_table(self, text):
        """Filter ``table_lot_picker`` rows by keyword across ID, owner, and forest address."""
        table = getattr(self, "table_lot_picker", None)
        if table is None:
            return
        query = (text or "").strip().lower()
        for row in range(table.rowCount()):
            if not query:
                table.setRowHidden(row, False)
                continue
            row_text = " ".join(
                table.item(row, col).text().lower()
                for col in range(1, table.columnCount())
                if table.item(row, col) is not None
            )
            table.setRowHidden(row, query not in row_text)

    def _set_visible_lots_checked(self, checked):
        table = getattr(self, "table_lot_picker", None)
        if table is None:
            return
        state = Qt.Checked if checked else Qt.Unchecked
        for row in range(table.rowCount()):
            if not table.isRowHidden(row):
                item = table.item(row, 0)
                if item is not None:
                    item.setCheckState(state)

    def _on_select_map_selected_lots_clicked(self):
        """Check rows in ``table_lot_picker`` matching currently selected features on active_layer."""
        if self.active_layer is None:
            self.label_sentinel_status.setText("Vui lòng chọn lớp dữ liệu ở Tab 1 trước.")
            return
        selected_feats = list(self.active_layer.selectedFeatures())
        if not selected_feats:
            self.label_sentinel_status.setText(
                "Chưa có lô nào được chọn trên bản đồ QGIS (hãy dùng Select Features để chọn lô)."
            )
            return

        table = getattr(self, "table_lot_picker", None)
        if table is None:
            return
        if table.rowCount() == 0 or not getattr(self, "_lot_picker_features", None):
            self._populate_lot_picker_table()

        sel_fids = {feat.id() for feat in selected_feats}
        id_field = self.field_map.get("id_lo")
        sel_ids = set()
        if id_field:
            for feat in selected_feats:
                try:
                    val = feat[id_field]
                    if val is not None and val != NULL:
                        sel_ids.add(str(val))
                except KeyError:
                    pass

        feats = getattr(self, "_lot_picker_features", [])
        matched = 0
        for row in range(min(table.rowCount(), len(feats))):
            feat = feats[row]
            row_id = table.item(row, 1).text() if table.item(row, 1) is not None else ""
            is_match = (feat.id() in sel_fids) or (id_field and row_id in sel_ids)
            item = table.item(row, 0)
            if item is not None:
                item.setCheckState(Qt.Checked if is_match else Qt.Unchecked)
            if is_match:
                matched += 1
        self.label_sentinel_status.setText(
            f"Đã tích chọn {matched} lô khớp với vùng đang chọn trên bản đồ QGIS."
        )

    def _get_checked_lot_picker_features(self):
        table = getattr(self, "table_lot_picker", None)
        feats = getattr(self, "_lot_picker_features", [])
        if table is None or not feats:
            return []
        selected = []
        for row in range(min(table.rowCount(), len(feats))):
            item = table.item(row, 0)
            if item is not None and item.checkState() == Qt.Checked:
                selected.append(feats[row])
        return selected

    def _on_pick_offline_folder_clicked(self):
        path = QFileDialog.getExistingDirectory(self, "Chọn thư mục ảnh offline")
        if path:
            self.offline_folder_path = path
            self.label_offline_folder.setText(path)

    def _on_clear_offline_folder_clicked(self):
        self.offline_folder_path = None
        self.label_offline_folder.setText("(chưa chọn — dùng trực tuyến STAC)")

    def _match_ids_to_features(self, ids):
        """Match IDs against ``self.active_layer`` via the mapped id_lo field."""
        id_field = self.field_map.get("id_lo")
        if not id_field:
            return [], list(ids)

        id_to_feature = {}
        for feat in self.active_layer.getFeatures():
            try:
                value = feat[id_field]
            except KeyError:
                continue
            if value is None or value == NULL:
                continue
            id_to_feature[str(value)] = feat

        matched_features = []
        unmatched_ids = []
        for id_value in ids:
            feat = id_to_feature.get(id_value)
            if feat is not None:
                matched_features.append(feat)
            else:
                unmatched_ids.append(id_value)
        return matched_features, unmatched_ids

    def _resolve_sentinel_scope_features(self):
        """Return checked features from ``table_lot_picker`` (or all if table empty)."""
        checked = self._get_checked_lot_picker_features()
        if checked:
            return checked, []
        if hasattr(self, "table_lot_picker") and self.table_lot_picker.rowCount() > 0:
            # If user hasn't checked any row yet, fall back to QGIS selection or all
            selected = list(self.active_layer.selectedFeatures())
            if selected:
                return selected, []
        return list(self.active_layer.getFeatures()), []

    def _build_lots_from_features(self, features):
        """Build HarvestDetectionTask lot dicts (WGS-84 geometry) plus an
        id_lo -> mapped-attribute snapshot for populating the results table
        once the background task finishes.

        Returns ``(lots, attr_snapshot, skipped)``. A feature whose geometry
        is null/empty (or can't be converted to WGS-84) is NOT handed to the
        background task -- it goes into ``skipped`` as an
        ``{"id_lo", "status"}`` entry and is shown as its own row (I2),
        instead of one bad feature crashing the whole batch synchronously.

        ``dien_tich_bando`` uses the SAME area CRS/routine as Tab 2's
        validation (``_resolve_area_crs`` + ``core.crs_manager.
        compute_area_ha``), so it is filled in for geographic layers too.
        """
        source_crs = self.active_layer.crs()
        id_field = self.field_map.get("id_lo")
        area_crs, _label = self._resolve_area_crs()
        to_area_crs = area_transform(source_crs, area_crs)

        lots = []
        attr_snapshot = {}
        skipped = []
        for feat in features:
            if id_field:
                raw_id = feat[id_field]
            else:
                raw_id = None
            id_lo = str(raw_id) if raw_id is not None and raw_id != NULL else str(feat.id())

            geom = feat.geometry()
            if geom is None or geom.isNull() or geom.isEmpty():
                skipped.append({"id_lo": id_lo, "status": STATUS_MISSING_GEOMETRY})
            else:
                try:
                    geometry_wgs84 = qgs_geometry_to_shapely_wgs84(geom, source_crs)
                except Exception as exc:
                    skipped.append({
                        "id_lo": id_lo,
                        "status": error_status_vi({"error": f"không chuyển được hình học sang WGS-84 ({exc})"}),
                    })
                else:
                    lots.append({"id_lo": id_lo, "geometry_wgs84": geometry_wgs84})

            def _mapped(key):
                field_name = self.field_map.get(key)
                if not field_name:
                    return None
                try:
                    value = feat[field_name]
                except KeyError:
                    return None
                return None if value == NULL else value

            dien_tich_bando = compute_area_ha(geom, to_area_crs)

            attr_snapshot[id_lo] = {
                "id_lo": id_lo,
                "chu_ho": _mapped("chu_ho"),
                "tieu_khu": _mapped("tieu_khu"),
                "khoanh": _mapped("khoanh"),
                "lo": _mapped("lo"),
                "nam_trong": _mapped("nam_trong"),
                "loai_cay": _mapped("loai_cay"),
                "dien_tich_kb": _mapped("dien_tich_kb"),
                "dien_tich_bando": dien_tich_bando,
            }

        return lots, attr_snapshot, skipped

    def _on_run_sentinel_clicked(self):
        self.label_unmatched_ids.setText("")

        if self.active_layer is None:
            self.label_sentinel_status.setText("Vui lòng chọn lớp dữ liệu ở Tab 1 trước.")
            return

        features, unmatched_ids = self._resolve_sentinel_scope_features()

        if unmatched_ids:
            self.label_unmatched_ids.setText(
                "Không tìm thấy lô: " + ", ".join(unmatched_ids)
            )

        if not features:
            self.label_sentinel_status.setText("Không có lô nào để kiểm tra.")
            return

        lots, attr_snapshot, skipped = self._build_lots_from_features(features)
        self._sentinel_attr_snapshot = attr_snapshot
        # Reused as-is (not rebuilt) by the JRC TMF check -- same WGS-84
        # geometries must be screened by both checks.
        self._sentinel_lots = lots
        #: Lots dropped before the task (no geometry) -- added as their own
        #: rows when results are shown.
        self._sentinel_skipped = skipped

        if not lots:
            # Nothing to send to the background task: show the skipped
            # lots' rows right away.
            self._sentinel_task = None
            self._show_sentinel_results([], [], terminated=False)
            return

        date_from = self.date_sentinel_from.date().toPyDate()
        date_to = self.date_sentinel_to.date().toPyDate()
        if date_from > date_to:
            self.label_sentinel_status.setText(
                "Lỗi: Ngày bắt đầu ('Từ ngày') đang lớn hơn ngày kết thúc ('Đến ngày')."
            )
            return

        step_days = (
            self.spin_sentinel_step_days.value()
            if hasattr(self, "spin_sentinel_step_days")
            else 10
        )
        params = {
            "date_from": date_from,
            "date_to": date_to,
            "cloud_max": self.spin_sentinel_cloud.value(),
            "index": self.combo_sentinel_index.currentText(),
            "drop_threshold": self._config_value("drop_threshold"),
            "step_days": step_days,
            "stac_url": self._config_value("stac_url"),
            "offline_folder": self.offline_folder_path,
            "max_workers": 6,
        }

        self._sentinel_started_at = time.monotonic()
        task = HarvestDetectionTask(lots, params)
        self._sentinel_task = task
        task.progressChanged.connect(self._on_sentinel_progress)
        task.taskCompleted.connect(lambda: self._on_sentinel_task_finished(terminated=False))
        task.taskTerminated.connect(lambda: self._on_sentinel_task_finished(terminated=True))

        self.progress_sentinel.setValue(0)
        self.btn_run_sentinel.setEnabled(False)
        self.btn_cancel_sentinel.setEnabled(True)
        mode_note = "thư mục offline" if self.offline_folder_path else f"STAC trực tuyến, bước {step_days} ngày"
        self.label_sentinel_status.setText(f"Đang xử lý {len(lots)} lô ({mode_note})...")

        QgsApplication.taskManager().addTask(task)

    def _on_cancel_sentinel_clicked(self):
        task = self._sentinel_task
        if task is not None:
            task.cancel()

    def _on_sentinel_progress(self, progress):
        self.progress_sentinel.setValue(int(progress))

    def _on_sentinel_task_finished(self, terminated=False):
        """Slot for the task's ``taskCompleted`` (``terminated=False``) and
        ``taskTerminated`` (``terminated=True`` -- the task only returns
        False when the user cancelled it) signals."""
        self.btn_run_sentinel.setEnabled(True)
        if hasattr(self, "btn_run_sentinel_one_click"):
            self.btn_run_sentinel_one_click.setEnabled(True)
        self.btn_cancel_sentinel.setEnabled(False)

        task = self._sentinel_task
        if task is None:
            return
        self._show_sentinel_results(task.results, task.errors, terminated=terminated)

        one_click_dir = getattr(self, "_sentinel_one_click_dir", None)
        self._sentinel_one_click_dir = None
        if not terminated and one_click_dir and self._sentinel_lots:
            self._tmf_one_click_dir = one_click_dir
            self._tmf_chain_full_reports = True
            self._start_tmf_task_for_lots(
                self._sentinel_lots,
                self._sentinel_attr_snapshot,
                self._sentinel_skipped,
            )

    def _suggest_one_click_dir(self, suffix):
        if self.active_layer is not None:
            src = self.active_layer.source().split("|")[0]
            if src and os.path.exists(src):
                base_dir = os.path.dirname(src)
                layer_name = os.path.splitext(os.path.basename(src))[0]
                return os.path.join(base_dir, f"{layer_name}_{suffix}")
        return os.path.join(tempfile.gettempdir(), f"CheckCCRQT_{suffix}")

    def _on_run_sentinel_one_click_clicked(self):
        if self.active_layer is None:
            self.label_sentinel_status.setText("Vui lòng chọn lớp dữ liệu ở Tab 1 trước.")
            return
        default_dir = self._suggest_one_click_dir("KetQua_1Click")
        out_dir = QFileDialog.getExistingDirectory(
            self, "Chọn thư mục xuất kết quả 1-Click", os.path.dirname(default_dir)
        )
        if not out_dir:
            return
        self._sentinel_one_click_dir = out_dir
        self._on_run_sentinel_clicked()

    def _show_sentinel_results(self, results, errors, terminated=False):
        """Fill the results table and ``last_audit_records`` with one row per
        lot: a successful result, a per-lot error from the task (I1: shown
        as "Lỗi: ..." -- previously these lots silently vanished), a lot
        skipped for having no geometry (I2), or -- if the run was
        cancelled -- a lot that was never processed.
        """
        self.btn_run_sentinel.setEnabled(True)
        self.btn_cancel_sentinel.setEnabled(False)

        record_keys = (
            "chu_ho", "tieu_khu", "khoanh", "lo", "nam_trong",
            "loai_cay", "dien_tich_kb", "dien_tich_bando",
        )

        self.table_sentinel_results.setRowCount(0)
        self._sentinel_row_by_id = {}
        records = []

        def _add_row(id_lo, status, harvest_date=None, pct_decline=None, error=None):
            snapshot = self._sentinel_attr_snapshot.get(id_lo, {})
            record = {"id_lo": id_lo}
            for key in record_keys:
                record[key] = snapshot.get(key)
            record["status"] = status
            record["harvest_date"] = harvest_date
            record["pct_decline"] = pct_decline
            # Truthy for "no result" rows (task error / no geometry /
            # cancelled before processing) -- excluded from "changed"
            # counts and grey on the overview map.
            record["error"] = error
            # JRC TMF columns: not yet populated until "Kiểm tra JRC TMF"
            # (Task 11, _on_run_tmf_clicked) runs as a second step; keyed
            # here regardless so Task 13's Excel export always finds them.
            record["tmf_status"] = None
            record["tmf_year"] = None
            record["tmf_ha"] = None
            records.append(record)

            row = self.table_sentinel_results.rowCount()
            self.table_sentinel_results.insertRow(row)
            self._sentinel_row_by_id[id_lo] = row
            row_values = [
                record.get("chu_ho"),
                record.get("nam_trong"),
                None,  # Năm khai thác khai báo: no canonical field mapped yet.
                status,
                harvest_date,
                None,  # Trạng thái JRC TMF
                None,  # Năm mất rừng (TMF)
                None,  # DT ảnh hưởng (ha)
            ]
            for col, value in enumerate(row_values):
                self.table_sentinel_results.setItem(
                    row, col, QTableWidgetItem("" if value is None else str(value))
                )

        handled_ids = set()
        for result in results:
            id_lo = result.get("id_lo")
            handled_ids.add(id_lo)
            _add_row(
                id_lo, result.get("status"), result.get("harvest_date"), result.get("pct_decline"),
            )
        for error in errors:
            id_lo = error.get("id_lo")
            handled_ids.add(id_lo)
            status = error_status_vi(error)
            _add_row(id_lo, status, error=status)
        not_checked = 0
        if terminated:
            for lot in self._sentinel_lots:
                if lot.get("id_lo") not in handled_ids:
                    not_checked += 1
                    _add_row(lot.get("id_lo"), STATUS_NOT_CHECKED_CANCELLED,
                             error=STATUS_NOT_CHECKED_CANCELLED)
        skipped = getattr(self, "_sentinel_skipped", [])
        for item in skipped:
            _add_row(item["id_lo"], item["status"], error=item["status"])

        self.last_audit_records = records
        n_ok = len(results)
        n_err = len(errors) + len(skipped)
        summary = f"{n_ok} lô có kết quả, {n_err} lô lỗi/thiếu dữ liệu"
        if not_checked:
            summary += f", {not_checked} lô chưa kiểm tra"
        prefix = "Đã hủy" if terminated else "Hoàn tất"
        started = getattr(self, "_sentinel_started_at", None)
        elapsed_str = f" ({time.monotonic() - started:.1f}s)" if started is not None else ""
        self.label_sentinel_status.setText(f"{prefix}{elapsed_str}: {summary}.")
        self._log(f"{prefix} kiểm tra xác thực Sentinel-2{elapsed_str}: {summary}.")

    def _resolve_tmf_scope_features(self):
        if self.active_layer is None:
            return []
        scope_id = self.tmf_scope_group.checkedId() if hasattr(self, "tmf_scope_group") else 0
        if scope_id == 1:
            return list(self.active_layer.selectedFeatures())
        if scope_id == 2:
            return self._get_checked_lot_picker_features()
        return list(self.active_layer.getFeatures())

    def _start_tmf_task_for_lots(self, lots, attr_snapshot, skipped):
        self._tmf_attr_snapshot = attr_snapshot
        self._tmf_skipped = skipped
        cache_dir = self._config_value("tmf_cache_dir")
        self._tmf_started_at = time.monotonic()
        task = TmfCheckTask(lots, cache_dir)
        self._tmf_task = task
        task.progressChanged.connect(self._on_tmf_progress)
        task.taskCompleted.connect(lambda: self._on_tmf_task_finished(terminated=False))
        task.taskTerminated.connect(lambda: self._on_tmf_task_finished(terminated=True))

        self.progress_tmf.setValue(0)
        self.btn_run_tmf.setEnabled(False)
        if hasattr(self, "btn_run_tmf_one_click"):
            self.btn_run_tmf_one_click.setEnabled(False)
        self.btn_cancel_tmf.setEnabled(True)
        self.label_tmf_status.setText(
            f"Đang kiểm tra JRC TMF v1_2025 cho {len(lots)} lô..."
        )

        QgsApplication.taskManager().addTask(task)

    def _on_tmf_primary_clicked(self):
        """Merged Tab 4 action: run 1-Click auto-export if checked, else run check only."""
        auto_box = getattr(self, "check_tmf_auto_export", None)
        if auto_box is not None and auto_box.isChecked():
            self._on_run_tmf_one_click_clicked()
        else:
            self._tmf_one_click_dir = None
            self._on_run_tmf_clicked()

    def _on_run_tmf_clicked(self):
        """Independent JRC TMF check (Tab 4): runs directly on active_layer lots."""
        if self.active_layer is None:
            self.label_tmf_status.setText("Vui lòng chọn lớp dữ liệu ở Tab 1 trước.")
            return

        features = self._resolve_tmf_scope_features()
        if not features:
            self.label_tmf_status.setText("Không có lô nào trong phạm vi đã chọn.")
            return

        lots, attr_snapshot, skipped = self._build_lots_from_features(features)
        if not lots:
            self.label_tmf_status.setText("Các lô đã chọn không có hình học hợp lệ.")
            return

        self._start_tmf_task_for_lots(lots, attr_snapshot, skipped)

    def _on_run_tmf_one_click_clicked(self):
        """1-Click EUDR assessment on Tab 4 (runs JRC TMF + auto-exports HTML/Excel/PDF)."""
        if self.active_layer is None:
            self.label_tmf_status.setText("Vui lòng chọn lớp dữ liệu ở Tab 1 trước.")
            return
        features = self._resolve_tmf_scope_features()
        if not features:
            self.label_tmf_status.setText("Không có lô nào trong phạm vi đã chọn.")
            return
        default_dir = self._suggest_one_click_dir("EUDR_JRC_TMF")
        out_dir = QFileDialog.getExistingDirectory(
            self, "Chọn thư mục lưu hồ sơ EUDR 1-Click", os.path.dirname(default_dir)
        )
        if not out_dir:
            return
        self._tmf_one_click_dir = out_dir
        self._tmf_chain_full_reports = False
        self._on_run_tmf_clicked()

    def _on_cancel_tmf_clicked(self):
        task = self._tmf_task
        if task is not None:
            task.cancel()

    def _on_tmf_progress(self, progress):
        self.progress_tmf.setValue(int(progress))

    def _export_one_click_tmf_deliverables(self, out_dir, chain_full=False):
        """Export HTML, Excel, Word (when chained) and Overview PDF into ``out_dir``."""
        os.makedirs(out_dir, exist_ok=True)
        exported = []

        from ..exporters.html_report import export_tmf_html_report
        from ..exporters.tmf_visual import build_tmf_visuals_for_records

        visual_by_id = {}
        try:
            visual_by_id = build_tmf_visuals_for_records(
                self.last_tmf_records, stac_url=self._config_value("stac_url")
            )
        except Exception as exc:
            self._log(f"Cảnh báo tạo ảnh Sentinel-2 minh họa cho báo cáo HTML: {exc}")

        html_path = os.path.join(out_dir, "Bao_Cao_JRC_TMF.html")
        export_tmf_html_report(
            self.last_tmf_records,
            html_path,
            visual_by_id=visual_by_id,
            org_name=self._org_name_value(),
        )
        exported.append(html_path)

        try:
            if chain_full and self.last_audit_records:
                from ..exporters.excel_report import export_excel_report
                xlsx_path = os.path.join(out_dir, "Bao_Cao_Chu_Ky_CCRQT.xlsx")
                export_excel_report(
                    self.last_audit_records,
                    xlsx_path,
                    self._format_period_label(),
                    org_name=self._org_name_value(),
                )
                exported.append(xlsx_path)
            else:
                from ..exporters.excel_report import export_tmf_excel_report
                xlsx_path = os.path.join(out_dir, "Bao_Cao_JRC_TMF.xlsx")
                export_tmf_excel_report(
                    self.last_tmf_records,
                    xlsx_path,
                    org_name=self._org_name_value(),
                )
                exported.append(xlsx_path)
        except ImportError:
            pass

        if self.last_tmf_records:
            try:
                from ..exporters.eudr_geojson import export_eudr_geojson
                geojson_path = os.path.join(out_dir, "Ho_So_EUDR_TRACES.geojson")
                point_under_4ha = bool(
                    hasattr(self, "check_eudr_point_under_4ha")
                    and self.check_eudr_point_under_4ha.isChecked()
                )
                export_eudr_geojson(
                    self.last_tmf_records,
                    geojson_path,
                    point_under_4ha=point_under_4ha,
                    executing_unit=self._org_name_value(),
                )
                exported.append(geojson_path)
            except Exception as exc:
                self._log(f"Cảnh báo xuất GeoJSON EUDR 1-Click: {exc}")

        if chain_full and self.last_audit_records:
            try:
                from ..exporters.word_report import export_word_report
                docx_path = os.path.join(out_dir, "Bao_Cao_Chu_Ky_CCRQT.docx")
                period_label = self._format_period_label()
                summary = self._build_report_summary(self.last_audit_records, period_label)
                export_word_report(
                    summary,
                    self.last_audit_records,
                    [],
                    docx_path,
                    org_name=self._org_name_value(),
                    tmf_visuals=visual_by_id,
                )
                exported.append(docx_path)
            except ImportError:
                pass

        if self.active_layer is not None and self.last_tmf_records:
            pdf_path = os.path.join(out_dir, "Ban_Do_Tong_The_JRC_TMF.pdf")
            status_layer = self._build_status_layer_from_records(
                self.last_tmf_records, status_key="tmf_status", layer_name="Kết quả JRC TMF"
            )
            try:
                export_overview_map(
                    self.iface, self.plugin_dir, status_layer, "trang_thai", pdf_path,
                    include_satellite=True,
                    org_name=self._org_name_value(),
                    label_field="id_lo",
                )
                exported.append(pdf_path)
            except Exception as exc:
                self._log(f"Cảnh báo xuất bản đồ tổng thể 1-Click: {exc}")
            finally:
                QgsProject.instance().removeMapLayer(status_layer.id())

        self._log(f"Hoàn tất xuất 1-Click ({len(exported)} tệp) vào: {out_dir}")
        try:
            if os.path.isfile(html_path):
                QDesktopServices.openUrl(QUrl.fromLocalFile(html_path))
            QDesktopServices.openUrl(QUrl.fromLocalFile(out_dir))
        except Exception:
            pass
        return exported

    def _on_tmf_task_finished(self, terminated=False):
        """Populate Tab 4's independent JRC TMF table + records and sync to audit records."""
        self.btn_run_tmf.setEnabled(True)
        if hasattr(self, "btn_run_tmf_one_click"):
            self.btn_run_tmf_one_click.setEnabled(True)
        self.btn_cancel_tmf.setEnabled(False)

        task = self._tmf_task
        if task is None:
            return

        records_by_id = {record.get("id_lo"): record for record in self.last_audit_records}
        snap_by_id = getattr(self, "_tmf_attr_snapshot", {})
        lot_geom_by_id = {
            lot.get("id_lo"): lot.get("geometry_wgs84")
            for lot in getattr(task, "lots", [])
            if lot.get("id_lo")
        }
        tmf_records = []
        self.table_tmf_results.setRowCount(0)
        if hasattr(self, "table_tmf_compliant"):
            self.table_tmf_compliant.setRowCount(0)

        def _loc_str(snap):
            parts = []
            if snap.get("tieu_khu"):
                parts.append(f"TK {snap['tieu_khu']}")
            if snap.get("khoanh"):
                parts.append(f"K {snap['khoanh']}")
            if snap.get("lo"):
                parts.append(f"Lô {snap['lo']}")
            return " / ".join(parts)

        def _add_tmf_row(
            id_lo, tmf_status, tmf_year=None, tmf_ha=None, dominant="",
            driver="", loss_patches=None,
        ):
            snap = snap_by_id.get(id_lo, {})
            chu_ho = snap.get("chu_ho") or ""
            dt_lot = snap.get("dien_tich_bando")
            dt_lot_str = f"{float(dt_lot):.4f}" if dt_lot is not None else ""
            ha_rounded = round(float(tmf_ha), 4) if tmf_ha is not None else None
            ha_str = f"{ha_rounded:.4f}" if ha_rounded is not None else ""
            loc = _loc_str(snap)
            geom_wgs = lot_geom_by_id.get(id_lo)
            c_lat = c_lon = None
            if geom_wgs is not None and not geom_wgs.is_empty:
                cent = geom_wgs.centroid
                c_lat, c_lon = round(cent.y, 6), round(cent.x, 6)

            tmf_records.append({
                "id_lo": id_lo,
                "chu_ho": chu_ho,
                "tieu_khu": snap.get("tieu_khu") or "",
                "khoanh": snap.get("khoanh") or "",
                "lo": snap.get("lo") or "",
                "dien_tich_bando": dt_lot,
                "tmf_status": tmf_status,
                "tmf_year": tmf_year,
                "tmf_ha": ha_rounded,
                "tmf_dominant_class": dominant,
                "dominant_class_vi": dominant,
                "tmf_driver": driver,
                "loss_patches": loss_patches or [],
                "geometry_wgs84": geom_wgs,
                "centroid_lat": c_lat,
                "centroid_lon": c_lon,
            })

            if tmf_status == "Tuân thủ" and hasattr(self, "table_tmf_compliant"):
                row_c = self.table_tmf_compliant.rowCount()
                self.table_tmf_compliant.insertRow(row_c)
                for col, val in enumerate((id_lo, chu_ho, loc, dt_lot_str, tmf_status, dominant)):
                    self.table_tmf_compliant.setItem(
                        row_c, col, QTableWidgetItem("" if val is None else str(val))
                    )
            else:
                row = self.table_tmf_results.rowCount()
                self.table_tmf_results.insertRow(row)
                for col, val in enumerate((
                    id_lo, chu_ho, loc, dt_lot_str, tmf_status, tmf_year,
                    ha_str, dominant, driver,
                )):
                    self.table_tmf_results.setItem(
                        row, col, QTableWidgetItem("" if val is None else str(val))
                    )

            # Also sync into Tab 3 / Excel / Word records if present.
            record = records_by_id.get(id_lo)
            if record is not None:
                record["tmf_status"] = tmf_status
                record["tmf_year"] = tmf_year
                record["tmf_ha"] = ha_rounded
            s_row = self._sentinel_row_by_id.get(id_lo)
            if s_row is not None and self.table_sentinel_results.columnCount() > 7:
                for col, value in ((5, tmf_status), (6, tmf_year), (7, ha_rounded)):
                    self.table_sentinel_results.setItem(
                        s_row, col, QTableWidgetItem("" if value is None else str(value))
                    )

        handled_ids = set()
        for result in task.results:
            id_lo = result.get("id_lo")
            handled_ids.add(id_lo)
            dom_text = result.get("tmf_dominant_class") or result.get("dominant_class_vi") or ""
            _add_tmf_row(
                id_lo,
                result.get("tmf_status"),
                result.get("tmf_year"),
                result.get("tmf_ha"),
                dom_text,
                result.get("tmf_driver") or "",
                result.get("loss_patches") or [],
            )
        for error in task.errors:
            id_lo = error.get("id_lo")
            handled_ids.add(id_lo)
            _add_tmf_row(id_lo, error_status_vi(error))
        not_checked = 0
        if terminated:
            for lot in task.lots:
                id_lo = lot.get("id_lo")
                if id_lo not in handled_ids:
                    not_checked += 1
                    _add_tmf_row(id_lo, STATUS_NOT_CHECKED_CANCELLED)
        for item in getattr(self, "_tmf_skipped", []):
            _add_tmf_row(item["id_lo"], item["status"])

        self.last_tmf_records = tmf_records
        compliant = sum(1 for r in tmf_records if r.get("tmf_status") == "Tuân thủ")
        warning = sum(1 for r in tmf_records if r.get("tmf_status") == "Cảnh báo")
        violation = sum(1 for r in tmf_records if r.get("tmf_status") == "Vi phạm")
        review_total = len(tmf_records) - compliant
        if hasattr(self, "tmf_result_tabs"):
            self.tmf_result_tabs.setTabText(0, f"✅ Tuân thủ ({compliant})")
            self.tmf_result_tabs.setTabText(1, f"⚠️ Vi phạm && Cần check lại ({review_total})")
            self.tmf_result_tabs.setCurrentIndex(1 if review_total > 0 else 0)
        summary = (
            f"{len(task.results)} lô có kết quả "
            f"(Tuân thủ: {compliant}, Cảnh báo: {warning}, Vi phạm: {violation}), "
            f"{len(task.errors)} lô lỗi"
        )
        if not_checked:
            summary += f", {not_checked} lô chưa kiểm tra"
        prefix = "Đã hủy" if terminated else "Hoàn tất"
        started = getattr(self, "_tmf_started_at", None)
        elapsed_str = f" ({time.monotonic() - started:.1f}s)" if started is not None else ""
        self.label_tmf_status.setText(f"{prefix} kiểm tra JRC TMF{elapsed_str}: {summary}.")
        self._log(f"{prefix} kiểm tra JRC TMF{elapsed_str}: {summary}.")

        one_click_dir = getattr(self, "_tmf_one_click_dir", None)
        chain_full = bool(getattr(self, "_tmf_chain_full_reports", False))
        self._tmf_one_click_dir = None
        self._tmf_chain_full_reports = False
        if not terminated and one_click_dir and self.last_tmf_records:
            exported = self._export_one_click_tmf_deliverables(one_click_dir, chain_full=chain_full)
            self.label_tmf_status.setText(
                f"{prefix} 1-Click{elapsed_str}: {summary} | Đã xuất {len(exported)} tệp vào {one_click_dir}"
            )
            if chain_full:
                self.label_sentinel_status.setText(
                    f"Hoàn tất 1-Click (Sentinel-2 + JRC TMF + Báo cáo): đã xuất {len(exported)} tệp vào {one_click_dir}"
                )

    def _on_export_tmf_html_clicked(self):
        if not getattr(self, "last_tmf_records", None):
            self.label_tmf_status.setText("Vui lòng chạy kiểm tra JRC TMF trước khi xuất báo cáo.")
            return
        output_path, _filter = QFileDialog.getSaveFileName(
            self, "Xuất báo cáo HTML JRC TMF", "bao_cao_jrc_tmf.html", "HTML (*.html)"
        )
        if not output_path:
            return
        from ..exporters.html_report import export_tmf_html_report
        from ..exporters.tmf_visual import build_tmf_visuals_for_records

        self.label_tmf_status.setText("Đang tạo ảnh Sentinel-2 theo năm mất rừng cho báo cáo HTML...")
        visual_by_id = {}
        try:
            visual_by_id = build_tmf_visuals_for_records(
                self.last_tmf_records, stac_url=self._config_value("stac_url")
            )
        except Exception as exc:
            self._log(f"Cảnh báo tạo ảnh Sentinel-2 minh họa: {exc}")

        export_tmf_html_report(
            self.last_tmf_records,
            output_path,
            visual_by_id=visual_by_id,
            org_name=self._org_name_value(),
        )
        self.label_tmf_status.setText(f"Đã xuất báo cáo HTML JRC TMF: {output_path}")
        self._log(f"Xuất báo cáo HTML JRC TMF: {output_path}")
        QDesktopServices.openUrl(QUrl.fromLocalFile(output_path))

    def _on_export_tmf_excel_clicked(self):
        records = getattr(self, "last_tmf_records", None)
        if not records:
            self.label_tmf_status.setText("Vui lòng chạy kiểm tra JRC TMF trước khi xuất Excel.")
            return
        try:
            from ..exporters.excel_report import export_tmf_excel_report
        except ImportError:
            self.label_tmf_status.setText(MISSING_OPENPYXL_MESSAGE)
            self._log(MISSING_OPENPYXL_MESSAGE)
            return
        output_path, _filter = QFileDialog.getSaveFileName(
            self, "Xuất báo cáo Excel (JRC TMF)", "Bao_Cao_JRC_TMF.xlsx", "Excel (*.xlsx)"
        )
        if not output_path:
            return
        try:
            export_tmf_excel_report(
                records,
                output_path,
                org_name=self._org_name_value(),
            )
        except Exception as exc:
            msg = f"Lỗi xuất báo cáo Excel JRC TMF: {exc}"
            self.label_tmf_status.setText(msg)
            self._log(msg)
            return
        self.label_tmf_status.setText(f"Đã xuất báo cáo Excel JRC TMF: {output_path}")
        self._log(f"Xuất báo cáo Excel JRC TMF: {output_path}")
        try:
            QDesktopServices.openUrl(QUrl.fromLocalFile(output_path))
        except Exception:
            pass

    def _on_export_tmf_geojson_clicked(self):
        records = getattr(self, "last_tmf_records", None)
        if not records:
            self.label_tmf_status.setText("Vui lòng chạy kiểm tra JRC TMF trước khi xuất GeoJSON EUDR.")
            return
        output_path, _filter = QFileDialog.getSaveFileName(
            self,
            "Xuất hồ sơ GeoJSON chuẩn EUDR (TRACES NT)",
            "Ho_So_EUDR_TRACES.geojson",
            "GeoJSON (*.geojson *.json)",
        )
        if not output_path:
            return
        try:
            from ..exporters.eudr_geojson import export_eudr_geojson

            point_under_4ha = bool(
                hasattr(self, "check_eudr_point_under_4ha")
                and self.check_eudr_point_under_4ha.isChecked()
            )
            export_eudr_geojson(
                records,
                output_path,
                point_under_4ha=point_under_4ha,
                executing_unit=self._org_name_value(),
            )
        except Exception as exc:
            msg = f"Lỗi xuất GeoJSON EUDR: {exc}"
            self.label_tmf_status.setText(msg)
            self._log(msg)
            return
        self.label_tmf_status.setText(f"Đã xuất GeoJSON chuẩn EUDR (RFC 7946): {output_path}")
        self._log(
            f"Xuất GeoJSON EUDR ({len(records)} lô, point_under_4ha={point_under_4ha}): {output_path}"
        )
        try:
            QDesktopServices.openUrl(QUrl.fromLocalFile(os.path.dirname(output_path)))
        except Exception:
            pass

    def _on_export_tmf_map_clicked(self):
        if self.active_layer is None:
            self.label_tmf_status.setText("Vui lòng chọn lớp dữ liệu ở Tab 1 trước.")
            return
        if not getattr(self, "last_tmf_records", None):
            self.label_tmf_status.setText("Vui lòng chạy kiểm tra JRC TMF trước khi xuất bản đồ.")
            return
        mode_idx = self.combo_tmf_map_mode.currentIndex() if hasattr(self, "combo_tmf_map_mode") else 0
        if mode_idx == 2:
            output_path, _filter = QFileDialog.getSaveFileName(
                self, "Xuất bản đồ tổng thể JRC TMF", "ban_do_jrc_tmf.pdf", "PDF (*.pdf)"
            )
            if not output_path:
                return
            status_layer = self._build_status_layer_from_records(
                self.last_tmf_records, status_key="tmf_status", layer_name="Kết quả JRC TMF"
            )
            try:
                export_overview_map(
                    self.iface, self.plugin_dir, status_layer, "trang_thai", output_path,
                    include_satellite=True,
                    org_name=self._org_name_value(),
                    label_field="id_lo",
                )
            finally:
                QgsProject.instance().removeMapLayer(status_layer.id())
            self.label_tmf_status.setText(f"Đã xuất bản đồ tổng thể JRC TMF: {output_path}")
            self._log(f"Xuất bản đồ tổng thể JRC TMF: {output_path}")
            QDesktopServices.openUrl(QUrl.fromLocalFile(output_path))
            return

        output_dir = QFileDialog.getExistingDirectory(self, "Chọn thư mục xuất bản đồ JRC TMF")
        if not output_dir:
            return
        ids = [r.get("id_lo") for r in self.last_tmf_records if r.get("id_lo")]
        features, _unmatched = self._match_ids_to_features(ids)
        if not features:
            self.label_tmf_status.setText("Không tìm thấy lô khớp trên lớp dữ liệu.")
            return
        lon_0_deg = 106.0
        idx = self.crs_combo.currentIndex() if hasattr(self, "crs_combo") else -1
        if 0 <= idx < len(self._crs_catalog):
            lon_0_deg = float(self._crs_catalog[idx].get("lon_0", 106.0))
        tmf_by_id = {
            r.get("id_lo"): {"status": r.get("tmf_status"), "tmf_status": r.get("tmf_status")}
            for r in self.last_tmf_records if r.get("id_lo")
        }
        want_merge = mode_idx == 0
        has_pdf_lib = (
            importlib.util.find_spec("pypdf") is not None
            or importlib.util.find_spec("PyPDF2") is not None
        )
        merge = want_merge and has_pdf_lib
        paths = export_per_lot_maps(
            self.iface, self.plugin_dir, self.active_layer, features,
            self.field_map, output_dir, merge=merge,
            include_satellite=True,
            audit_records=tmf_by_id,
            lon_0_deg=lon_0_deg,
            org_name=self._org_name_value(),
        )
        self.label_tmf_status.setText(f"Đã xuất bản đồ JRC TMF (nền vệ tinh): {output_dir}")
        self._log(f"Xuất bản đồ JRC TMF: {len(features)} lô vào {output_dir}.")
        if paths:
            QDesktopServices.openUrl(QUrl.fromLocalFile(output_dir))

    def _format_period_label(self):
        if self.current_period is None:
            return ""
        t1, t2 = self.current_period
        return f"{t1.strftime('%d/%m/%Y')} – {t2.strftime('%d/%m/%Y')}"

    def _build_report_summary(self, records, period_label):
        # STATUS_CLOUDY is an inconclusive result (no clear imagery), not a
        # detected land-use change, so it is excluded from the "changed"
        # count alongside STATUS_NONE.
        # Per-lot error rows (I1: STAC/network failure, missing geometry) are
        # likewise "no result", not a detected change.
        changed = sum(
            1
            for record in records
            if not record.get("error")
            and record.get("status") not in (STATUS_NONE, STATUS_CLOUDY)
        )
        return {
            "period_label": period_label,
            "total": len(records),
            "changed": changed,
            "errors": sum(1 for record in records if record.get("error")),
        }

    def _on_export_excel_report_clicked(self):
        if not self.last_audit_records:
            self.label_report_export_status.setText(
                "Vui lòng chạy kiểm tra ở Tab 3 trước khi xuất báo cáo."
            )
            return

        try:
            from ..exporters.excel_report import export_excel_report
        except ImportError:
            self.label_report_export_status.setText(MISSING_OPENPYXL_MESSAGE)
            self._log(MISSING_OPENPYXL_MESSAGE)
            return

        output_path, _filter = QFileDialog.getSaveFileName(
            self,
            "Xuất báo cáo Excel",
            "bao_cao_chu_ky.xlsx",
            "Excel (*.xlsx)",
        )
        if not output_path:
            return

        export_excel_report(
            self.last_audit_records,
            output_path,
            self._format_period_label(),
            org_name=self._org_name_value(),
        )
        self.label_report_export_status.setText(f"Đã xuất báo cáo Excel: {output_path}")
        self._log(f"Xuất báo cáo Excel chu kỳ: {output_path}")
        QDesktopServices.openUrl(QUrl.fromLocalFile(output_path))

    def _on_export_word_report_clicked(self):
        if not self.last_audit_records:
            self.label_report_export_status.setText(
                "Vui lòng chạy kiểm tra ở Tab 3 trước khi xuất báo cáo."
            )
            return

        try:
            from ..exporters.word_report import export_word_report
        except ImportError:
            self.label_report_export_status.setText(MISSING_DOCX_MESSAGE)
            self._log(MISSING_DOCX_MESSAGE)
            return

        output_path, _filter = QFileDialog.getSaveFileName(
            self,
            "Xuất báo cáo Word",
            "bao_cao_chu_ky.docx",
            "Word (*.docx)",
        )
        if not output_path:
            return

        period_label = self._format_period_label()
        summary = self._build_report_summary(self.last_audit_records, period_label)
        visual_by_id = {}
        if getattr(self, "last_tmf_records", None):
            try:
                from ..exporters.tmf_visual import build_tmf_visuals_for_records
                visual_by_id = build_tmf_visuals_for_records(
                    self.last_tmf_records, stac_url=self._config_value("stac_url")
                )
            except Exception:
                visual_by_id = {}
        export_word_report(
            summary,
            self.last_audit_records,
            [],
            output_path,
            org_name=self._org_name_value(),
            tmf_visuals=visual_by_id,
        )
        self.label_report_export_status.setText(f"Đã xuất báo cáo Word: {output_path}")
        self._log(f"Xuất báo cáo Word chu kỳ: {output_path}")
        QDesktopServices.openUrl(QUrl.fromLocalFile(output_path))

    def _build_lot_status_layer(self):
        """Build a disposable memory copy of ``self.active_layer`` with an
        extra ``trang_thai`` attribute populated from
        ``self.last_audit_records`` (keyed by the mapped ``id_lo`` field),
        for ``export_overview_map``'s ``status_field`` argument.

        A copy (rather than adding the field to the user's own layer in
        place) because the audit status lives only in
        ``self.last_audit_records``, not on the layer itself -- Task
        9/10's Sentinel-2 audit never writes back to the source layer.
        """
        id_field = self.field_map.get("id_lo")
        status_by_id = {
            record.get("id_lo"): record.get("status") for record in self.last_audit_records
        }

        geom_type = QgsWkbTypes.displayString(self.active_layer.wkbType())
        uri = f"{geom_type}?crs={self.active_layer.crs().authid()}"
        mem_layer = QgsVectorLayer(uri, "lot_status", "memory")
        dp = mem_layer.dataProvider()
        dp.addAttributes(
            list(self.active_layer.fields()) + [QgsField("trang_thai", QVariant.String)]
        )
        mem_layer.updateFields()

        new_features = []
        for feat in self.active_layer.getFeatures():
            new_feat = QgsFeature(mem_layer.fields())
            new_feat.setGeometry(feat.geometry())
            for field in self.active_layer.fields():
                new_feat[field.name()] = feat[field.name()]

            if id_field:
                raw_id = feat[id_field]
            else:
                raw_id = None
            id_lo = str(raw_id) if raw_id is not None and raw_id != NULL else str(feat.id())
            new_feat["trang_thai"] = status_by_id.get(id_lo)
            new_features.append(new_feat)

        dp.addFeatures(new_features)
        mem_layer.updateExtents()
        return mem_layer

    def _on_export_overview_map_clicked(self):
        if self.active_layer is None:
            self.label_map_export_status.setText("Vui lòng chọn lớp dữ liệu ở Tab 1 trước.")
            return
        if not self.last_audit_records:
            self.label_map_export_status.setText(
                "Vui lòng chạy kiểm tra ở Tab 3 trước khi xuất bản đồ."
            )
            return

        output_path, _filter = QFileDialog.getSaveFileName(
            self,
            "Xuất bản đồ tổng thể",
            "ban_do_tong_the.pdf",
            "PDF (*.pdf)",
        )
        if not output_path:
            return

        status_layer = self._build_lot_status_layer()
        try:
            include_sat = (
                self.check_map_satellite.isChecked()
                if hasattr(self, "check_map_satellite")
                else False
            )
            export_overview_map(
                self.iface, self.plugin_dir, status_layer, "trang_thai", output_path,
                include_satellite=include_sat,
                org_name=self._org_name_value(),
                label_field=self.field_map.get("id_lo") or "id_lo",
            )
        except Exception as exc:
            self.label_map_export_status.setText(f"Lỗi xuất bản đồ tổng thể: {exc}")
            return
        finally:
            QgsProject.instance().removeMapLayer(status_layer.id())

        self.label_map_export_status.setText(f"Đã xuất bản đồ tổng thể: {output_path}")
        self._log(f"Xuất bản đồ tổng thể: {output_path}")
        QDesktopServices.openUrl(QUrl.fromLocalFile(output_path))

    def _on_export_per_lot_maps_clicked(self):
        if self.active_layer is None:
            self.label_map_export_status.setText("Vui lòng chọn lớp dữ liệu ở Tab 1 trước.")
            return
        if not self.last_audit_records:
            self.label_map_export_status.setText(
                "Vui lòng chạy kiểm tra ở Tab 3 trước khi xuất bản đồ."
            )
            return

        output_dir = QFileDialog.getExistingDirectory(self, "Chọn thư mục xuất bản đồ từng lô")
        if not output_dir:
            return

        ids = [record.get("id_lo") for record in self.last_audit_records if record.get("id_lo")]
        features, unmatched_ids = self._match_ids_to_features(ids)
        if not features:
            self.label_map_export_status.setText(
                "Không tìm thấy lô nào khớp với kết quả kiểm tra trên lớp đang chọn."
            )
            return

        merge = self.checkbox_merge_per_lot_pdf.isChecked()
        merge_skipped = False
        if merge and importlib.util.find_spec("PyPDF2") is None:
            # PyPDF2 is not bundled with QGIS: still export one PDF per lot,
            # just don't merge them (instead of failing after the fact).
            merge = False
            merge_skipped = True
        lon_0_deg = 106.0
        idx = self.crs_combo.currentIndex() if hasattr(self, "crs_combo") else -1
        if 0 <= idx < len(self._crs_catalog):
            lon_0_deg = float(self._crs_catalog[idx].get("lon_0", 106.0))
        include_sat = (
            self.check_map_satellite.isChecked()
            if hasattr(self, "check_map_satellite")
            else True
        )
        records_by_id = {
            r.get("id_lo"): r for r in self.last_audit_records if r.get("id_lo")
        }
        try:
            paths = export_per_lot_maps(
                self.iface, self.plugin_dir, self.active_layer, features,
                self.field_map, output_dir, merge=merge,
                include_satellite=include_sat,
                audit_records=records_by_id,
                lon_0_deg=lon_0_deg,
            )
        except Exception as exc:
            self.label_map_export_status.setText(f"Lỗi xuất bản đồ từng lô: {exc}")
            return

        message = f"Đã xuất {len(features)} bản đồ lô vào: {output_dir}"
        if unmatched_ids:
            message += f" (Bỏ qua {len(unmatched_ids)} ID không khớp lớp dữ liệu.)"
        if merge_skipped:
            message += f" {MISSING_PYPDF2_MESSAGE} Đã xuất từng file riêng."
        self.label_map_export_status.setText(message)
        self._log(f"Xuất bản đồ từng lô: {len(features)} lô vào {output_dir}.")
        if paths:
            QDesktopServices.openUrl(QUrl.fromLocalFile(output_dir))

    def _on_reset_sentinel_clicked(self):
        """Reset Tab 3 (Truy xuất khai thác) selections, search filter, and results."""
        if hasattr(self, "line_search_lots"):
            self.line_search_lots.clear()
        self._set_visible_lots_checked(False)
        self.table_sentinel_results.setRowCount(0)
        self.progress_sentinel.setValue(0)
        self.label_unmatched_ids.setText("")
        self.label_sentinel_status.setText("Đã đặt lại danh sách chọn và kết quả kiểm tra.")
        self.last_audit_records = []
        self._sentinel_lots = []
        self._sentinel_skipped = []
        self._sentinel_row_by_id = {}

    def _build_status_layer_from_records(self, records, status_key="status", layer_name="Tổng thể lô"):
        """Create a temporary vector layer for ONLY the given ``records`` with ``trang_thai``."""
        crs = self.active_layer.crs()
        geom_type = QgsWkbTypes.displayString(self.active_layer.wkbType())
        crs_auth = crs.authid() if crs is not None and crs.isValid() else ""
        uri = f"{geom_type}?crs={crs_auth}" if crs_auth else geom_type
        mem = QgsVectorLayer(uri, layer_name, "memory")
        if crs is not None and crs.isValid():
            mem.setCrs(crs)
        dp = mem.dataProvider()
        dp.addAttributes([
            QgsField("id_lo", QVariant.String),
            QgsField("trang_thai", QVariant.String),
        ])
        mem.updateFields()

        rec_by_id = {r.get("id_lo"): r for r in records if r.get("id_lo")}
        feats, _ = self._match_ids_to_features(list(rec_by_id.keys()))
        id_field = self.field_map.get("id_lo")
        new_feats = []
        for feat in feats:
            raw_id = feat[id_field] if id_field else feat.id()
            id_lo = str(raw_id)
            rec = rec_by_id.get(id_lo, {})
            nf = QgsFeature(mem.fields())
            nf.setGeometry(feat.geometry())
            nf["id_lo"] = id_lo
            nf["trang_thai"] = str(rec.get(status_key) or "")
            new_feats.append(nf)
        dp.addFeatures(new_feats)
        mem.updateExtents()
        QgsProject.instance().addMapLayer(mem, False)
        return mem

    def _on_export_traceability_map_clicked(self):
        """Export harvest traceability maps (satellite basemap + LVTLayout frame) from Tab 3."""
        if self.active_layer is None:
            self.label_sentinel_status.setText("Vui lòng chọn lớp dữ liệu ở Tab 1 trước.")
            return
        if not self.last_audit_records:
            self.label_sentinel_status.setText(
                "Vui lòng chạy kiểm tra hiện trạng khai thác trước khi xuất bản đồ truy xuất nguồn gốc."
            )
            return

        mode_idx = self.combo_trace_map_mode.currentIndex() if hasattr(self, "combo_trace_map_mode") else 0
        if mode_idx == 2:
            output_path, _filter = QFileDialog.getSaveFileName(
                self,
                "Xuất bản đồ nhiều lô (truy xuất nguồn gốc)",
                "ban_do_truy_xuat_nhieu_lo.pdf",
                "PDF (*.pdf)",
            )
            if not output_path:
                return
            status_layer = self._build_status_layer_from_records(
                self.last_audit_records, status_key="status", layer_name="Lô truy xuất nguồn gốc"
            )
            try:
                export_overview_map(
                    self.iface, self.plugin_dir, status_layer, "trang_thai", output_path,
                    include_satellite=True,
                    org_name=self._org_name_value(),
                    label_field="id_lo",
                )
            finally:
                QgsProject.instance().removeMapLayer(status_layer.id())
            self.label_sentinel_status.setText(
                f"Đã xuất bản đồ nhiều lô truy xuất nguồn gốc: {output_path}"
            )
            self._log(f"Xuất bản đồ nhiều lô truy xuất nguồn gốc: {output_path}")
            QDesktopServices.openUrl(QUrl.fromLocalFile(output_path))
            return

        output_dir = QFileDialog.getExistingDirectory(
            self, "Chọn thư mục xuất bản đồ truy xuất nguồn gốc"
        )
        if not output_dir:
            return
        ids = [r.get("id_lo") for r in self.last_audit_records if r.get("id_lo")]
        features, _unmatched = self._match_ids_to_features(ids)
        if not features:
            self.label_sentinel_status.setText("Không tìm thấy lô khớp trên lớp dữ liệu.")
            return
        lon_0_deg = 106.0
        idx = self.crs_combo.currentIndex() if hasattr(self, "crs_combo") else -1
        if 0 <= idx < len(self._crs_catalog):
            lon_0_deg = float(self._crs_catalog[idx].get("lon_0", 106.0))
        records_by_id = {
            r.get("id_lo"): r for r in self.last_audit_records if r.get("id_lo")
        }
        want_merge = mode_idx == 0
        has_pdf_lib = (
            importlib.util.find_spec("pypdf") is not None
            or importlib.util.find_spec("PyPDF2") is not None
        )
        merge = want_merge and has_pdf_lib
        paths = export_per_lot_maps(
            self.iface, self.plugin_dir, self.active_layer, features,
            self.field_map, output_dir, merge=merge,
            include_satellite=True,
            audit_records=records_by_id,
            lon_0_deg=lon_0_deg,
            stac_url=self._config_value("stac_url"),
            offline_folder=getattr(self, "offline_folder_path", None),
            org_name=self._org_name_value(),
        )
        self.label_sentinel_status.setText(
            f"Đã xuất {len(features)} bản đồ truy xuất nguồn gốc vào: {output_dir}"
        )
        self._log(f"Xuất bản đồ truy xuất nguồn gốc: {len(features)} lô vào {output_dir}.")
        if paths:
            QDesktopServices.openUrl(QUrl.fromLocalFile(output_dir))

    # ------------------------------------------------------------------
    # Tab 5 behavior: Cấu hình & Nhật ký
    # ------------------------------------------------------------------
    def _build_tab_config(self, label):
        page = QWidget()
        page.setObjectName("contentPage")
        layout = QVBoxLayout(page)

        tab_number = label.split(".", 1)[0]
        title = QLabel(f"Tab {tab_number}: {label.split('.', 1)[1].strip()}", page)
        title.setObjectName("tabTitle")
        layout.addWidget(title)

        layout.addWidget(self._build_config_form_section(page))
        layout.addWidget(self._build_log_section(page))
        layout.addStretch(1)

        return page

    def _build_config_form_section(self, parent):
        box = QGroupBox("Thông số cấu hình (áp dụng cho Tab 2 / Tab 3)", parent)
        form = QFormLayout(box)

        self.spin_cfg_sliver_ha = QDoubleSpinBox(box)
        self.spin_cfg_sliver_ha.setRange(0.0, 1000.0)
        self.spin_cfg_sliver_ha.setDecimals(4)
        self.spin_cfg_sliver_ha.setSingleStep(0.01)
        self.spin_cfg_sliver_ha.setValue(self._config_value("sliver_ha"))
        form.addRow("Ngưỡng lô mảnh vụn (ha):", self.spin_cfg_sliver_ha)

        self.spin_cfg_mismatch_pct = QDoubleSpinBox(box)
        self.spin_cfg_mismatch_pct.setRange(0.0, 100.0)
        self.spin_cfg_mismatch_pct.setSingleStep(0.5)
        self.spin_cfg_mismatch_pct.setValue(self._config_value("mismatch_pct"))
        form.addRow("Ngưỡng lệch diện tích (%):", self.spin_cfg_mismatch_pct)

        self.spin_cfg_drop_threshold = QDoubleSpinBox(box)
        self.spin_cfg_drop_threshold.setRange(-1.0, 0.0)
        self.spin_cfg_drop_threshold.setDecimals(2)
        self.spin_cfg_drop_threshold.setSingleStep(0.01)
        self.spin_cfg_drop_threshold.setValue(self._config_value("drop_threshold"))
        form.addRow("Ngưỡng sụt giảm chỉ số (khai thác):", self.spin_cfg_drop_threshold)

        self.spin_cfg_cloud_max = QDoubleSpinBox(box)
        self.spin_cfg_cloud_max.setRange(0.0, 100.0)
        self.spin_cfg_cloud_max.setSingleStep(1.0)
        self.spin_cfg_cloud_max.setValue(self._config_value("cloud_max"))
        form.addRow("Mây tối đa (%):", self.spin_cfg_cloud_max)

        self.line_cfg_stac_url = QLineEdit(box)
        self.line_cfg_stac_url.setText(self._config_value("stac_url"))
        form.addRow("STAC URL (Sentinel-2):", self.line_cfg_stac_url)

        cache_row = QHBoxLayout()
        self.line_cfg_tmf_cache_dir = QLineEdit(box)
        self.line_cfg_tmf_cache_dir.setText(self._config_value("tmf_cache_dir"))
        cache_row.addWidget(self.line_cfg_tmf_cache_dir)
        self.btn_cfg_tmf_cache_dir = QPushButton("Chọn...", box)
        self.btn_cfg_tmf_cache_dir.clicked.connect(self._on_pick_tmf_cache_dir_clicked)
        cache_row.addWidget(self.btn_cfg_tmf_cache_dir)
        form.addRow("Thư mục cache JRC TMF:", cache_row)

        self.line_cfg_org_name = QLineEdit(box)
        self.line_cfg_org_name.setText(self._config_value("org_name"))
        self.line_cfg_org_name.editingFinished.connect(
            lambda: self._on_org_name_edited(self.line_cfg_org_name)
        )
        form.addRow("Đơn vị thực hiện (mặc định):", self.line_cfg_org_name)

        self.btn_save_config = QPushButton("Lưu cấu hình", box)
        self.btn_save_config.clicked.connect(self._on_save_config_clicked)
        form.addRow(self.btn_save_config)

        self.label_config_status = QLabel("", box)
        self.label_config_status.setWordWrap(True)
        form.addRow(self.label_config_status)

        return box

    def _on_pick_tmf_cache_dir_clicked(self):
        path = QFileDialog.getExistingDirectory(self, "Chọn thư mục cache JRC TMF")
        if path:
            self.line_cfg_tmf_cache_dir.setText(path)

    def _on_save_config_clicked(self):
        """Persist Tab 5's form to ``QSettings`` AND push the new values as
        the defaults Tab 2/3's own spin boxes use from now on (same dialog
        session), per the brief's "push them as the defaults Tabs 2/3
        already use" requirement.
        """
        values = {
            "sliver_ha": self.spin_cfg_sliver_ha.value(),
            "mismatch_pct": self.spin_cfg_mismatch_pct.value(),
            "drop_threshold": self.spin_cfg_drop_threshold.value(),
            "cloud_max": self.spin_cfg_cloud_max.value(),
            "stac_url": self.line_cfg_stac_url.text().strip() or CONFIG_DEFAULTS["stac_url"],
            "tmf_cache_dir": self.line_cfg_tmf_cache_dir.text().strip()
            or CONFIG_DEFAULTS["tmf_cache_dir"],
            "org_name": self.line_cfg_org_name.text().strip() or CONFIG_DEFAULTS["org_name"],
        }
        for key, value in values.items():
            self.settings.setValue(f"config/{key}", value)
        self.settings.sync()

        self.spin_sliver_ha.setValue(values["sliver_ha"])
        self.spin_mismatch_pct.setValue(values["mismatch_pct"])
        self.spin_sentinel_cloud.setValue(values["cloud_max"])
        if hasattr(self, "line_org_name"):
            self.line_org_name.blockSignals(True)
            self.line_org_name.setText(values["org_name"])
            self.line_org_name.blockSignals(False)

        self.label_config_status.setText("Đã lưu cấu hình.")
        self._log("Đã lưu cấu hình Tab 6 (ngưỡng kiểm tra, STAC URL, thư mục cache JRC TMF).")

    def _build_log_section(self, parent):
        box = QGroupBox("Nhật ký", parent)
        layout = QVBoxLayout(box)

        self.text_log = QPlainTextEdit(box)
        self.text_log.setReadOnly(True)
        layout.addWidget(self.text_log)

        return box

    def _build_about_page(self, parent):
        page = QWidget(parent)
        page.setObjectName("contentPage")
        layout = QVBoxLayout(page)

        title = QLabel(f"Giới thiệu phần mềm (Phiên bản {self.plugin_version})", page)
        title.setObjectName("tabTitle")
        layout.addWidget(title)

        logo_label = QLabel(page)
        logo_path = os.path.join(self.plugin_dir, "assets", "logo_kiemlam.png")
        pixmap = QPixmap(logo_path)
        self.about_logo_pixmap = pixmap
        if not pixmap.isNull():
            logo_label.setPixmap(
                pixmap.scaled(140, 140, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            )
        logo_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(logo_label)

        roster_rows = "".join(
            f"<tr><td align='center'>{stt}</td><td>{name}</td>"
            f"<td>{chuc_vu}</td><td>{phone}</td></tr>"
            for stt, name, chuc_vu, phone in TEAM_ROSTER
        )
        roster_html = (
            "<h3>Danh sách cán bộ Phòng Sử dụng và Phát triển rừng</h3>"
            "<table border='1' cellspacing='0' cellpadding='5' width='100%' "
            "style='border-collapse:collapse; border-color:#D0D7DE;'>"
            "<tr style='background-color:#1B4D2E; color:#FFFFFF;'>"
            "<th>STT</th><th>Họ và tên</th><th>Chức vụ</th><th>Số điện thoại</th>"
            "</tr>"
            f"{roster_rows}"
            "</table>"
        )

        self.text_about = QTextBrowser(page)
        self.text_about.setOpenExternalLinks(True)
        self.text_about.setHtml(ABOUT_TEXT_VI + roster_html)
        layout.addWidget(self.text_about, 1)

        # Keep table_team_roster populated (hidden) for programmatic access/tests,
        # while visually rendering the roster seamlessly inside text_about above.
        self.table_team_roster = QTableWidget(len(TEAM_ROSTER), 4, page)
        self.table_team_roster.setHorizontalHeaderLabels(
            ["STT", "Họ và tên", "Chức vụ", "Số điện thoại"]
        )
        self.table_team_roster.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table_team_roster.setVisible(False)
        for row, (stt, name, chuc_vu, phone) in enumerate(TEAM_ROSTER):
            self.table_team_roster.setItem(row, 0, QTableWidgetItem(str(stt)))
            self.table_team_roster.setItem(row, 1, QTableWidgetItem(name))
            self.table_team_roster.setItem(row, 2, QTableWidgetItem(chuc_vu))
            self.table_team_roster.setItem(row, 3, QTableWidgetItem(phone))

        return page

    def _on_nav_toggled(self, button_id, checked):
        if checked:
            self.content_stack.setCurrentIndex(button_id)

    def _load_stylesheet(self):
        qss_path = os.path.join(self.plugin_dir, "assets", "styles.qss")
        try:
            with open(qss_path, "r", encoding="utf-8") as handle:
                self.setStyleSheet(handle.read())
        except OSError:
            # Styling is cosmetic; missing/unreadable QSS must not break the dialog.
            pass

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    def refresh(self):
        """Refresh dialog state on reshow (called by plugin.py's run())."""
        # Re-sync Tab 1's layer list with the current project (layers may
        # have been added/removed since the dialog was last shown). Later
        # tasks will repopulate their own tab contents here too.
        self._populate_layer_combo()
        self._on_layer_selection_changed(self.layer_combo.currentIndex())
