# -*- coding: utf-8 -*-
"""UI package for CheckCCRQT plugin."""
