# GIỚI THIỆU PLUGIN CHECK CCRQT (DÀNH CHO CLAUDE CODE)

## 1. Lệnh khởi động gửi cho Claude Code

> Hãy đọc kỹ file `C:\Users\User\OneDrive\QGIS_Plugin\CheckCCRQT\PLAN.md` và triển khai xây dựng Plugin QGIS **CheckCCRQT**.
>
> **Thông tin chung về sáng kiến & đơn vị chủ trì:**
> - **Tên sáng kiến:** *“Nghiên cứu ứng dụng AI để xây dựng Plugin mã nguồn mở trên nền tảng QGIS nhằm tự động hóa việc theo dõi kiểm tra, quản lý rừng trồng được cấp chứng chỉ quản lý rừng bền vững trên địa bàn tỉnh Quảng Trị”*
> - **Cơ quan chủ quản:** Chi cục Kiểm lâm tỉnh Quảng Trị (Sở Nông nghiệp và Môi trường tỉnh Quảng Trị) — Thực hiện nhiệm vụ theo Quyết định số 406/QĐ-CCKL ngày 08/7/2025 (Điều 5: Phòng Sử dụng và Phát triển rừng).
> - **Nhóm tác giả:** Tập thể Phòng Sử dụng và Phát triển rừng tỉnh Quảng Trị.
> - **Phụ trách chuyên môn:** Ông Phạm Thanh Trung — Trưởng phòng Sử dụng và Phát triển rừng.
> - **Liên hệ:** Email `sdptrklqt@gmail.com` | Điện thoại `0905 822 335`.
>
> **Lưu ý cốt lõi khi triển khai:**
> - Đây là **Plugin kiểm tra tính xác thực**. Dữ liệu đầu vào tối thiểu của lớp Polygon chỉ cần `ID lô` và `Hình học`.
> - Đưa đầy đủ thông tin đơn vị, Trưởng phòng, email, số điện thoại và Logo Kiểm lâm Việt Nam (tách nền đen thành PNG trong suốt) vào giao diện Sidebar/About của Plugin và `metadata.txt`.
> - Thực hiện tuần tự theo 5 giai đoạn trong `PLAN.md`.

---

## 2. Nội dung Giới thiệu chính thức (Dùng cho `README.md`, `metadata.txt` và Tab *Giới thiệu / About* trong Plugin)

**CHECK CCRQT — Hệ thống Kiểm tra Tính xác thực & Giám sát Rừng trồng Chứng chỉ**

**CheckCCRQT** là phần mềm bổ trợ (Plugin) mã nguồn mở trên nền tảng QGIS, thuộc sáng kiến *"Nghiên cứu ứng dụng AI để xây dựng Plugin mã nguồn mở trên nền tảng QGIS nhằm tự động hóa việc theo dõi kiểm tra, quản lý rừng trồng được cấp chứng chỉ quản lý rừng bền vững trên địa bàn tỉnh Quảng Trị"* do **Tập thể Phòng Sử dụng và Phát triển rừng — Chi cục Kiểm lâm tỉnh Quảng Trị** (Sở Nông nghiệp và Môi trường tỉnh Quảng Trị) nghiên cứu và xây dựng.

Phần mềm phục vụ trực tiếp công tác tham mưu, hướng dẫn và kiểm tra thực hiện phương án quản lý rừng bền vững, cấp chứng chỉ gỗ rừng trồng và giám sát khai thác theo Quyết định số 406/QĐ-CCKL ngày 08/7/2025 của Chi cục Kiểm lâm tỉnh Quảng Trị, đồng thời thiết kế mở để áp dụng trên phạm vi cả nước.

### Chức năng chính
- Chuẩn hóa hệ tọa độ VN-2000 (Quảng Trị mới `106°00'`, Quảng Trị cũ `106°15'`, Quảng Bình cũ `106°00'` và toàn bộ các tỉnh/thành Việt Nam).
- Kiểm tra lỗi hình học, thiếu số liệu thuộc tính, đối soát diện tích bản đồ với diện tích khai báo và xuất báo cáo cảnh báo HTML.
- Kiểm tra tính xác thực theo danh sách ID lô thông báo; dò chuỗi thời gian ảnh vệ tinh Sentinel-2 trực tuyến (không cần đăng nhập) để xác định thời điểm khai thác thực tế chính xác.
- Thẩm định nguy cơ phá rừng, chuyển đổi mục đích sử dụng rừng sau mốc 31/12/2020 căn cứ dữ liệu EC JRC TMF.
- Xuất báo cáo so sánh theo chu kỳ (Excel, Word) và bản đồ in PDF chuẩn khung 02 dòng kẻ.

### Thông tin đơn vị & liên hệ
- **Đơn vị thực hiện:** Phòng Sử dụng và Phát triển rừng — Chi cục Kiểm lâm tỉnh Quảng Trị
- **Cơ quan chủ quản:** Sở Nông nghiệp và Môi trường tỉnh Quảng Trị
- **Đại diện:** Ông Phạm Thanh Trung — Trưởng phòng
- **Email:** `sdptrklqt@gmail.com`
- **Điện thoại:** `0905 822 335`
