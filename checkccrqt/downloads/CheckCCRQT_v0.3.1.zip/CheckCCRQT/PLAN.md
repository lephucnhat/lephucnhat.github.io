# KẾ HOẠCH TRIỂN KHAI QGIS PLUGIN: `CheckCCRQT`

> **Tên sáng kiến**: *"Nghiên cứu ứng dụng AI để xây dựng Plugin mã nguồn mở trên nền tảng QGIS nhằm tự động hóa việc theo dõi kiểm tra, quản lý rừng trồng được cấp chứng chỉ quản lý rừng bền vững trên địa bàn tỉnh Quảng Trị"*  
> **Nhóm tác giả**: Tập thể Phòng Sử dụng và Phát triển rừng tỉnh Quảng Trị  
> **Thư mục dự án**: `C:\Users\User\OneDrive\QGIS_Plugin\CheckCCRQT`  
> **Phiên bản QGIS mục tiêu**: QGIS 3.28+ (Python 3.9+, PyQt5)

---

## 1. Mục tiêu & Phạm vi
Xây dựng Plugin QGIS mã nguồn mở **CheckCCRQT** — **Plugin kiểm tra tính xác thực** phục vụ tự động hóa thẩm định, theo dõi và quản lý rừng trồng được cấp chứng chỉ quản lý rừng bền vững (FSC/PEFC/VFCS) trên địa bàn tỉnh Quảng Trị (và mở rộng toàn quốc).

### Nguyên tắc dữ liệu tối thiểu & Kịch bản kiểm tra xác thực
* **Thông tin tối thiểu của lớp Polygon**: Chỉ bắt buộc có **`ID lô` và `Hình học (Polygon)`**. Các trường thông tin khác (Chủ hộ, Tiểu khu/Khoảnh/Lô, Năm trồng, Năm khai thác, Loài cây, Diện tích khai báo...) được ánh xạ linh hoạt nếu có, và tự động cảnh báo thiếu ở bước kiểm tra dữ liệu.
* **Kịch bản kiểm tra xác thực nhanh (Audit Verification)**: Khi có danh sách thông báo khai thác (ví dụ: ai đó đưa danh sách 5 ID lô), cán bộ chỉ cần **nhập/dán danh sách ID lô** (hoặc nạp từ Excel/CSV, hoặc chọn trên bản đồ) → Plugin tự động:
  1. Truy xuất hồ sơ từng lô: **Chủ hộ là ai? Trồng năm nào? Khai thác khai báo năm nào? Diện tích bản đồ vs khai báo?**
  2. Dò chuỗi thời gian ảnh **Sentinel-2** nhiều kỳ để **phát hiện chính xác thời điểm khai thác thực tế** (ngày/kỳ đầu tiên xảy ra sụt giảm thảm thực vật), đối chiếu tính trung thực với thời điểm khai báo.
  3. Kiểm tra **phá rừng hoặc chuyển đổi rừng sau mốc 31/12/2020** theo dữ liệu **JRC TMF** (chuẩn EUDR).

### Tài nguyên kế thừa bắt buộc tham khảo
1. **`C:\Users\User\OneDrive\QGIS_Plugin\Harvested Print`**:
   - Kế thừa tư duy `sentinel_engine.py` (tổ chức kỳ ảnh, vẽ ranh giới lô lên ảnh), `vertex_coordinate_filter.py` (định dạng tọa độ VN-2000/WGS-84), `QgsTask` chạy nền không đơ QGIS.
2. **`C:\Users\User\OneDrive\QGIS_Plugin\LVTLayout`**:
   - Kế thừa `layout_engine/engine.py` và các template `.qpt` để dựng khung in bản đồ chuẩn.
   - **Yêu cầu tùy biến khung**: Mặc định sử dụng **khung bản đồ 02 dòng kẻ** (double-line frame) gọn gàng, sạch sẽ.
3. **`C:\Users\User\OneDrive\QGIS_Plugin\LVT_EUDR`** *(Tài liệu tham khảo JRC TMF)*:
   - Tham khảo `core/analyzer.py` về cách truy vấn/phân tích dữ liệu **EC JRC Tropical Moist Forest (TMF)** (`AnnualChanges`, `TransitionMap`, `DeforestationYear`) để kiểm tra phá rừng và chuyển đổi rừng sau mốc **31/12/2020**.
4. **Logo Kiểm lâm Việt Nam**:
   - File gốc: `C:\Users\User\.gemini\antigravity\brain\65aa23a9-4019-45c9-8b35-89bd352359e5\.user_uploaded\media_1794821416792_d089ba0c.jpg`
   - Khi triển khai: Tách nền đen xung quanh hình khiên thành PNG nền trong suốt lưu tại `assets/logo_kiemlam.png` (và tạo `icon.png` cho toolbar QGIS).

---

## 2. Thiết kế Giao diện (UI/UX) — Gam màu Xanh Kiểm lâm
* **Bố cục 2 vùng (Sidebar + Content)**:
  * **Sidebar bên trái (~220px)**:
    * Trên cùng đặt **Logo Kiểm lâm Việt Nam** (`assets/logo_kiemlam.png`, căn giữa).
    * Tiêu đề: `CHECK CCRQT` & phụ đề *Phòng Sử dụng & Phát triển rừng*.
    * 5 nút điều hướng dạng tab dọc:
      1. `1. Dữ liệu & Hệ tọa độ`
      2. `2. Kiểm tra lỗi & Diện tích`
      3. `3. Giám sát Sentinel-2`
      4. `4. Báo cáo chu kỳ & In bản đồ`
      5. `5. Cấu hình & Nhật ký`
  * **Vùng nội dung bên phải**: Hiển thị form thao tác tương ứng từng tab, có thanh tiến trình `%` và nút `Hủy (Cancel)` cho các tác vụ `QgsTask`.
* **Bảng màu chuẩn Kiểm lâm**:
  * Chính (Primary): `#1B4D2E` (Xanh Kiểm lâm đậm) / `#1B5E20`
  * Nhấn (Accent): `#D4AF37` (Vàng quân hiệu)
  * Nền chính (Background): `#F4F7F5`
  * Viền / Card: `#D0D7DE` / `#FFFFFF`
  * Trạng thái: Thành công `#2E7D32`, Cảnh báo `#E65100`, Lỗi `#C62828`.

---

## 3. Kiến trúc Module & Cấu trúc Thư mục

```text
CheckCCRQT/
├── __init__.py                 # Khởi tạo plugin (classFactory)
├── metadata.txt                # Thông tin plugin QGIS (qgisMinimumVersion=3.28)
├── plugin.py                   # Controller: menu, toolbar, mở dialog
├── icon.png                    # Icon plugin (từ Logo Kiểm lâm)
├── assets/
│   ├── logo_kiemlam.png        # Logo Kiểm lâm nền trong suốt
│   └── styles.qss              # Stylesheet PyQt5 gam màu Xanh Kiểm lâm
├── core/
│   ├── __init__.py
│   ├── crs_manager.py          # Danh mục VN-2000 toàn quốc + Quảng Trị mới (106°) & cũ (106°15')
│   ├── geometry_validator.py   # Kiểm tra lỗi hình học + thiếu thuộc tính + tính/so sánh diện tích
│   ├── sentinel_stac.py        # Truy vấn Sentinel-2 L2A trực tuyến qua AWS Earth Search STAC (không cần login)
│   ├── change_detector.py      # Tính NDVI/NBR/NDMI, lọc mây SCL, dò thời điểm khai thác chính xác theo chuỗi ngày
│   ├── jrc_tmf_checker.py      # Kiểm tra phá rừng / chuyển đổi rừng sau 31/12/2020 theo JRC TMF (tham khảo LVT_EUDR)
│   └── cycle_manager.py        # Quản lý chu kỳ giám sát (Tháng/Quý/6 tháng/Năm/Tùy chọn)
├── exporters/
│   ├── __init__.py
│   ├── html_report.py          # Xuất báo cáo HTML kiểm tra lỗi Polygon & sai lệch diện tích
│   ├── excel_report.py         # Xuất Excel (.xlsx) tổng hợp biến động (dùng công thức Excel, Author="Phòng Sử dụng và Phát triển rừng — Chi cục Kiểm lâm tỉnh Quảng Trị")
│   ├── word_report.py          # Xuất Word (.docx) báo cáo chu kỳ chuẩn Chi cục (A4, Arial, lề 2cm, Author="Phòng Sử dụng và Phát triển rừng — Chi cục Kiểm lâm tỉnh Quảng Trị")
│   └── map_layout_exporter.py  # Kế thừa LVTLayout engine, khung 02 dòng kẻ, xuất PDF tổng thể & từng lô
├── templates/
│   └── Khung_CheckCCRQT_02Line.qpt  # Template bản đồ kế thừa LVTLayout, khung 02 dòng kẻ
└── ui/
    ├── __init__.py
    └── main_dialog.py          # Giao diện chính 5 tab + QgsTask workers
```

---

## 4. Đặc tả Chi tiết Từng Chức năng

### Chức năng 1: Dữ liệu đầu vào, Hệ tọa độ & Hiển thị lớp (`core/crs_manager.py`)
* **Chọn lớp Polygon**: Chọn lớp vector hiện có trong QGIS; hỗ trợ chạy trên **Toàn bộ lớp** hoặc **Các lô đang chọn (Selected features)**.
* **Hệ tọa độ VN-2000 (Dùng cho Quảng Trị & Toàn quốc)**:
  * Ghim sẵn ở đầu danh sách:
    * `Quảng Trị (Mới - sau sáp nhập) — VN-2000 / TM-3 106°00'` (múi 3°, `lon_0=106.0`, `k=0.9999`, `x_0=500000`)
    * `Quảng Trị (Cũ) — VN-2000 / TM-3 106°15'` (múi 3°, `lon_0=106.25`, `k=0.9999`, `x_0=500000`)
    * `Quảng Bình (Cũ) — VN-2000 / TM-3 106°00'` (múi 3°, `lon_0=106.0`, `k=0.9999`, `x_0=500000`)
  * Danh sách đầy đủ các kinh tuyến trục VN-2000 (múi 3° và múi 6°) của các tỉnh/thành trên cả nước + `WGS-84 (EPSG:4326)` / `UTM`.
  * Cho phép gán/chuyển hệ tọa độ (Reproject) trực tiếp cho lớp Polygon nếu lớp đầu vào chưa đúng chuẩn.
* **Thiết lập màu sắc hiển thị**: Chọn màu tô, màu viền, độ dày nét viền, độ trong suốt và áp dụng ngay lên `QgsVectorLayer.renderer()` của QGIS.
* **Ánh xạ trường thuộc tính**: Tự động nhận diện (auto-detect) và cho phép người dùng chọn lại các cột: `Mã lô / ID`, `Chủ hộ`, `Tiểu khu`, `Khoảnh`, `Lô`, `Diện tích khai báo (ha)`, `Năm trồng`, `Loài cây`, `Trạng thái chứng chỉ`.

### Chức năng 2: Kiểm tra lỗi Polygon, So sánh Diện tích & Báo cáo HTML (`core/geometry_validator.py`, `exporters/html_report.py`)
* **Kiểm tra lỗi hình học**:
  * Hình học không hợp lệ (`isGeosValid()` / self-intersection), hình học rỗng (`isEmpty()`), nhiều phần rời rạc không mong muốn, đỉnh trùng (duplicate vertices), diện tích quá nhỏ (sliver < ngưỡng cấu hình, mặc định `0.01 ha`), chồng lấn (`Overlap` giữa các lô dùng `QgsSpatialIndex`), khe hở (`Gap` nếu bật kiểm tra).
* **Kiểm tra thiếu số liệu thuộc tính**:
  * Kiểm tra `NULL` hoặc chuỗi rỗng ở các trường bắt buộc đã ánh xạ (Chủ hộ, Tiểu khu/Khoảnh/Lô, Diện tích khai báo...).
* **Tính toán & So sánh diện tích**:
  * Chiếu tạm sang hệ tọa độ phẳng VN-2000 đã chọn để tính diện tích thực tế (`ha`, làm tròn 2 hoặc 4 chữ số thập phân).
  * So sánh với cột `Diện tích khai báo`: tính `Chênh lệch (ha) = DT_BanDo - DT_KhaiBao` và `% Sai lệch`.
  * Gắn cờ cảnh báo nếu `|% Sai lệch| > Ngưỡng cho phép` (mặc định `5%`, tùy chỉnh được).
* **Xuất báo cáo cảnh báo HTML**:
  * Giao diện báo cáo web hiện đại (tông xanh Kiểm lâm), mở trực tiếp bằng trình duyệt.
  * Có thẻ tổng quan (Tổng số lô, Số lô đạt, Số lô lỗi hình học, Số lô thiếu dữ liệu, Số lô lệch diện tích), bộ lọc theo loại lỗi, tìm kiếm nhanh theo Chủ hộ / Tiểu khu / Khoảnh / Lô.

### Chức năng 3: Kiểm tra xác thực theo danh sách ID, Dò thời điểm khai thác Sentinel-2 & JRC TMF sau 31/12/2020 (`core/sentinel_stac.py`, `core/change_detector.py`, `core/jrc_tmf_checker.py`)
* **Kiểm tra xác thực nhanh theo danh sách ID thông báo (Audit Verification)**:
  * Cho phép chọn **Toàn bộ lớp**, **Các lô đang chọn**, hoặc **Nhập/dán nhanh danh sách ID lô** (ví dụ danh sách 5 lô xin khai thác, hoặc nạp từ file CSV/Excel).
  * Tự động đối chiếu ID với lớp Polygon để trích xuất hồ sơ xác thực: **Chủ hộ, Tiểu khu/Khoảnh/Lô, Năm trồng, Năm khai thác khai báo, Loài cây, Diện tích khai báo vs Diện tích bản đồ**.
* **Nguồn ảnh Sentinel-2 trực tuyến không cần đăng nhập**:
  * Sử dụng **AWS Earth Search STAC API** (`https://earth-search.aws.element84.com/v1/search`, collection `sentinel-2-l2a`).
  * Hỗ trợ tìm ảnh theo **Ngày/Tháng/Năm** (tự động lấy ảnh gần nhất trong cửa sổ `±N ngày` có độ che phủ mây thấp nhất).
  * Đọc dữ liệu trực tiếp theo vùng bao (Bounding Box) của lô rừng qua GDAL `/vsicurl/` hoặc HTTP COG windowed read — **không tải toàn bộ cảnh 800MB**, tốc độ nhanh cho cả 1 lô lẫn hàng trăm lô (`n` lô).
  * Hỗ trợ thêm chế độ **Thư mục GeoTIFF cục bộ (Offline)** khi không có Internet.
* **Phát hiện thời điểm khai thác chính xác (Time-Series Harvest Detection)**:
  * Ngoài chế độ so sánh **2 mốc (`T1` → `T2`)** và **1 mốc đơn lẻ**, bổ sung chế độ **Dò chuỗi thời gian (Time-Series)**: tự động quét các ảnh ít mây trong khoảng thời gian (hoặc từ năm trồng đến hiện tại) để xác định **ngày/tháng/năm chính xác** mà `NDVI`/`NBR` sụt giảm đột ngột (`ΔNDVI < -0.20` và duy trì thấp), từ đó trả về **Thời điểm khai thác thực tế** và đối chiếu khớp/lệch với **Năm khai thác khai báo**.
  * Phân loại tự động:
    * `Chưa khai thác` (thảm thực vật ổn định)
    * `Khai thác một phần` (suy giảm 20% – 70% diện tích lô)
    * `Đã khai thác trắng` (suy giảm > 70% diện tích lô)
    * `Bị mây che / Thiếu dữ liệu` (tỷ lệ pixel mây > 40%)
  * Trích xuất ảnh crop RGB True-Color (`B04-B03-B02`) có vẽ viền ranh giới lô rừng ở 2 mốc `T1` và `T2` (hoặc trước/sau thời điểm khai thác phát hiện được) để đưa vào báo cáo & bản đồ.
* **Kiểm tra phá rừng / chuyển đổi rừng sau 31/12/2020 (JRC TMF — tham khảo `LVT_EUDR`)**:
  * Tham khảo `C:\Users\User\OneDrive\QGIS_Plugin\LVT_EUDR\core\analyzer.py` để phân tích dữ liệu **EC JRC Tropical Moist Forest (TMF)** (`AnnualChanges`, `TransitionMap`, `DeforestationYear`).
  * Kiểm tra xem trong phạm vi Polygon có diện tích rừng tự nhiên bị phá hoặc chuyển đổi mục đích sử dụng sau ngày **31/12/2020** hay không, trả về trạng thái (`Tuân thủ` / `Cảnh báo` / `Vi phạm`), năm mất rừng và diện tích `ha` bị ảnh hưởng.

### Chức năng 4: Báo cáo so sánh theo chu kỳ & Bản in từ `LVTLayout` (`exporters/excel_report.py`, `exporters/word_report.py`, `exporters/map_layout_exporter.py`)
* **Thiết lập chu kỳ (`core/cycle_manager.py`)**:
  * Hỗ trợ chọn chu kỳ: *Hàng tháng*, *Hàng quý*, *6 tháng*, *Hàng năm*, hoặc *Khoảng ngày tùy chỉnh*. Tự động sinh cặp mốc `T1` (đầu kỳ) và `T2` (cuối kỳ).
* **Xuất Excel tổng hợp (`.xlsx`)**:
  * Sheet 1 (`Input_Data`): Dữ liệu thô từng lô (Mã lô, Chủ hộ, Tiểu khu/Khoảnh/Lô, DT Khai báo, DT Bản đồ, NDVI T1, NDVI T2, % Suy giảm, Trạng thái).
  * Sheet 2 (`Tong_Hop`): Bảng tổng hợp diện tích và số lô theo từng trạng thái khai thác, sai lệch diện tích.
  * **Bắt buộc**: Mọi ô tính toán (`Chênh lệch`, `% Sai lệch`, `ΔNDVI`, `Tổng cộng`, `Đếm theo trạng thái`) dùng công thức Excel tự nhiên (`=F5-E5`, `=SUM(...)`, `=COUNTIF(...)`, `=SUMIF(...)`, `=IF(...)`). Metadata `wb.properties.creator = "Phòng Sử dụng và Phát triển rừng — Chi cục Kiểm lâm tỉnh Quảng Trị"`.
* **Xuất Word báo cáo kiểm tra (`.docx`)**:
  * Chuẩn văn bản Kiểm lâm: Khổ A4, lề 2.0 cm, font Arial xuyên suốt, bảng rộng 17.0 cm, căn chỉnh gọn gàng.
  * Tóm tắt kết quả kiểm tra chu kỳ, bảng danh sách các lô biến động/vi phạm, chèn cặp ảnh vệ tinh Trước–Sau đối chiếu cho các lô phát hiện khai thác.
  * Metadata `Author = "Phòng Sử dụng và Phát triển rừng — Chi cục Kiểm lâm tỉnh Quảng Trị"`.
* **Xuất Bản đồ in PDF từ `LVTLayout` (`map_layout_exporter.py`)**:
  * Sử dụng `QgsPrintLayout` và template `Khung_CheckCCRQT_02Line.qpt` (kế thừa từ `LVTLayout/layout_engine/engine.py`, **khung bản đồ mặc định 02 dòng kẻ**).
  * Hỗ trợ **cả 2 chế độ xuất**:
    1. **Bản đồ tổng thể**: Toàn bộ khu vực/các lô chứng chỉ (tô màu phân loại theo trạng thái biến động/lỗi).
    2. **Xuất hàng loạt từng lô (hoặc từng cặp ảnh Trước/Sau)**: Tự động zoom tới từng lô biến động, điền thông tin chủ hộ, tọa độ VN-2000, chú giải, tỷ lệ, xuất PDF riêng từng lô hoặc gộp chung 1 file PDF.

---

## 5. Lộ trình Triển khai Đề xuất (Để Claude Code thực hiện theo từng bước)
1. **Giai đoạn 1 — Khung Plugin & UI + Tách Logo**:
   - Tạo cấu trúc thư mục `CheckCCRQT`, `metadata.txt`, `__init__.py`, `plugin.py`.
   - Tách nền đen logo Kiểm lâm thành `assets/logo_kiemlam.png` và `icon.png`.
   - Xây dựng `ui/main_dialog.py` với Sidebar + Logo bên trái, gam màu Xanh Kiểm lâm (`assets/styles.qss`) và 5 tab khung.
2. **Giai đoạn 2 — Hệ tọa độ VN-2000, Hiển thị & Kiểm tra lỗi + HTML**:
   - Xây dựng `core/crs_manager.py` (Quảng Trị 106°00' mới, 106°15' cũ, toàn quốc).
   - Xây dựng `core/geometry_validator.py` và `exporters/html_report.py`.
3. **Giai đoạn 3 — Động cơ Sentinel-2 trực tuyến (STAC), Dò thời điểm khai thác & JRC TMF**:
   - Xây dựng `core/sentinel_stac.py` (AWS Earth Search STAC + COG windowed read + fallback local).
   - Xây dựng `core/change_detector.py` (dò chuỗi thời gian tìm ngày khai thác chính xác, NDVI/NBR + lọc mây SCL + nhập nhanh danh sách ID lô + `QgsTask`).
   - Xây dựng `core/jrc_tmf_checker.py` (kiểm tra phá rừng/chuyển đổi rừng sau 31/12/2020 tham khảo `LVT_EUDR`).
4. **Giai đoạn 4 — Chu kỳ, Xuất Excel/Word & Bản đồ `LVTLayout` (Khung 02 dòng kẻ)**:
   - Xây dựng `core/cycle_manager.py`, `exporters/excel_report.py`, `exporters/word_report.py`.
   - Tạo `templates/Khung_CheckCCRQT_02Line.qpt` từ `LVTLayout` (giữ khung mặc định 02 dòng kẻ) và `exporters/map_layout_exporter.py` hỗ trợ cả bản đồ tổng thể và từng lô.
5. **Giai đoạn 5 — Kiểm thử trên QGIS thực tế**:
   - Test trên dữ liệu Polygon lô rừng Quảng Trị (kiểm tra lỗi, lệch diện tích, truy vấn Sentinel-2 trực tuyến 1 lô & nhiều lô, xuất HTML/Excel/Word/PDF).
